#!/bin/sh
git rev-parse HEAD > $1/version.txt
