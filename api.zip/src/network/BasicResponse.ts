export const RESPONSE_CODE = Object.freeze({
  NG: "NG",
  OK: "OK",
  ERROR: "error",
  UNDEFINED: "UNDEFINED"
})
export type RESPONSE_CODE_TYPE = typeof RESPONSE_CODE[keyof typeof RESPONSE_CODE]

export interface Response {
  result: RESPONSE_CODE_TYPE,
  cause?: string,
  message?: string
}

export const ResponseZero: Response = {
  result: RESPONSE_CODE.UNDEFINED,
}

export interface ResponseWithId {
  result: RESPONSE_CODE_TYPE,
  cause?: string,
  id: string
}

export const ResponseWithIdZero: ResponseWithId = {
  result: RESPONSE_CODE.UNDEFINED,
  id: ""
}

export const Signature = Object.freeze({
  response: "response",
  responseDelete: "responseDelete",
  responseDeleteMulti: "responseDeleteMulti",
  responseInsert: "responseInsert",
  responseUpdate: "responseUpdate",
  responseUpdateMulti: "responseUpdateMulti",
  items: "items",
  item: "item",
  elements: "elements",
})
export type SignatureType = typeof Signature[keyof typeof Signature]
