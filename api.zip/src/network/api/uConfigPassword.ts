//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-22 メールアドレス変更
   ログイン中の自アカウントのメールアドレスを更新する
     指定したメールアドレスが重複していたら更新せずにNGを返す
   --------------------------------------------------------------- */

export const UConfigPasswordURL = URL_ENDPOINT_TOP + '/u/config/password/'

export interface UConfigPasswordRequest {
  currentPassword: string,
  newPassword: string,
}

export type UConfigPasswordResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUConfigPassword = (
  params: UConfigPasswordRequest,
  callback: (response: UConfigPasswordResponse) => void,
) => postToApi(API_TOKEN.user, UConfigPasswordURL, params, callback)
