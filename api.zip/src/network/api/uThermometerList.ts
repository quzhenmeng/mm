import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'

export interface IdNameDto {
  id: string, //整数
  name: string,
}

export const IdNameDtoZero: IdNameDto = {
  id: "0", //整数
  name: "",
}

/* ---------------------------------------------------------------
   1-24 マイ体温計設定情報取得
   マイ体温計と計測部位に指定可能な一覧を取得する
   --------------------------------------------------------------- */

export const UThermometerListURL = URL_ENDPOINT_TOP + '/u/thermometerList/'

export interface UThermometerListRequest { }

export interface UThermometerListResponse {
  thermometerList: Array<IdNameDto>,
  measurementMethodList: Array<IdNameDto>,
}

export const UThermometerListResponseZero : UThermometerListResponse = {
  thermometerList: [IdNameDtoZero],
  measurementMethodList: [IdNameDtoZero],
}

export const postToUThermometerList = (
  params: UThermometerListRequest = {},
  callback: (response: UThermometerListResponse) => void = () => {},
) => postToApi(API_TOKEN.user, UThermometerListURL, params, callback)
