import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { TaionDto, TaionDtoZero } from './dto/TaionDto'
import { MemberDto, MemberDtoZero } from './dto/MemberDto'
import { FriendRequestDto, FriendRequestDtoZero } from './dto/FriendRequestDto'

/* ---------------------------------------------------------------
   1-4 ユーザートップ画面
   トップ画面を表示する情報を取得する
      サービスロゴ
      自メンバー情報
      本日の体温
      体温履歴共有一覧
   --------------------------------------------------------------- */

export const UHomeURL = URL_ENDPOINT_TOP + '/u/home/'

export interface UHomeRequestParameters { }

export interface UHomeResponse {
  member: MemberDto,
  taion?: TaionDto,
  friendRequestList: Array<FriendRequestDto>,
  logo: string,
  supportMailAddress: string
}

export const UHomeResponseZero = {
  member: MemberDtoZero,
  taion: TaionDtoZero,
  friendRequestList: [FriendRequestDtoZero],
  logo: "",
  supportMailAddress: ""
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUHome = (
  params: UHomeRequestParameters = {},
  callback: (response: UHomeResponse) => void = () => { },
) => postToApi(API_TOKEN.user, UHomeURL, params, callback)
