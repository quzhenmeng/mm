import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { StudentListDto, StudentListDtoZero } from './dto/StudentListDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   3-3 システム環境設定
   --------------------------------------------------------------- */

export const SStudentListURL = URL_ENDPOINT_TOP + '/s/student/list/'

export interface SStudentListRequestParameters {
  生徒番号?: string, // 生徒番号による絞り込み tdm_student.inside_no の前方一致   氏名とのOR検索
  氏名?: string, // 識別番号名は、前方一致 氏名の部分一致  生徒番号とのOR検索
  クラス?: number, //department_id を指定 /  未指定時は 0 /   0の場合、ログイン中管理者でアクセスできる全件を取得する
  並び順?: string, //"識別番号", "所属名", "連携ステータス"
  昇順降順?: string, //"昇順"：ASC
  件数: number,
  ページ: number,
  在籍無し: boolean,
}

export interface SStudentListResponse {
  items: Array<StudentListDto>,
  count: number,
  班List: Array<IdNameDto>,
}

export const SStudentListResponseZero = {
  items: [StudentListDtoZero],
  count: 0,
  班List: [IdNameDtoZero],
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSStudentList = (
  params: SStudentListRequestParameters,
  callback: (response: SStudentListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SStudentListURL, params, callback)
