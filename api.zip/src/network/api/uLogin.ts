//@flow

import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログイン
   --------------------------------------------------------------- */

export const ULoginURL = URL_ENDPOINT_TOP + '/u/login/'

export interface ULoginParameters {
  username: string,
  password: string,
}

export type ULoginResponse = Response

export const postToULogin = (
  params: ULoginParameters,
  callback: (response: ULoginResponse) => void,
) => postToApi(API_TOKEN.user, ULoginURL, params, callback)
