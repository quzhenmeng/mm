import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { FeverConfigDto, FeverConfigDtoZero } from './dto/FeverConfigDto'
import { TeacherDto, TeacherDtoZero } from './dto/TeacherDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   2-3 体温アラート管理
   --------------------------------------------------------------- */

export const THomeURL = URL_ENDPOINT_TOP + '/t/home/'

export interface THomeRequestParameters { }

export interface THomeResponse {
  clientName: string, //団体名
  department: IdNameDto, //所属クラス名
  serviceLogoId: number, //サービスロゴ取得用ID
  companyLogoId: number, //企業ロゴ取得用ID
  departmentList: Array<IdNameDto>, //選択可能なクラス
  teamList: Array<IdNameDto>, //選択可能な班
  isAdmin: boolean, //全クラス閲覧権限
  clientId: number, 
  teacher: TeacherDto,
  feverConfig: FeverConfigDto,
  体温管理対象呼称: string,
  分類名: string,
  所属名: string,
  識別番号名: string,
}

export const THomeResponseZero = {
  clientName: "", //団体名
  department: IdNameDtoZero, //所属クラス名
  serviceLogoId: 0, //サービスロゴ取得用ID
  companyLogoId: 0, //企業ロゴ取得用ID
  departmentList: [IdNameDtoZero], //選択可能なクラス
  teamList: [IdNameDtoZero], //選択可能な班
  isAdmin: false, //全クラス閲覧権限
  clientId: 0, 
  teacher: TeacherDtoZero,
  feverConfig: FeverConfigDtoZero,
  体温管理対象呼称: "",
  分類名: "",
  所属名: "",
  識別番号名: "",
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToTHome = (
  params: THomeRequestParameters = {},
  callback: (response: THomeResponse) => void = () => { },
) => postToApi(API_TOKEN.user, THomeURL, params, callback)
