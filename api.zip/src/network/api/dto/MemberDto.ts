export interface MemberDto {
  //createdAt: number, //timestamp
  birthday: number, //timestamp
  graphDisplayDays: number,
  gender: number,
  measurementMethod: string, //number
  memberId: number,
  myThermometer: string, //number
  myiconId: string, //number
  nickName: string,
  prefecture: string,
  mail: string,
  suspendedFlg: number,
  //updatedAt: number,
}

export const MemberDtoZero: MemberDto = {
  birthday: 0, //timestamp
  graphDisplayDays: 7,
  gender: 0,
  measurementMethod: "0",
  memberId: 0,
  myThermometer: "0",
  myiconId: "0",
  nickName: "",
  prefecture: "",
  mail: "",
  suspendedFlg: 0,
}