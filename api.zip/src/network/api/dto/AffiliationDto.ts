import { StudentDto, StudentDtoZero } from './StudentDto'

export interface AffiliationDto {
  affiliationId: number,
  memberId: number,
  clientId: number,
  departmentId: number,
  name: string,
  birthMonth: number,
  birthDay: number,
  status: number,  //  0:承認未、1:連携中、2:承認除外、3:連携解除済み
  studentId: number,  //未連携時は0
  acceptedAt?: number, //timestamp
  deniedAt?: number, //timestamp
  createdAt: number, //timestamp
  student?: StudentDto,
}

export const AffiliationDtoZero: AffiliationDto = {
  affiliationId: 0,
  memberId: 0,
  clientId: 0,
  departmentId: 0,
  name: "",
  birthMonth: 0,
  birthDay: 0,
  status: 0,  //  0:承認未、1:連携中、2:承認除外、3:連携解除済み
  studentId: 0,  //未連携時は0
  acceptedAt: 0,
  deniedAt: 0,
  createdAt: 0,
  student: StudentDtoZero,
}