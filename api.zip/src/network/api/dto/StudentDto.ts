export interface StudentDto {
  studentId: number,
  clientId: number,
  insideNo: string, //  未設定時は空文字 0: 申請未 / 1: 申請受付 / 2: 連携中 / 3: 連携解除
  name: string,
  status: number, //int 
  departmentId: number, //int  所属クラスを表す
  teamId: number, //int 所属班を表す
  kana: string, //未設定時は空文字
  gender: number, //int  1: 男性、2: 女性、3: その他
  birth: string, //"yyyy-mm-dd" 未設定時は空文字
  mail: string, //未設定時は空文字
  tel: string, //未設定時は空文字
  retired: boolean, //退職/退学
  hidden: boolean, //非表示
  createdAt: number, //timestamp,
  updatedAt: number //timestamp
}

export const StudentDtoZero: StudentDto = {
  studentId: 0,
  clientId: 0,
  insideNo: "", //  未設定時は空文字 0: 申請未 / 1: 申請受付 / 2: 連携中 / 3: 連携解除
  name: "",
  status: 0, //int 
  departmentId: 0, //int  所属クラスを表す
  teamId: 0, //int 所属班を表す
  kana: "", //未設定時は空文字
  gender: 0, //int  1: 男性、2: 女性、3: その他
  birth: "", //"yyyy-mm-dd" 未設定時は空文字
  mail: "", //未設定時は空文字
  tel: "", //未設定時は空文字
  retired: false, //退職/退学
  hidden: false, //非表示
  createdAt: 0, //timestamp,
  updatedAt: 0 //timestamp
}