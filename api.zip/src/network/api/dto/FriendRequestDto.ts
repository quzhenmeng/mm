export interface FriendRequestDto {
  friendRequestId: number,
  nickName: string,
  requestedAt: number, //timestamp
}

export const FriendRequestDtoZero: FriendRequestDto = {
  friendRequestId: 0,
  nickName: "",
  requestedAt: 0, //timestamp
}