export interface StudentCsvLineErrorDto {
  line: number, //  int:  CSV中の行数
  message: string, //  理由
}

export const StudentCsvLineErrorDtoZero: StudentCsvLineErrorDto = {
  line: 0, //  int:  CSV中の行数
  message: "", //  理由
}