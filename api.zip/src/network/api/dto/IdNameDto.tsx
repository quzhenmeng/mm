export interface IdNameDto {
  id: number,
  name: string,
}

export const IdNameDtoZero: IdNameDto = {
  id: 0,
  name: "",
}