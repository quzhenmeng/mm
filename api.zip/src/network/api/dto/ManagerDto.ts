export interface ManagerDto {
  managerId: number,
  clientId: number,
  name: string,
  dispName: string,
  loginId: string,
  mail: string,
  superUser: boolean
}

export const ManagerDtoZero: ManagerDto = {
  managerId: 0,
  clientId: 0,
  name: "",
  dispName: "",
  loginId: "",
  mail: "",
  superUser: false
}