export interface FeverConfigDto {
  平熱差閾値: number, //float
  体温閾値: number, //float
  アラート有効: boolean, // 当日のアラート管理を実施が有効になっている
  報告期限?: string, // "hh:mm"
  対象曜日: string, //選択された曜日設定、デバッグ用
}

export const FeverConfigDtoZero: FeverConfigDto = {
  平熱差閾値: 0, //float
  体温閾値: 0, //float
  アラート有効: false, // 当日のアラート管理を実施が有効になっている
  報告期限: "23:59", // "hh:mm"
  対象曜日: "", //選択された曜日設定、デバッグ用
}