import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE_TYPE as RESPONSE_CODE_TYPE_Temporary, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { IdNameDto, IdNameDtoZero } from "./dto/IdNameDto"

/* ---------------------------------------------------------------
   1-26 データ申請先団体詳細取得
   コードをもとに団体を検索する
   --------------------------------------------------------------- */

export const UAffiliationSearchURL = URL_ENDPOINT_TOP + '/u/affi/search/'

export interface CompanyDto { 
  clientId: number,
  name: string,
  departmentList: Array<IdNameDto>,
}

export const CompanyDtoZero = { 
  clientId: 0,
  name: "",
  departmentList: [IdNameDtoZero],
}

export interface UAffiliationSearchRequest {
  code: string,
}

export interface UAffiliationSearchResponse {
  result: RESPONSE_CODE_TYPE_Temporary, //OK or NG
  company: CompanyDto,
  申請済み: boolean,
  連携済み: boolean,
}

export const UAffiliationSearchResponseZero = {
  result: RESPONSE_CODE_Temporary.NG,
  company: CompanyDtoZero,
  申請済み: false,
  連携済み: false,
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary
export type RESPONSE_CODE_TYPE = RESPONSE_CODE_TYPE_Temporary

export const postToUAffiliationSearch = (
  params: UAffiliationSearchRequest,
  callback: (response: UAffiliationSearchResponse) => void,
) => postToApi(API_TOKEN.user, UAffiliationSearchURL, params, callback)
