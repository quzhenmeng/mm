import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { StudentCsvLineErrorDto, StudentCsvLineErrorDtoZero } from './dto/StudentCsvLineErrorDto'

/* ---------------------------------------------------------------
   3-3 システム環境設定
   --------------------------------------------------------------- */

export const SStudentCsvUploadURL = URL_ENDPOINT_TOP + '/s/student/csvUpload/'

export interface SStudentCsvUploadRequestParameters {
  file: Blob, //アップロードCSVファイル
  携帯番号取込: boolean,
}

export interface SStudentCsvUploadResponse {
  result: "OK" | "NG",
  items: Array<StudentCsvLineErrorDto>, //行エラーの発生したレコードの詳細を格納, 並び順はlineのASC, 
  データ件数: number, //全レコード数
  新規追加OK: number, //Insert対象の件数
  データ更新OK: number, // int : Update対象の件数
  処理エラーNG: number, //int : 行エラーの件数
  cause: string, //Fatalエラー発生時に設定
  message: string, //Fatalエラー発生時に設定
}

export const SStudentCsvUploadResponseZero = {
  result: "NG" as "NG",
  items: [StudentCsvLineErrorDtoZero],
  データ件数: 0, //全レコード数
  新規追加OK: 0, //Insert対象の件数
  データ更新OK: 0, // int : Update対象の件数
  処理エラーNG: 0, //int : 行エラーの件数
  cause: "", //Fatalエラー発生時に設定
  message: "", //Fatalエラー発生時に設定
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSStudentCsvUpload = (
  params: SStudentCsvUploadRequestParameters,
  callback: (response: SStudentCsvUploadResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SStudentCsvUploadURL, params, callback)
