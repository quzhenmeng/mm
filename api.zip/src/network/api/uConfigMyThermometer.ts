import { postToApi, URL_ENDPOINT_TOP, Response, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   1-25 マイ体温計登録
   ログイン中の自アカウントのメールアドレスを更新する
   --------------------------------------------------------------- */

export const UConfigMyThermometerURL = URL_ENDPOINT_TOP + '/u/config/myThermometer/'

export interface UConfigMyThermometerRequest {
  thermometerId: string, //整数
  measurementMethodId: string, //整数
}

export type UConfigMyThermometerResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary


export const postToUConfigMyThermometer = (
  params: UConfigMyThermometerRequest,
  callback: (response: UConfigMyThermometerResponse) => void,
) => postToApi(API_TOKEN.user, UConfigMyThermometerURL, params, callback)
