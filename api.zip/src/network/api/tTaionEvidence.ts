//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
//import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-36 体温画像取得
   --------------------------------------------------------------- */

export const TTaionEvidenceURL = URL_ENDPOINT_TOP + '/t/taion/evidence/'

export interface TTaionEvidenceRequest { 
  evidenceId: number,
}

export type TTaionEvidenceResponse = Blob
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToTTaionEvidence = (
  params: TTaionEvidenceRequest,
  callback: (response: TTaionEvidenceResponse) => void,
) => postToApi(API_TOKEN.user, TTaionEvidenceURL, params, callback)
