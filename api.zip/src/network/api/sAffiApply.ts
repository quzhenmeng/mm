import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   3-11 申請承認
   --------------------------------------------------------------- */

export const SAffiApplyURL = URL_ENDPOINT_TOP + '/s/affi/apply/'

export interface SAffiApplyRequestParameters {
  status: number, //int 1:連携中にする / 2:承認除外にする / 3:連携解除済みにする それ以外は IllegalArgumentException
  affiliationId: number, //int 対象の tdt_affiliation.affiliation_id
  studentId: number, //int 対象の tdm_student.student_id
}

export interface SAffiApplyResponse {
  result: "OK" | "NG"
}

export const SAffiApplyResponseZero = {
  result: "NG" as "NG"
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSAffiApply = (
  params: SAffiApplyRequestParameters,
  callback: (response: SAffiApplyResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SAffiApplyURL, params, callback)
