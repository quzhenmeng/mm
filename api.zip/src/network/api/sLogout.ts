import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログアウト
   --------------------------------------------------------------- */

export const SlogoutURL = URL_ENDPOINT_TOP + '/s/logout/'

export interface SlogoutParameters { }

export type SlogoutResponse = Response

export const postToSLogout = (
  params: SlogoutParameters = {},
  callback: (response: SlogoutResponse) => void = () => { },
) => postToApi(API_TOKEN.organization, SlogoutURL, params, callback)
