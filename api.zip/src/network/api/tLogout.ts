import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログアウト
   --------------------------------------------------------------- */

export const TLogoutURL = URL_ENDPOINT_TOP + '/t/logout/'

export interface TLogoutParameters { }

export type TLogoutResponse = Response

export const postToTLogout = (
  params: TLogoutParameters = {},
  callback: (response: TLogoutResponse) => void = () => {},
) => postToApi(API_TOKEN.smallGroup, TLogoutURL, params, callback)
