import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   1-18 アイコン一覧取得
   --------------------------------------------------------------- */

export const UIconListURL = URL_ENDPOINT_TOP + '/u/icon/list/'

export interface IconDto {
  id: number,
}

export const IconDtoZero: IconDto = {
  id: 0,
}

export interface UIconListRequest { }

export type UIconListResponse = Array<IconDto>

export const UIconListResponseZero = [IconDtoZero]

//export interface UIconListResponse {
//  items: Array<IconDto>
//}

//export const UIconListResponseZero = {
//  items: [IconDtoZero]
//}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUIconList = (
  params: UIconListRequest = {},
  callback: (response: UIconListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, UIconListURL, params, callback)
