//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN  } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ニックネーム変更
   --------------------------------------------------------------- */

export const UConfigNicknameURL = URL_ENDPOINT_TOP + '/u/config/nickname/'

export interface UConfigNicknameRequest {
  nickname: String,
}

export type UConfigNicknameResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUConfigNickname = (
  params: UConfigNicknameRequest,
  callback: (response: UConfigNicknameResponse) => void,
) => postToApi(API_TOKEN.user, UConfigNicknameURL, params, callback)
