import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   1-20 マイアイコン表示 GET可 画像を直接取得
   --------------------------------------------------------------- */

export const UIconURL = URL_ENDPOINT_TOP + '/u/icon/'
export const UIconURLWithParam = URL_ENDPOINT_TOP + '/u/icon/?iconId='

export interface UIconRequest {
  iconId: number, // int
}

export type UIconResponse = Blob

export const postToUIcon = (
  params: UIconRequest,
  callback: (response: UIconResponse) => void,
) => postToApi(API_TOKEN.user, UIconURL, params, callback)
