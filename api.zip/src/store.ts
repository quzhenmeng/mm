import { createStore } from 'redux'
import { useSelector, TypedUseSelectorHook } from 'react-redux'
import { MemberDto, MemberDtoZero } from './network/api/dto/MemberDto'
import { TaionDto, TaionDtoZero } from './network/api/dto/TaionDto'
import { UHomeTaionListResponse, UHomeTaionListResponseZero } from './network/api/uHomeTaionList'
import { UAffiliationSearchResponse, UAffiliationSearchResponseZero } from './network/api/uAffiliationSearch'

import { format } from 'date-fns'
import CameraPng from './assets/img/general/6_camera.png'
import { SHomeResponse, SHomeResponseZero } from './network/api/sHome'
import { SStudentCsvUploadResponseZero, SStudentCsvUploadResponse } from './network/api/sStudentCsvUpload'

type state = {
  sidebarShow: 'responsive' | boolean,
  asideShow: boolean,
  darkMode: boolean,
  isReloading: boolean,

  //認証
  authToken: string,
  sLoginId: string,
  sLoginHojinCode: string,
  tLoginId: string,
  tLoginHojinCode: string,
  uLoginMail: string,

  //モーダル
  danger: boolean,
  message: string

  //会員登録
  gender: string,
  birthYear: number,
  birthMonth: number,
  prefecture: string,
  nickname: string,
  password: string,
  mail: string,

  //ホーム
  memberDto: MemberDto,
  taionDto: TaionDto | undefined,
  taionListResponse: UHomeTaionListResponse
  taionListDate: string,
  taionListPage: number,
  taionListNextDates: Array<string>,
  isOneRecordADayMode: boolean,

  //体温入力
  isCameraOn: boolean,
  is確認モード: boolean,
  
  //各種設定
  uAffiliationSearchResponse: UAffiliationSearchResponse,
  supportMailAddress: string,

  //体温登録
  taionRegisterDate: string,
  taionRegisterTime: string,
  taionDegree: number,
  taionEvidence?: string,

  //システム環境設定
  sHomeResponse: SHomeResponse,
  sStudentCsvUploadResponse: SStudentCsvUploadResponse,
}

const initialState: state = {
  sidebarShow: 'responsive',
  asideShow: false,
  darkMode: false,
  isReloading: false,

  //認証関連
  authToken: "",
  sLoginId: "",
  sLoginHojinCode: "",
  tLoginId: "",
  tLoginHojinCode: "",
  uLoginMail: "",

  //モーダル関連
  danger: false,
  message: "",

  //会員登録
  gender: "男性",
  birthYear: 2000,
  birthMonth: 1,
  prefecture: "01",
  nickname: "",
  password: "",
  mail: "",

  //ホーム
  memberDto: MemberDtoZero,
  taionDto: TaionDtoZero,
  taionListResponse: UHomeTaionListResponseZero,
  taionListDate: format(new Date(), 'yyyy-MM-dd'),
  taionListPage: 1,
  taionListNextDates: [format(new Date(), 'yyyy-MM-dd')],
  isOneRecordADayMode: true,

  //体温入力
  isCameraOn: false,
  is確認モード: true,

  //各種設定
  uAffiliationSearchResponse: UAffiliationSearchResponseZero,
  supportMailAddress: "",

  //体温登録
  taionRegisterDate: format(new Date(), 'yyyy-MM-dd'),
  taionRegisterTime: format(new Date(), 'HH:mm'),
  taionDegree: 36.5,
  taionEvidence: CameraPng,

  //システム環境設定
  sHomeResponse: SHomeResponseZero,
  sStudentCsvUploadResponse: SStudentCsvUploadResponseZero,
}

type args = { type?: string, [key: string]: any }

const changeState = (state = initialState, { type, ...rest }: args) => {
  switch (type) {
    case 'set':
      return { ...state, ...rest }
    default:
      return state
  }
}

const store = createStore(changeState)
export default store

// https://react-redux.js.org/using-react-redux/static-typing#typing-the-useselector-hook
export const useTypedSelector: TypedUseSelectorHook<state> = useSelector
