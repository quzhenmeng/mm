import React from 'react'
import { AUTH_CLASS } from './constants/Localstorage'
import BackgroundImage from './assets/img/general/1_background_2.png'

const Dashboard = React.lazy(() => import('./views/Dashboard'))
const RegisterTaion = React.lazy(() => import('./views/RegisterTaion'))
const Login = React.lazy(() => import('./views/Login'))
const LoginError = React.lazy(() => import('./views/LoginError'))
const PasswordReset = React.lazy(() => import('./views/PasswordReset'))
const NewRegistoration = React.lazy(() => import('./views/NewRegistoration'))
const NewRegistorationBirthday = React.lazy(() => import('./views/NewRegistorationBirthday'))
const NewRegistorationPrefecture = React.lazy(() => import('./views/NewRegistorationPrefecture'))
const NewRegistorationNickname = React.lazy(() => import('./views/NewRegistorationNickname'))
const NewRegistorationPassword = React.lazy(() => import('./views/NewRegistorationPassword'))
const NewRegistorationEmail = React.lazy(() => import('./views/NewRegistorationEmail'))
const Config = React.lazy(() => import('./views/config/ConfigTop'))
const ConfigNickname = React.lazy(() => import('./views/config/Nickname'))
const ConfigMyIcon = React.lazy(() => import('./views/config/MyIcon'))
const ConfigThermometer = React.lazy(() => import('./views/config/Thermometer'))
const ConfigMail = React.lazy(() => import('./views/config/Mail'))
const ConfigPassword = React.lazy(() => import('./views/config/Password'))
const ConfigGraph = React.lazy(() => import('./views/config/Graph'))
const AboutThisApp = React.lazy(() => import('./views/config/AboutThisApp'))
const TermsAndConditions = React.lazy(() => import('./views/config/TermsAndConditions'))
const TokuShoHou = React.lazy(() => import('./views/config/TokuShoHou'))
const Version = React.lazy(() => import('./views/config/Version'))
const Inquiry = React.lazy(() => import('./views/config/Inquiry'))
const PrivacyPolicy = React.lazy(() => import('./views/config/PrivacyPolicy'))
const AffiliationRequest = React.lazy(() => import('./views/config/AffiliationRequest'))
const AffiliationInput = React.lazy(() => import('./views/config/AffiliationInput'))
const AffiliationList = React.lazy(() => import('./views/config/AffiliationList'))
const AffiliationCompleted = React.lazy(() => import('./views/config/AffiliationCompleted'))

const SLogin = React.lazy(() => import('./views/s/SLogin'))
const SLoginError = React.lazy(() => import('./views/s/SLoginError'))
const SDashboard = React.lazy(() => import('./views/s/SDashboard'))
const SStudent = React.lazy(() => import('./views/s/SStudent'))
const SAffiliation = React.lazy(() => import('./views/s/SAffiliation'))
const SCsv = React.lazy(() => import('./views/s/SCsv'))
const SCsvCompleted = React.lazy(() => import('./views/s/SCsvCompleted'))

const TLogin = React.lazy(() => import('./views/t/TLogin'))
const TLoginError = React.lazy(() => import('./views/t/TLoginError'))
const TDashboard = React.lazy(() => import('./views/t/TDashboard'))

const Root = React.lazy(() => import('./views/Root'))


// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/', component: Root, exact: true, name: 'Home', authClass: AUTH_CLASS.public },
  { path: '/login', name: 'Login', component: Login, backgroundImage: BackgroundImage, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/login_error', name: 'LoginError', component: LoginError, backgroundImage: BackgroundImage, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/password_reset', name: 'PasswordReset', component: PasswordReset, backgroundImage: BackgroundImage, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/new_registoration', name: 'NewRegistoration', component: NewRegistoration, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },
  { path: '/new_registoration_birthday', name: 'NewRegistorationBirthday', component: NewRegistorationBirthday, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },
  { path: '/new_registoration_prefecture', name: 'NewRegistorationPrefecture', component: NewRegistorationPrefecture, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },
  { path: '/new_registoration_nickname', name: 'NewRegistorationNickname', component: NewRegistorationNickname, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },
  { path: '/new_registoration_password', name: 'NewRegistorationPassword', component: NewRegistorationPassword, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },
  { path: '/new_registoration_email', name: 'NewRegistorationEmail', component: NewRegistorationEmail, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "プロフィール登録", authClass: AUTH_CLASS.public },

  { path: '/dashboard', name: 'Dashboard', component: Dashboard, authClass: AUTH_CLASS.user, reload: true },
  { path: '/register_taion', name: 'RegisterTaion', backgroundColor: "rgb(220,220,220)", component: RegisterTaion, cardType: true, hasHeader: false, authClass: AUTH_CLASS.user },

  { path: '/config', exact: true, name: 'Config', component: Config, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, hasCloseButton: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/about_this_app', name: 'AboutThisApp', component: AboutThisApp, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/nickname', name: 'ConfigNickname', component: ConfigNickname, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/my_icon', name: 'ConfigMyIcon', component: ConfigMyIcon, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/mail', name: 'ConfigMail', component: ConfigMail, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/password', name: 'ConfigPassword', component: ConfigPassword, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/thermometer', name: 'ConfigThermometer', component: ConfigThermometer, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/graph', name: 'ConfigGraph', component: ConfigGraph, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/terms_and_conditions', name: 'TermsAndConditions', component: TermsAndConditions, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/tokushohou', name: 'TokuShoHou', component: TokuShoHou, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/version', name: 'Version', component: Version, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/privacy_policy', name: 'PrivacyPolicy', component: PrivacyPolicy, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/inquiry', name: 'Inquiry', component: Inquiry, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/affiliation_list', name: 'AffiliationList', component: AffiliationList, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/affiliation_request', name: 'AffiliationRequest', component: AffiliationRequest, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/affiliation_input', name: 'AffiliationInput', component: AffiliationInput, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },
  { path: '/config/affiliation_completed', name: 'AffiliationCompleted', component: AffiliationCompleted, backgroundImage: BackgroundImage, cardType: true, hasHeader: true, headerTitle: "各種設定", authClass: AUTH_CLASS.user },

  { path: '/s/login', name: 'SLogin', component: SLogin, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/s/login_error', name: 'SLoginError', component: SLoginError, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/s/dashboard', name: 'SDashboard', component: SDashboard, rightLogo: true, backgroundColor: "rgb(255,255,255)", cardType: false, authClass: AUTH_CLASS.organization },
  { path: '/s/affiliation', name: 'SAffiliation', component: SAffiliation, rightLogo: true, backgroundColor: "rgb(255,255,255)", cardType: false, authClass: AUTH_CLASS.organization },
  { path: '/s/student', name: 'SStudent', component: SStudent, rightLogo: true, backgroundColor: "rgb(255,255,255)", cardType: false, authClass: AUTH_CLASS.organization },
  { path: '/s/csv', name: 'SCsv', component: SCsv, rightLogo: true, backgroundColor: "rgb(255,255,255)", cardType: false, authClass: AUTH_CLASS.organization },
  { path: '/s/csv_completed', name: 'SCsvCompleted', component: SCsvCompleted, rightLogo: true, backgroundColor: "rgb(255,255,255)", cardType: false, authClass: AUTH_CLASS.organization },

  { path: '/t/login', name: 'TLogin', component: TLogin, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/t/login_error', name: 'TLoginError', component: TLoginError, cardType: true, authClass: AUTH_CLASS.public },
  { path: '/t/dashboard', name: 'TDashboard', component: TDashboard, reload: true, logout: true, cardType: false, authClass: AUTH_CLASS.smallGroup },

]

export default routes
