import React, { useState } from 'react'

export const useInput = (initialValue: any) => {
  const [value, set] = useState(initialValue)
  return { value, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { if (e && e.target) set(e.target.value) } }
}