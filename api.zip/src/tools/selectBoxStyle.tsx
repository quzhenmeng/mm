import DownArrow from '../assets/img/general/9_cal_yajirushi_down.png'

export const selectBoxStyle = {
  width: "45%",
  height: "34px",
  display: 'inline-block',
  backgroundImage: "url(" + DownArrow + ")",
  backgroundRepeat: "no-repeat",
  backgroundSize: "34px 34px",
  backgroundPosition: "right 0px center",
  border: "none",

  WebkitAppearance: "none" as "none",
  MozAppearance: "none" as "none",
  appearance: "none" as "none",
}

export const selectBoxBorderedStyle = {
  width: "45%",
  height: "34px",
  display: 'inline-block',
  backgroundImage: "url(" + DownArrow + ")",
  backgroundRepeat: "no-repeat",
  backgroundSize: "34px 34px",
  backgroundPosition: "right 0px center",
  border: "1px solid light-gray",

  WebkitAppearance: "none" as "none",
  MozAppearance: "none" as "none",
  appearance: "none" as "none",
}