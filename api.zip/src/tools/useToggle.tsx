import { useState } from 'react'

export const useToggle = (initialValue: boolean) => {
  const [value, set] = useState(initialValue)
  return { 
    value, 
    onClick: () => { set(!value) },
    setTrue: () => { set(true) },
    setFalse: () => { set(false) },
  }
}
