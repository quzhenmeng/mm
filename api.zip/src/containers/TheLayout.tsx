import React from 'react'
import { useTypedSelector } from '../store'
import {
  TheContent,
  TheHeader
} from './index'


const TheLayout = () => {
  const darkMode = useTypedSelector((state) => state.darkMode)
  const isReloading = useTypedSelector((state) => state.isReloading)
  const classes = `c-app c-default-layout ${darkMode ? 'c-dark-theme' : ''}`

  return (
    <div className={classes}>
      <div className="c-wrapper">
        <TheHeader />
        <div className="c-body">
          {isReloading ?
            <div className="center-box" style={{ backgroundColor: 'white' }}>
              <div className="loader">Loading...</div>
            </div>
            :
            <TheContent />}
        </div>
      </div>
    </div>
  )
}

export default TheLayout
