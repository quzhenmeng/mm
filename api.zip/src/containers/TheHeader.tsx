import React from 'react'
import { useDispatch } from 'react-redux'
import { useLocation } from 'react-router-dom'
import { useTypedSelector } from '../store'
import {
  CHeader,
  CHeaderBrand,
  CButton,
  CModal,
  CModalHeader,
  CModalBody,
  CModalFooter
  //CHeaderNav,
  //CHeaderNavItem,
  //CHeaderNavLink,
  //CSubheader,
  //CToggler,
  //CBreadcrumbRouter,
} from '@coreui/react'
//import CIcon from '@coreui/icons-react'

import { AUTH_CLASS } from '../constants/Localstorage'
import routes from '../routes'

import logo from '../assets/img/general/2_App_logo.jpg'
import title from '../assets/img/general/3_service_logo.png'
import reload from '../assets/img/general/4_kousin_logo.png'
import spacer from '../assets/img/general/4_spacer.png'
import VPLogo from '../assets/img/corporate/14_VP_logo.png'

import { postToUHome } from '../network/api/uHome'
import { postToUHomeTaionList } from '../network/api/uHomeTaionList'

const TheHeader = () => {
  const dispatch = useDispatch()
  const location = useLocation()
  const danger = useTypedSelector((state) => state.danger)
  const message = useTypedSelector((state) => state.message)
  const taionListDate = useTypedSelector((state) => state.taionListDate)
  const memberDto = useTypedSelector((state) => state.memberDto)

  //const toggleDangerToTrue = () => { dispatch({ type: 'set', danger: true }) }
  const toggleDanger = () => { dispatch({ type: 'set', danger: !danger }) }

  //  const asideShow = useTypedSelector((state) => state.asideShow);
  //  const darkMode = useTypedSelector((state) => state.darkMode);
  //const sidebarShow = useTypedSelector((state) => state.sidebarShow);

  /*
  const toggleSidebar = () => {
    const val = [true, 'responsive'].includes(sidebarShow) ? false : 'responsive'
    dispatch({ type: 'set', sidebarShow: val })
  }

  const toggleSidebarMobile = () => {
    const val = [false, 'responsive'].includes(sidebarShow) ? true : 'responsive'
    dispatch({ type: 'set', sidebarShow: val })
  }
  */


  const onClickReload = async () => {
    const sleep = (second: number) => new Promise(resolve => setTimeout(resolve, second * 1000))
    await dispatch({ type: 'set', isReloading: true })
    await postToUHomeTaionList({ date: taionListDate, 件数: memberDto.graphDisplayDays }, (response) => {
      dispatch({ type: 'set', taionListResponse: response })
    })(dispatch)
    await postToUHome({}, (response) => {
      dispatch({ type: 'set', memberDto: response.member })
      dispatch({ type: 'set', taionDto: response.taion })
    })(dispatch)
    await sleep(0.5)
    await dispatch({ type: 'set', isReloading: false })
  }

  const onClickSmallGroupReload = async () => {
    window.location.reload()
  }

  return (
    <CHeader withSubheader fixed={false}>
      {routes.filter(e => e.path === location.pathname).map((route, idx) => {
        if (route.authClass === AUTH_CLASS.organization) {
          return <img src={logo} key={"leftLogo-oi" + idx} width={96 * 0.5} height={88 * 0.5} alt='Logo' style={{ margin: "10px 10px 10px 10px" }} />
        } else {
          return <img src={logo} key={"leftLogoi" + idx} width={96 * 0.64} height={88 * 0.64} alt='Logo' />
        }
      })}

      {routes.filter(e => e.path === location.pathname).map((route, idx) => {
        if (route.reload && route.authClass === AUTH_CLASS.user) {
          return <CHeaderBrand key={"header-brand" + idx} className="mx-auto" to="/dashboard">
            <img src={title} height={85 * 0.4} width={352 * 0.4} style={{ marginTop: 4, marginBottom: 4 }} alt='Logo' />
          </CHeaderBrand>
        } else if (route.authClass === AUTH_CLASS.smallGroup) {
          return <CHeaderBrand key={"header-brand" + idx} className="mx-auto" to="/t/dashboard">
            <img src={title} height={85 * 0.4} width={352 * 0.4} style={{ marginTop: 4, marginBottom: 4 }} alt='Logo' />
          </CHeaderBrand>
        } else if (route.authClass === AUTH_CLASS.organization) {
          return <CHeaderBrand key={"header-brand" + idx} style={{ marginLeft: 20 }} to="/s/dashboard">
            <img src={title} height={85 * 0.4} width={352 * 0.4} style={{ marginTop: 4, marginBottom: 4 }} alt='Logo' />
          </CHeaderBrand>
        } else {
          return <CHeaderBrand key={"header-brand" + idx} className="mx-auto" to="/">
            <img src={title} height={85 * 0.4} width={352 * 0.4} style={{ marginTop: 4, marginBottom: 4 }} alt='Logo' />
          </CHeaderBrand>
        }
      })}



      {routes.filter(e => e.path === location.pathname).map((route, idx) => {
        if (route.reload && route.authClass === AUTH_CLASS.user) {
          return <img src={reload} key={idx + "header-reload-u"} height={88 * 0.6} width={88 * 0.6} style={{ padding: "10px 10px 10px 10px", marginTop: 2 }} alt='reload' onClick={() => onClickReload()} />
        } else if (route.reload && route.authClass === AUTH_CLASS.smallGroup) {
          return <img src={reload} key={idx + "header-reload-sg"} height={88 * 0.6} width={88 * 0.6} style={{ padding: "10px 10px 10px 10px", marginTop: 2 }} alt='reload' onClick={() => onClickSmallGroupReload()} />
        } else {
          return <img src={spacer} key={idx + "header-reload-e"} height={88 * 0.6} width={88 * 0.6} style={{ padding: "10px 10px 10px 10px", marginTop: 2 }} alt='spacer' />
        }
      })}

      {routes.filter(e => e.path === location.pathname).map((route, idx) => {
        if (route.logout && route.authClass === AUTH_CLASS.smallGroup) {
          return ""/*<img src={logout} key={idx + "header-logout-sg"} height={88 * 0.6} style={{ padding: "10px 10px 10px 10px" }} alt='logout'
            onClick={() => {
              postToTLogout()(() => { })
              localStorage.removeItem(API_TOKEN.smallGroup)
              history.push("/t/login")
            }} />*/
        } else if (route.rightLogo && route.authClass === AUTH_CLASS.organization) {
          return <img src={VPLogo} key={idx + "right-logo"} height={88 * 0.6} style={{ marginLeft: "auto", padding: "10px 10px 10px 10px" }} alt='right-logo' />
        } else {
          return ""//<img src={spacer} key={idx + "header-logout"} height={88 * 0.6} style={{ padding: "10px 10px 10px 0" }} alt='spacer2' />
        }
      })}

      {/*
      <CHeaderNav className="d-md-down-none mr-auto">
        <CHeaderNavItem className="px-3" >
          <CHeaderNavLink to="/dashboard">Dashboard</CHeaderNavLink>
        </CHeaderNavItem>
      </CHeaderNav>

      <CHeaderNav className="px-3">
        <CToggler
          inHeader
          className="ml-3 d-md-down-none"
          onClick={() => dispatch({type: 'set', darkMode: !darkMode})}
          title="Toggle Light/Dark Mode"
          
        >
          <CIcon name="cil-moon" className="c-d-dark-none" alt="CoreUI Icons Moon" />
          <CIcon name="cil-sun" className="c-d-default-none" alt="CoreUI Icons Sun" />
        </CToggler>
        <CToggler
          inHeader
          className="d-md-down-none"
          onClick={() => dispatch({type: 'set', asideShow: !asideShow})}
        >
          <CIcon className="mr-2" size="lg" name="cil-applications-settings" />
        </CToggler>
      </CHeaderNav>
      */}

      <CModal show={danger} onClose={toggleDanger} className={'modal'} centered>
        <CModalHeader style={{ backgroundColor: 'rgb(62, 191, 240)' }}>メッセージ</CModalHeader>
        <CModalBody>
          {message}
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={toggleDanger}>戻る</CButton>
        </CModalFooter>
      </CModal>
    </CHeader>


  )
}

export default TheHeader
