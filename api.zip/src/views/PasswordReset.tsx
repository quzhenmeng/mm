import React, { useState } from 'react';
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import SubmitButton from '../assets/img/personal/14_re_password.png'

const Login = () => {
  const history = useHistory()

  const useInput = (initialValue: string) => {
    const [value, set] = useState(initialValue)
    return { value, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { if (e && e.target) set(e.target.value) } }
  }

  const email = useInput("")
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }

  const onSubmitClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault()
    history.push("/login")
  }

  return (
    <>
      <h4 className="cardtitle">パスワード再設定</h4>
      <CForm action="" method="post" onSubmit={handleSubmit}>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="email"
            id="nf-email"
            name="nf-email"
            placeholder="メールアドレス"
            autoComplete="email"
            {...email}
          />
        </CFormGroup>
      </CForm>
      <div className="maintext">
        登録したメールアドレスを<br />
        入力してください。<br />
        パスワード再設定用の<br />
        リンクを送信します。<br />
      </div>
      <div className="primarybutton" onClick={(event) => onSubmitClick(event)}>
        <img src={SubmitButton} width={"100%"} alt='Logo' />
      </div>
    </>
  )
}

export default Login
