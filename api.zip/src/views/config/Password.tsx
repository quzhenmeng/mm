import React from 'react'
import { useDispatch } from "react-redux"
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useInput } from '../../tools/useInput'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUConfigPassword, RESPONSE_CODE } from '../../network/api/uConfigPassword'
import { ConfigHeader } from './ConfigHeader'

const Password = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const password1 = useInput("")
  const password2 = useInput("")
  const currentPassword = useInput("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    await e.preventDefault()

    if (password1.value === "" || password2.value === "" || currentPassword.value === "") {
      dispatch({ type: 'set', message: "未入力の項目があります。入力を行ってください。" })
      dispatch({ type: 'set', danger: true })
    } else if (password1.value.length < 8 || password1.value.length > 20) {
      dispatch({ type: 'set', message: "パスワードは、半角英数字・記号、8文字以上20文字以内で登録してください。" })
      dispatch({ type: 'set', danger: true })
    } else if (password1.value !== password2.value) {
      dispatch({ type: 'set', message: "入力された、新しいパスワードが一致しません。" })
      dispatch({ type: 'set', danger: true })
    } else if (!password1.value.match(/^[a-zA-Z0-9!-/:-@¥[-`{-~]*$/)) {
      dispatch({ type: 'set', message: "パスワードは、半角英数字・記号・8文字以上20文字以内で登録してください。" })
      dispatch({ type: 'set', danger: true })
    } else {
      const parameters = {
        currentPassword: currentPassword.value,
        newPassword: password1.value,
      }
      await postToUConfigPassword(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            history.push("/config")
          }
        }
      )(dispatch)
    }
  }


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20 }}>パスワード変更</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-password1">新しいパスワード</label>
            </div>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-password1"
              name="nf-password1"
              placeholder="パスワード(8文字以上)"
              autoComplete="password1"
              {...password1}
            />
          </CFormGroup>
        </CForm>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-password2">新しいパスワード(再入力)</label>
            </div>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-password2"
              name="nf-password2"
              placeholder="パスワード(8文字以上)"
              autoComplete="password2"
              {...password2}
            />
          </CFormGroup>
        </CForm>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-currentPassword">確認のため、現在のパスワードを入力</label>
            </div>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-currentPassword"
              name="nf-currentPassword"
              placeholder="現在のパスワード"
              autoComplete="currentPassword"
              {...currentPassword}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton" style={{ marginTop: 20 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default Password
