import React from 'react'
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useInput } from '../../tools/useInput'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUConfigMail, RESPONSE_CODE } from '../../network/api/uConfigMail'
import { ConfigHeader } from './ConfigHeader'
import { is半角英数記号のみ } from '../../tools/is半角英数記号のみ'

const Mail = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const mail = useInput("")
  const password = useInput("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    if (mail.value === "" || password.value === "") {
      dispatch({ type: 'set', message: "未入力の項目があります。入力を行ってください。" })
      dispatch({ type: 'set', danger: true })
    } else if (mail.value.slice(1).indexOf('@') === -1 || !is半角英数記号のみ(mail.value) || (mail.value.match(/@/g) || []).length > 1) {
      dispatch({ type: 'set', message: "メールアドレスは、半角英数字・記号にて登録を行ってください。" })
      dispatch({ type: 'set', danger: true })
    } else {
      await e.preventDefault()
      const parameters = {
        mail: mail.value,
        password: password.value,
      }
      await postToUConfigMail(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            history.push("/config")
          }
        }
      )(dispatch)
    }
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20 }}>メールアドレス変更</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-mail">現在のメールアドレス</label>
            </div>
            <CInput
              disabled
              className="input"
              size="lg"
              type="mail"
              id="nf-mail"
              name="nf-mail"
              placeholder="現在のメールアドレス"
              autoComplete="mail"
              value={memberDto.mail}
            />
          </CFormGroup>
        </CForm>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-mail">新しいメールアドレス</label>
            </div>
            <CInput
              className="input"
              size="lg"
              type="mail"
              id="nf-mail"
              name="nf-mail"
              placeholder="メールアドレス(非公開)"
              autoComplete="mail"
              {...mail}
            />
          </CFormGroup>
        </CForm>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <div className="form-label">
              <label htmlFor="nf-password">確認のため、現在のパスワードを入力</label>
            </div>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-password"
              name="nf-password"
              placeholder="現在のパスワード"
              autoComplete="password"
              {...password}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton" style={{ marginTop: 20 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default Mail
