import { CButton } from '@coreui/react'
import React from 'react'
import { useHistory } from 'react-router-dom'
import { useTypedSelector } from '../../store'
import BackButton from '../../assets/img/personal/14_OK_orange.png'
import { ConfigHeader } from './ConfigHeader'


const Version = () => {
  const history = useHistory()
  const supportMailAddress = useTypedSelector((state) => state.supportMailAddress)

  const os = navigator.platform
  const device = navigator.userAgent
  const subject = '体温ダイアリーサービスについての問合せ'
  const body =
    '※問い合わせ内容を記載の上、送信ください。' +
    '%0D%0A' +
    '%0D%0A' +
    '以下の情報は、弊社での調査のために使用するため、このままで送信ください。' +
    '%0D%0A' +
    os + ' / ' + device
  const mailto = 'mailto:' + supportMailAddress + '?subject=' + subject + '&body=' + body

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="configtitle">お問合せ</h4>
      <iframe
        width="300px"
        height="75px"
        src="/text/inquiry_way.txt"
        scrolling="no"
        frameBorder="1"
        title="問合せ方法"
      ></iframe>
      <div style={{ textAlign: "center" }}>
        <span className="centered">お問合せ先 : {supportMailAddress}</span>
      </div>
      <div style={{ textAlign: "center", margin: "10px 0 15px 0" }}>
        <a href={mailto}><CButton color="info">同意してメールにて問合せする</CButton></a>
      </div>
      <iframe
        width="300px"
        height="200px"
        src="/text/inquiry_conditions.txt"
        scrolling="yes"
        frameBorder="1"
        title="問合せについての注意事項"
      ></iframe>
      <div className="primarybutton" style={{ marginTop: 20, textAlign: 'center' }}>
        <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
      </div>
    </>
  )
}

export default Version
