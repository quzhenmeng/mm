import React from 'react'
import { useHistory } from 'react-router-dom'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_OK_orange.png'
import { ConfigHeader } from './ConfigHeader'

const AffiliationCompleted = () => {
  const history = useHistory()
  const uAffiliationSearchResponse = useTypedSelector((state) => state.uAffiliationSearchResponse)

  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.push("/config/")
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20, marginBottom: 10 }}>データ連携申請</h4>
      <div className="centered">
        {uAffiliationSearchResponse.company.name}への<br />
        体温データ連携申請が完了しました。<br />
        所属先での承認が終わり次第、<br />
        トップ画面にてお知らせします。<br />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div className="primarybutton" style={{ marginTop: 80 }}>
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default AffiliationCompleted
