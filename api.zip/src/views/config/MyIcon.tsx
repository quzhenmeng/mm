import React, { useEffect, useState } from 'react'
import { useDispatch } from "react-redux"
import { useHistory } from 'react-router-dom'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUHome } from '../../network/api/uHome'
import { postToUConfigMyIcon, RESPONSE_CODE } from '../../network/api/uConfigMyIcon'
import { postToUIconList, UIconListResponseZero } from '../../network/api/uIconList'
import { UIconURLWithParam } from '../../network/api/uIcon'
import { ConfigHeader } from './ConfigHeader'

const MyIcon = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const [selectedMyIcon, setSelectedMyIcon] = useState(memberDto.myiconId)
  const [UIconListResponse, setUIconListResponse] = useState(UIconListResponseZero)

  useEffect(() => {
    postToUIconList()(dispatch, setUIconListResponse)
    postToUHome({}, (response) => {
      dispatch({ type: 'set', memberDto: response.member })
    })(dispatch)
  }, [dispatch])

  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    await e.preventDefault()
    const parameters = {
      iconId: selectedMyIcon
    }
    await postToUConfigMyIcon(parameters,
      async (response) => {
        if (response.result === RESPONSE_CODE.OK) {
          history.push("/config")
        }
      }
    )(dispatch)
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const icons = () => UIconListResponse.map((e) => <span style={{ padding: 5, margin: 5, backgroundColor: e.id.toString() === selectedMyIcon ? 'rgb(62, 191, 240)' : '#EEEEEE', display: 'inline-block' }}>
    <img style={{ width: 30, height: 30 }} src={UIconURLWithParam + e.id} onClick={() => { setSelectedMyIcon(e.id.toString()) }} key={"img" + e.id} alt={"img" + e.id} />
  </span>)

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20 }}>マイアイコン選択</h4>
      <div style={{ textAlign: 'center' }}>
        <div>
          <span style={{ padding: 5, margin: 5, backgroundColor: selectedMyIcon === "0" ? 'rgb(62, 191, 240)' : '#EEEEEE', display: 'inline-block' }}>
            <img style={{ width: 30, height: 30 }} src={UIconURLWithParam + "0"} onClick={() => { setSelectedMyIcon("0") }} alt={"imgDefault"} />
          </span>
          {icons()}
        </div>
        <div className="primarybutton" style={{ marginTop: 20 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>
    </>
  )
}


export default MyIcon
