import React from 'react'
import { useHistory } from 'react-router-dom'
import BackButton from '../../assets/img/personal/14_back.png'
import { ConfigHeader } from './ConfigHeader'


const AboutThisApp = () => {
  const history = useHistory()

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <iframe
        width="300px"
        height="350px"
        src="/about_this_app.html"
        scrolling="yes"
        frameBorder="1"
        title="アプリ説明"
      >
      </iframe>
      <div className="primarybutton" style={{ marginTop: 20 }}>
        <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
      </div>
    </>
  )
}

export default AboutThisApp
