import React from 'react'
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useInput } from '../../tools/useInput'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUConfigNickname, RESPONSE_CODE } from '../../network/api/uConfigNickname'
import { ConfigHeader } from './ConfigHeader'


const ChangeNickname = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const nickname = useInput(memberDto.nickName)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    await e.preventDefault()
    if (nickname.value.length === 0) {
      dispatch({ type: 'set', message: "ニックネームを入力してください。" })
      dispatch({ type: 'set', danger: true })
    } else {
      const parameters = {
        nickname: nickname.value,
      }
      await postToUConfigNickname(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            await history.push("/config/")
          }
        }
      )(dispatch)
    }
}


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle">ニックネーム変更</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="nickname"
              id="nf-nickname"
              name="nf-nickname"
              placeholder="新しいニックネーム(8文字以内)"
              autoComplete="nickname"
              value={nickname.value.slice(0, 8)}
              onChange={nickname.onChange}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default ChangeNickname
