import React from 'react'
import { useHistory } from 'react-router-dom'
import BackButton from '../../assets/img/personal/14_OK_orange.png'
import { ConfigHeader } from './ConfigHeader'


const PrivacyPolicy = () => {
  const history = useHistory()

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="configtitle">プライバシーポリシー</h4>
      <iframe
        width="300px"
        height="350px"
        src="/text/privacy_policy.txt"
        scrolling="yes"
        frameBorder="1"
        title="プライバシーポリシー"
      >
      </iframe>
      <div className="primarybutton" style={{ marginTop: 20, textAlign: 'center' }}>
        <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
      </div>
    </>
  )
}

export default PrivacyPolicy
