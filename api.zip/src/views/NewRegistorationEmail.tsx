import React from 'react';
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../store'
import { postToURegister } from '../network/api/uRegister'
import { RESPONSE_CODE } from '../network/BasicResponse'
import { API_TOKEN, LOGIN_STATUS_IS_VALID } from "../constants/Localstorage"
import InputDisabledButton from '../assets/img/personal/nyuryoku_hissu.png'
import InputButton from '../assets/img/personal/kanryo_button_icon.png'
import BackButton from '../assets/img/personal/14_back.png'
import { is半角英数記号のみ } from '../tools/is半角英数記号のみ'


const NewRegistorationEmail = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const mail = useTypedSelector((state) => state.mail)

  const gender = useTypedSelector((state) => state.gender)
  const birthYear = useTypedSelector((state) => state.birthYear)
  const birthMonth = useTypedSelector((state) => state.birthMonth)
  const prefecture = useTypedSelector((state) => state.prefecture)
  const nickname = useTypedSelector((state) => state.nickname)
  const password = useTypedSelector((state) => state.password)


  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    await e.preventDefault()
    if (mail.slice(1).indexOf('@') === -1 || !is半角英数記号のみ(mail) || (mail.match(/@/g) || []).length > 1) {
      dispatch({ type: 'set', message: "メールアドレスは、半角英数字・記号にて登録を行ってください。" })
      dispatch({ type: 'set', danger: true })
    } else {
      const parameters = {
        gender: gender,
        birthYear: birthYear,
        birthMonth: birthMonth,
        prefecture: prefecture,
        nickname: nickname,
        password: password,
        mail: mail,
      }
      await postToURegister(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            await localStorage.setItem(API_TOKEN.user, LOGIN_STATUS_IS_VALID)
            await history.push("/dashboard")
          }
        }
      )(dispatch)
    }
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <h4 className="cardtitle" style={{ marginTop: 10 }}>メールアドレス入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="text"
              id="nf-email"
              name="nf-email"
              placeholder="メールアドレス（非公開）"
              autoComplete="email"
              value={mail}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', mail: e.target.value })}
            />
          </CFormGroup>
        </CForm>
        <iframe
          width="300px"
          height="250px"
          src="/text/terms_and_conditions_and_privacy_policy.txt"
          scrolling="yes"
          frameBorder="1"
          title="利用規約"
          style={{ marginTop: 20 }}
        >
        </iframe>
        <div className="primarybutton" style={{ marginTop: 20 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          {mail !== "" ?
            <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
            :
            <img src={InputDisabledButton} className="inputbutton" alt='InputDisabled' />
          }
        </div>
      </div>

    </>
  )
}

export default NewRegistorationEmail
