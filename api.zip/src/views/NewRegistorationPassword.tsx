import React from 'react'
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../store'
import { useInput } from '../tools/useInput'
import InputDisabledButton from '../assets/img/personal/nyuryoku_hissu.png'
import InputDisabledPasswordInconsistentButton from '../assets/img/personal/password_mismatch.png'
import InputButton from '../assets/img/personal/14_nyuryoku.png'
import BackButton from '../assets/img/personal/14_back.png'


const NewRegistorationPassword = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const password = useTypedSelector((state) => state.password)

  const password2 = useInput("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    if (password.length < 8 || password.length > 21 || !is半角英数記号のみ(password)) {
      dispatch({ type: 'set', message: "パスワードは、半角英数字・記号、8文字以上20文字以内で登録してください。" })
      dispatch({ type: 'set', danger: true })
    } else {
      history.push("/new_registoration_email")
    }
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const is半角英数記号のみ = (s: string) => new RegExp(/^[a-zA-Z0-9!-/:-@¥[-`{-~]*$/).test(s)

  return (
    <>
      <h4 className="cardtitle">パスワード入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm action="" method="post" onSubmit={handleSubmit}>
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-password"
              name="nf-password"
              placeholder="パスワード（８文字以上）"
              autoComplete="password"
              value={password}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', password: e.target.value })}
            />
          </CFormGroup>
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="password"
              id="nf-password2"
              name="nf-password2"
              placeholder="パスワード（再入力）"
              autoComplete="password2"
              {...password2}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          {password !== "" && password2.value !== "" ?
            password === password2.value ?
              <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
              :
              <img src={InputDisabledPasswordInconsistentButton} className="inputbutton" alt='InputDisabled' />
            :
            <img src={InputDisabledButton} className="inputbutton" alt='InputDisabled' />
          }
        </div>
      </div>

    </>
  )
}

export default NewRegistorationPassword
