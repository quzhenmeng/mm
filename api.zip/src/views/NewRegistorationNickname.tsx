import React from 'react'
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../store'
import InputDisabledButton from '../assets/img/personal/nyuryoku_hissu.png'
import InputButton from '../assets/img/personal/14_nyuryoku.png'
import BackButton from '../assets/img/personal/14_back.png'


const NewRegistorationNickname = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const nickname = useTypedSelector((state) => state.nickname)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.push("/new_registoration_password")
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <h4 className="cardtitle">ニックネーム入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="nickname"
              id="nf-nickname"
              name="nf-nickname"
              placeholder="ニックネーム(8文字以内)"
              autoComplete="nickname"
              value={nickname}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', nickname: e.target.value.slice(0, 8) })}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          {nickname !== "" ?
            <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
            :
            <img src={InputDisabledButton} className="inputbutton" alt='InputDisabled' />
          }
        </div>
      </div>

    </>
  )
}

export default NewRegistorationNickname
