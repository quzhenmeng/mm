import { CRow, CCol, CSelect, CButton, CModal, CModalHeader, CModalBody, CModalFooter, CInput } from '@coreui/react'
import { CChart } from '@coreui/react-chartjs'
import React, { useState, useEffect } from 'react'
import { useDispatch } from "react-redux"
import { useToggle } from '../../tools/useToggle'
import Camera from '../../assets/img/general/6_camera.png'
import LeftArrow from '../../assets/img/general/9_cal_yajirushi_left.png'
import RightArrow from '../../assets/img/general/9_cal_yajirushi_right.png'
import Calendar from '../../assets/img/general/12_touroku_date.png'
import { postToTHome, THomeResponseZero } from '../../network/api/tHome'
import { postToTTaionSummary, TTaionSummaryResponseZero } from '../../network/api/tTaionSummary'
import { postToTTaionList, TTaionListResponseZero } from '../../network/api/tTaionList'
import { TTaionEvidenceURL } from '../../network/api/tTaionEvidence'
import { TaionDto } from '../../network/api/dto/TaionDto'
import { useTypedSelector } from '../../store'
import { useHistory } from 'react-router-dom'
import { API_TOKEN } from '../../constants/Localstorage'
import { isAfter, isToday, subDays } from 'date-fns'
import { format, addDays } from 'date-fns/fp'

import DatePicker, { registerLocale } from "react-datepicker"
import ja from "date-fns/locale/ja"
import "react-datepicker/dist/react-datepicker.css"

import Slider from "react-slick"
import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"

import { selectBoxBorderedStyle, selectBoxStyle } from "../../tools/selectBoxStyle"
import { RESPONSE_CODE } from '../../network/BasicResponse'
import { TaionListDto, TaionListDtoZero } from '../../network/api/dto/TaionListDto'

import { unregister } from '../../serviceWorker'
import version from "../../assets/version.json"
import { postToRoot } from '../../network/api/root'

import { postToTLogout } from '../../network/api/tLogout'

const formatYyyyMMdd = format("yyyy-MM-dd")

const TDashboard = () => {
  registerLocale("ja", ja)
  const [THomeResponse, setTHomeResponse] = useState(THomeResponseZero)
  const [TTaionSummaryResponse, setTTaionSummaryResponse] = useState(TTaionSummaryResponseZero)
  const [TTaionListResponse, setTTaionListResponse] = useState(TTaionListResponseZero)
  const [studentId, setStudentId] = useState(0)
  const dispatch = useDispatch()
  const history = useHistory()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const taionListDate = useTypedSelector((state) => state.taionListDate)
  //const taionListNextDates = useTypedSelector((state) => state.taionListNextDates)
  const taionListResponse = useTypedSelector((state) => state.taionListResponse)
  const taionListData = TTaionListResponse.subItems.reduce((acc: Array<TaionDto>, current, index) => {
    const prev = acc.slice(-1)[0]
    if (prev) {
      if (formatYyyyMMdd(prev.date) === formatYyyyMMdd(current.date)) {
        if (prev.registered) return acc
        if (current.registered) return [...(acc.filter(e => formatYyyyMMdd(e.date) !== formatYyyyMMdd(current.date))), current]
        if (current.date > prev.date) {
          return [...(acc.filter(e => formatYyyyMMdd(e.date) !== formatYyyyMMdd(current.date))), current]
        }
        return acc
      }
    }
    return [...acc, current]
  }, [])
  const line = lineBuilder(taionListData.slice(0, memberDto.graphDisplayDays).reverse())
  const toggle = useToggle(false)
  const toggle2 = useToggle(false)
  const toggle3 = useToggle(false)
  const [anEvidenceId, setAnEvidenceId] = useState(0)
  const [departmentId, setDepartmentId] = useState(0)
  const [teamId, setTeamId] = useState(0)
  const [sortMode, setSortMode] = useState("")
  const [order, setOrder] = useState(true)
  //const [anStudentId, setAnStudentId] = useState(0)

  const sortBy分類 = (n1: TaionListDto, n2: TaionListDto) => {
    return n1.teamId > n2.teamId ? 1 :
      n1.teamId === n2.teamId ? 0 : -1
  }
  const sortBy識別番号 = (n1: TaionListDto, n2: TaionListDto) => {
    return n1.number > n2.number ? 1 :
      n1.number === n2.number ? 0 : -1
  }
  const sortBy体温 = (n1: TaionListDto, n2: TaionListDto) => {
    return n1.temperature > n2.temperature ? 1 :
      n1.temperature === n2.temperature ? 0 : -1
  }
  const sortBy平熱差 = (n1: TaionListDto, n2: TaionListDto) => {
    return n1.diff > n2.diff ? 1 :
      n1.diff === n2.diff ? 0 : -1
  }
  const sortBy時刻 = (n1: TaionListDto, n2: TaionListDto) => {
    if (n1.date === undefined && n2.date === undefined) return 0
    if (n1.date === undefined) return -1
    if (n2.date === undefined) return 1
    return n1.date > n2.date ? 1 :
      n1.date === n2.date ? 0 : -1
  }
  const sortFunction = (n1: TaionListDto, n2: TaionListDto) => {
    if (sortMode === "体温") return sortBy体温(n1, n2)
    if (sortMode === "平熱差") return sortBy平熱差(n1, n2)
    if (sortMode === "時刻") return sortBy時刻(n1, n2)
    if (sortMode === "識別番号") return sortBy識別番号(n1, n2)
    return sortBy分類(n1, n2)
  }

  useEffect(() => {
    const ClientVersion = localStorage.getItem("ClientVersion")
    const ServerVersion = localStorage.getItem("ServerVersion")
    if (ClientVersion !== version.version) {
      localStorage.setItem("ClientVersion", version.version)
      unregister()
      console.log("...Client Refresh")
    }
    postToRoot({}, (response) => {
      if (ServerVersion !== response.version) {
        localStorage.setItem("ServerVersion", response.version)
        unregister()
        console.log("...Server Refresh")
      }
      console.log("Server Version: " + ServerVersion)
    })(() => { })
    console.log("Client Version: " + ClientVersion)
  }, [])

  useEffect(() => {
    postToTHome({}, () => {
    })(dispatch, setTHomeResponse)

    postToTTaionSummary({ date: taionListDate, departmentId: departmentId }, () => {
    })(dispatch, setTTaionSummaryResponse)
  }, [taionListDate, departmentId, dispatch])

  const now = new Date()
  const isTaionListDateIsAfterInitialDate = (days: number) => isAfter(addDays(days)(new Date(taionListDate)), new Date(taionListResponse.initialDate))
  const isTaionListDateIsTodayOrAfterToday = (days: number) => isAfter(addDays(days)(new Date(taionListDate)), new Date(formatYyyyMMdd(now))) || isToday(new Date(taionListDate))

  const adjustedGraghHeight = () => {
    const height = window.innerHeight
    switch (true) {
      case height <= 667:
        return "190px"
      case height <= 736:
        return "215px"
      case height <= 770:
        return "260px"
      case height <= 812:
        return "320px"
      default:
        return "350px"
    }
  }

  const adjustedIchiranListNumbers = () => {
    const height = window.innerHeight
    switch (true) {
      case height <= 667:
        return 7
      case height <= 736:
        return 8
      case height <= 770:
        return 10
      case height <= 812:
        return 14
      default:
        return 14
    }
  }

  const getDepartmentName = () => {
    if (TTaionSummaryResponse.department != null && TTaionSummaryResponse.department.name !== "")
      return "（" + TTaionSummaryResponse.department.name + "）"
    return ""
  }

  const get発熱人数 = () => {
    if (TTaionSummaryResponse.items === [TaionListDtoZero]) return "-"
    if (TTaionSummaryResponse.items.length === 1 && TTaionSummaryResponse.items[0].studentId === 0) return "-"
    return TTaionSummaryResponse.items.filter((ex) => ex.teamId === teamId || teamId === 0).filter(e => e.temperature > THomeResponse.feverConfig.体温閾値).length
  }

  const get未報告人数 = () => {
    if (!is報告期限を越えている()) return "0"
    if (TTaionSummaryResponse.items === [TaionListDtoZero]) return "-"
    if (TTaionSummaryResponse.items.length === 1 && TTaionSummaryResponse.items[0].studentId === 0) return "-"
    return TTaionSummaryResponse.items.filter((ex) => ex.teamId === teamId || teamId === 0).filter(e => e.temperature === 0).length
  }

  const is報告期限を越えている = () => {
    return new Date() > new Date(formatYyyyMMdd(new Date()) + " " + (THomeResponse.feverConfig.報告期限 || "23:59"))
  }
  const is体温表示レッド = (e: TaionListDto) => {
    /*
        　　　　　報告期限前　　報告期限後　表示例
        未報告　　黒＊　　　　　赤　　　　　未
        平熱　　　黒　　　　　　黒　　　　　36.1
        高熱　　　赤　　　　　　赤　　　　　38.2
    */
    // 高熱の場合 赤
    if (e.temperature > THomeResponse.feverConfig.体温閾値) return true
    // 報告期限に報告がない 赤
    if (e.temperature === 0 && is報告期限を越えている()) return true
    // 報告あり、平熱
    // 報告なし、期限前
    return false
  }
  const is平熱差表示レッド = (e: TaionListDto) => {
    /*
        　　　　　報告期限前　　報告期限後　表示例
        未報告　　黒　　　　　　黒＊　　　　-
        算出未　　黒＊　　　　　黒＊　　　　算出未
        閾値内　　黒　　　　　　黒　　　　　+0.12
        閾値外　　赤　　　　　　赤　　　　　+2.87
    */
    // 算出未 は優先的に 黒
    if (e.regTempSampleCount && e.regTempSampleCount < 3) return false
    // 閾値を越えてる 赤
    if (e.diff > THomeResponse.feverConfig.平熱差閾値) return true
    // 未報告は常に 黒
    // 報告期限に報告がない 黒
    // 報告あり、閾値内
    // 報告なし、期限前
    return false
  }

  return (
    <div style={{ width: "100%" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <div style={{ backgroundColor: 'white', borderRadius: "0 0 0.5rem 0.5rem", margin: "-5px 10px 0 10px", padding: "5px 5px 5px 5px" }}>
          <CRow>
            <CCol style={{ textAlign: 'left', verticalAlign: "middle", height: 33 }}>
            </CCol>
            <CCol style={{ textAlign: 'center', verticalAlign: "middle", height: 33, whiteSpace: "nowrap" }}>
              <div style={{ fontSize: 'large', fontWeight: 'bold' }}>{THomeResponse.clientName} {getDepartmentName()}</div>
            </CCol>
            <CCol style={{ textAlign: 'right', verticalAlign: "middle", height: 33 }}>
              {THomeResponse.isAdmin ? <CButton size="sm" color="secondary" onClick={toggle3.onClick}>{THomeResponse.所属名}切替</CButton> : <></>}
            </CCol>
          </CRow>
          <div style={{ borderBottom: "2px solid lightgray", marginBottom: 5 }}></div>
          <CRow>
            <CCol style={{ textAlign: 'center', display: 'flex', alignItems: "center", maxHeight: 35 }}>
              <div style={{ textAlign: 'center', margin: '-3px auto 0 auto', width: '100%' }}>
                <div style={{ textAlign: 'center', margin: '-3px auto 0 auto', whiteSpace: 'nowrap' }}>
                  <div style={{ verticalAlign: 'super', margin: 'auto', display: 'inline-block', whiteSpace: "nowrap", color: "white", backgroundColor: 'rgb(240,142,44)', fontWeight: 'bold', padding: "0px 5px", borderRadius: 3 }}>発熱あり</div>
                  <span style={{ marginLeft: 10, fontSize: 32, fontWeight: 'bold', color: 'rgb(240,142,44)', }}>{get発熱人数()}</span>
                  <span style={{ marginLeft: 5, fontSize: 20, fontWeight: 'bold', color: 'rgb(240,142,44)' }}>名</span>
                  <div style={{ verticalAlign: 'super', display: 'inline-block', marginLeft: 50, whiteSpace: "nowrap", color: "white", backgroundColor: 'gray', fontWeight: 'bold', padding: "0px 5px", borderRadius: 3 }}>体温未報告</div>
                  <span style={{ marginLeft: 10, fontSize: 32, fontWeight: 'bold', color: 'gray' }}>{get未報告人数()}</span>
                  <span style={{ marginLeft: 5, fontSize: 20, fontWeight: 'bold', color: 'gray' }}>名</span>
                </div>
              </div>
            </CCol>
          </CRow>
        </div>

        <div style={{ margin: "5px 10px 0 10px", padding: "5px 5px 5px 5px ", backgroundColor: 'rgb(240,142,44)', maxWidth: 800 }}>
          <CSelect style={{ ...selectBoxStyle, verticalAlign: "middle", width: '50%' }} onChange={(event: React.ChangeEvent<HTMLFormElement>) => { setTeamId(Number(event.target.value)) }}>
            <option value={0} selected>すべての{THomeResponse.分類名}</option>
            {THomeResponse.teamList.map(e => <option key={e.id + "TeamOptions"} value={e.id}>{e.name}</option>)}
          </CSelect>
          <div style={{ display: 'inline-block', textAlign: 'right', marginLeft: 'auto', width: '50%' }}>
            <div style={{ display: 'inline-block', textAlign: 'right', marginLeft: 'auto', whiteSpace: 'nowrap' }}>
              <div style={{ marginLeft: 10 }}>
                <img src={LeftArrow} alt='LeftArrow'
                  height={34} style={{ marginRight: 3, display: 'inline-block' }}
                  className={!isTaionListDateIsAfterInitialDate(0) ? "image-grayout" : ""}
                  onClick={async (e) => {
                    e.preventDefault()
                    if (!isTaionListDateIsAfterInitialDate(0)) {
                      dispatch({ type: 'set', taionListDate: taionListResponse.initialDate })
                    } else {
                      await dispatch({ type: 'set', taionListDate: formatYyyyMMdd(subDays(new Date(taionListDate), 1)) })
                    }
                  }
                  } />
                <div style={{ height: 34, padding: "1px 15px", borderRadius: 3, verticalAlign: "middle", display: "inline-block", backgroundColor: "white", color: 'ash', fontWeight: "bold", fontSize: 20 }}>{taionListDate}</div>
                <img src={RightArrow} alt='RightArrow' height={34} style={{ marginLeft: 3, display: 'inline-block' }}
                  className={isTaionListDateIsTodayOrAfterToday(0) ? "image-grayout" : ""}
                  onClick={async (e) => {
                    e.preventDefault()
                    if (isTaionListDateIsTodayOrAfterToday(0)) {
                      dispatch({ type: 'set', taionListDate: formatYyyyMMdd(now) })
                    } else {
                      await dispatch({ type: 'set', taionListDate: formatYyyyMMdd(subDays(new Date(taionListDate), -1)) })
                    }
                  }} />
                <DatePicker
                  dateFormat="yyyy-MM-dd"
                  locale="ja"
                  popperPlacement="left"
                  selected={new Date(taionListDate)}
                  minDate={new Date(taionListResponse.initialDate)}
                  maxDate={now}
                  onChange={(date) => {
                    if (date && !Array.isArray(date)) {
                      dispatch({ type: 'set', taionListDate: formatYyyyMMdd(new Date(date)) })
                      dispatch({ type: 'set', taionListNextDates: [formatYyyyMMdd(now)] })
                    }
                  }}
                  customInput={<img src={Calendar} alt='Calendar' height={34} style={{ marginLeft: 5 }} />}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="slide-panel">
          <div style={{ overflowY: "auto" }}>
            <table className="ichiran-table">
              <thead>
                <tr className="ichiran-t-header">
                  <th className="ichiran-t-header-cell" onClick={(event) => { setSortMode("分類"); setOrder(!order) }}>{THomeResponse.分類名}</th>
                  <th className="ichiran-t-header-cell" onClick={(event) => { setSortMode("識別番号"); setOrder(!order) }}>{THomeResponse.識別番号名}</th>
                  <th className="ichiran-t-header-cell">名前</th>
                  <th className="ichiran-t-header-cell">性別</th>
                  <th className="ichiran-t-header-cell" onClick={(event) => { setSortMode("時刻"); setOrder(!order) }}>時刻</th>
                  <th className="ichiran-t-header-cell" onClick={(event) => { setSortMode("体温"); setOrder(!order) }}>体温</th>
                  <th className="ichiran-t-header-cell" onClick={(event) => { setSortMode("平熱差"); setOrder(!order) }}>平熱差</th>
                  <th className="ichiran-t-header-cell font-size-x-small"><div>計測</div><div>画像</div></th>
                </tr>
              </thead>
              <tbody>
                {TTaionSummaryResponse.items === undefined ? <></> : TTaionSummaryResponse.items.filter((ex) => ex.teamId === teamId || teamId === 0).sort(
                  (n1, n2) => (order ? 1 : -1) * sortFunction(n1, n2)
                ).map((e, i) =>
                  <tr key={i + "trIchiranCell"}>
                    <td className="ichiran-t-cell">{(THomeResponse.teamList.find(e2 => e2.id === e.teamId) || { name: "" }).name}</td>
                    <td className="ichiran-t-cell">{e.number}</td>
                    <td className="ichiran-t-cell"><span onClick={() => {
                      postToTTaionList({ studentId: e.studentId, 件数: 7, ページ: 1 }, (resonse) => {
                        if (resonse.result === RESPONSE_CODE.OK) {
                          toggle2.onClick()
                          setStudentId(e.studentId)
                        }
                      }
                      )(dispatch, setTTaionListResponse)
                    }} style={{ color: "blue", textDecoration: 'underline' }}>{e.name}</span></td>
                    <td className="ichiran-t-cell">{e.gender ? Number(e.gender) === 1 ? "男" : "女" : ""}</td>
                    <td className="ichiran-t-cell">{e.date === 0 || !e.date ? "-" : format('HH:mm')(new Date(e.date))}</td>
                    <td className="ichiran-t-cell" style={{
                      color: is体温表示レッド(e) ? "red" : "black"
                    }}>
                      {e.temperature === 0 ? "未" : e.temperature.toFixed(1) + "℃"}
                    </td>
                    <td className="ichiran-t-cell" style={{
                      color: is平熱差表示レッド(e) ? "red" : "black"
                    }}>{
                        e.temperature === 0 ? "-" :
                          e.regTempSampleCount && e.regTempSampleCount < 3 ? "算出未" :
                            (Number(e.diff) > 0 ? "+" : Number(e.diff) === 0 ? "±" : "") + Number(e.diff).toFixed(2)}
                    </td>
                    <td className="ichiran-t-cell">{
                      e.evidenceId === 0 ?
                        ""
                        :
                        <span onClick={() => {
                          setAnEvidenceId(e.evidenceId)
                          toggle.onClick()
                        }} style={{ color: "blue", textDecoration: 'underline' }}>○</span>
                    }</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <CButton color="secondary" style={{ margin: "5px 5px 5px 5px" }} onClick={() => {
            postToTLogout()(() => { })
            localStorage.removeItem(API_TOKEN.smallGroup)
            history.push("/t/login")
          }}>ログアウト</CButton>
        </div>

        <CModal show={toggle.value} onClose={toggle.onClick} className={'modal'} centered>
          <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
          </CModalHeader>
          <CModalBody style={{ display: "block", textAlign: "center" }}>
            <div className="effect">
              <img src={
                anEvidenceId === 0 ?
                  Camera
                  :
                  TTaionEvidenceURL + "?evidenceId=" + anEvidenceId
              } alt="evidence" />
            </div>
          </CModalBody>
          <CModalFooter style={{ display: "block", textAlign: "center" }}>
            <CButton size="lg" onClick={(e: React.MouseEvent<HTMLFormElement>) => { toggle.onClick() }}>戻る</CButton>
          </CModalFooter>
        </CModal>

        <CModal show={toggle2.value} onClose={toggle2.onClick} className={'modal'} closeOnBackdrop={false} centered>
          <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
          </CModalHeader>
          <CModalBody style={{ display: "block", textAlign: "center" }}>
            <div style={{ margin: "5px 0 0 0", padding: "5px 0 5px 0 ", backgroundColor: 'rgb(240,142,44)' }}>
              <CInput type="text" style={{ width: "200px", display: 'inline' }} value=
                {(TTaionSummaryResponse.items.find(e => e.studentId === studentId ? e.name : '') || { name: "" }).name}
              />
              <div style={{ display: 'inline-block', textAlign: 'right', marginLeft: 'auto' }}>
                <img src={LeftArrow} alt='LeftArrow' height={34} style={{ marginLeft: 60 }}
                  className={TTaionListResponse.nextPage === 0 ? "image-grayout" : ""}
                  onClick={async (e) => {
                    e.preventDefault()
                    if (TTaionListResponse.nextPage === 0) {
                    } else {
                      postToTTaionList({ studentId: studentId, ページ: TTaionListResponse.nextPage, 件数: memberDto.graphDisplayDays }, (response) => {
                      })(dispatch, setTTaionListResponse)
                    }
                  }
                  } />
                <img src={RightArrow} alt='RightArrow' height={34} style={{ marginLeft: 5 }}
                  className={TTaionListResponse.previousPage === 0 ? "image-grayout" : ""}
                  onClick={async (e) => {
                    e.preventDefault()
                    if (TTaionListResponse.previousPage === 0) {
                    } else {
                      postToTTaionList({ studentId: studentId, ページ: TTaionListResponse.previousPage, 件数: memberDto.graphDisplayDays }, (response) => {
                      })(dispatch, setTTaionListResponse)
                    }
                  }} />
                <DatePicker
                  dateFormat="yyyy-MM-dd"
                  locale="ja"
                  popperPlacement="left"
                  selected={new Date(taionListDate)}
                  minDate={new Date(TTaionListResponse.initialDate)}
                  maxDate={now}
                  onChange={(date) => {
                    if (date && !Array.isArray(date)) {
                      dispatch({ type: 'set', taionListDate: formatYyyyMMdd(new Date(date)) })
                      postToTTaionList({ studentId: studentId, date: formatYyyyMMdd(new Date(date)), 件数: memberDto.graphDisplayDays }, (response) => {
                      })(dispatch, setTTaionListResponse)
                    }
                  }}
                  customInput={<img src={Calendar} alt='Calendar' height={34} style={{ marginLeft: 5 }} />}
                />
              </div>
            </div>

            <Slider {...settings1}>
              <div>
                <CChart type="line" datasets={line.datasets} options={
                  {
                    legend: {
                      labels: {
                        boxWidth: 15
                      }
                    },
                    animation: undefined,
                    maintainAspectRatio: false
                  }
                } labels={line.labels} style={{ height: adjustedGraghHeight() }} />
              </div>
              <div>
                <table className="ichiran-table">
                  <thead>
                    <tr className="ichiran-header">
                      <th className="ichiran-header-cell">日付</th>
                      <th className="ichiran-header-cell">時間</th>
                      <th className="ichiran-header-cell">体温(℃)</th>
                      <th className="ichiran-header-cell">平熱(℃)</th>
                      <th className="ichiran-header-cell">平熱差(℃)</th>
                      <th className="ichiran-header-cell font-size-x-small"><div>エビデンス</div><div>画像</div></th>
                    </tr>
                  </thead>
                  <tbody>
                    {taionListData.slice(0, adjustedIchiranListNumbers()).map((e, i) =>
                      <tr key={i + "trIchiranCell"}>
                        <td className="ichiran-cell">{format('M/d')(new Date(e.date))}</td>
                        <td className="ichiran-cell">{format('HH:mm')(new Date(e.date))}</td>
                        <td className="ichiran-cell">{e.temperature}</td>
                        <td className="ichiran-cell">{e.regTemp}</td>
                        <td className="ichiran-cell">{e.diff}</td>
                        <td className="ichiran-cell">{
                          e.evidenceId === 0 ?
                            "なし"
                            :
                            <span onClick={() => {
                              setAnEvidenceId(e.evidenceId)
                              toggle.onClick()
                            }} style={{ color: "blue" }}>あり</span>
                        }</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Slider>
          </CModalBody>
          <CModalFooter style={{ display: "block", textAlign: "center" }}>
            <CButton size="lg" onClick={(e: React.MouseEvent<HTMLFormElement>) => { toggle2.onClick() }}>戻る</CButton>
          </CModalFooter>
        </CModal>

        <CModal show={toggle3.value} onClose={toggle3.onClick} className={'modal'} centered>
          <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
          </CModalHeader>
          <CModalBody style={{ display: "block", textAlign: "center" }}>
            対象{THomeResponse.所属名}切り替え
            <br />
            <br />
            {THomeResponse.所属名}：
            <CSelect style={selectBoxBorderedStyle} onChange={(event: React.ChangeEvent<HTMLFormElement>) => {
              setDepartmentId(event.target.value)
              setTeamId(0)
            }}>
              {THomeResponse.departmentList.map(e => <option key={e.id + "DepartmentOptions"} value={e.id}>{e.name}</option>)}
            </CSelect>
            <br />
            <br />
            <br />
          </CModalBody>
          <CModalFooter style={{ display: "block", textAlign: "center" }}>
            <CButton size="lg" color='info' onClick={() => {
              postToTTaionSummary({ date: taionListDate, departmentId: departmentId }, () => {
              })(dispatch, setTTaionSummaryResponse)
              toggle3.onClick()
            }}>切　替</CButton>
            <CButton size="lg" onClick={toggle3.onClick}>戻る</CButton>
          </CModalFooter>
        </CModal>

      </div>
    </div>
  )
}

const lineBuilder = (taionDtos: Array<TaionDto>) => {
  const labels = taionDtos.map(e => e.date)
  const temperatures = taionDtos.map(e => e.temperature)
  const regTemps = taionDtos.map(e => e.regTemp)
  return {
    labels: labels.map(e => format('M/d')(new Date(e))),
    datasets: [
      {
        label: '体温',
        fill: false,
        lineTension: 0.1,
        backgroundColor: 'rgb(61,191,240)',
        borderColor: 'rgb(61,191,240)',
        borderCapStyle: 'butt' as 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter' as 'miter',
        pointBorderColor: 'rgb(61,191,240)',
        pointBackgroundColor: '#fff',
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: 'rgb(61,191,240)',
        pointHoverBorderColor: 'rgb(61,191,240)',
        pointHoverBorderWidth: 2,
        pointRadius: 1,
        pointHitRadius: 10,
        data: temperatures,
      },
      {
        label: '平熱',
        fill: false,
        lineTension: 0.1,
        backgroundColor: 'rgba(240,142,44,0.4)',
        borderColor: 'rgba(240,142,44,1)',
        borderCapStyle: 'butt' as 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter' as 'miter',
        pointBorderColor: 'rgba(240,142,44,1)',
        pointBackgroundColor: '#fff',
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: 'rgba(240,142,44,1)',
        pointHoverBorderColor: 'rgba(220,220,220,1)',
        pointHoverBorderWidth: 2,
        pointRadius: 1,
        pointHitRadius: 10,
        data: regTemps,
      },
    ],
  }
}

const settings1 = {
  className: "slider standard",
  infinite: false,
  centerMode: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  variableWidth: false,
}


export default TDashboard
