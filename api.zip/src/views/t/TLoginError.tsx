import React from 'react';
import { useHistory } from 'react-router-dom'
import OkButton from '../../assets/img/personal/14_OK_gray.png'

const TLoginError = () => {
  const history = useHistory()

  const onOkClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault()
    history.push("/t/login")
  }

  return (
    <>
      <h4 className="cardtitle">ログインエラー</h4>
      <div className="maintext">
        入力された法人コード・ID・パ<br />
        スワードが正しくありません。<br />
        確認のうえ、入力をやり直してください。<br />
      </div>
      <div className="primarybutton" onClick={(event) => onOkClick(event)}>
        <img src={OkButton} width={"100%"} alt='ok' />
      </div>
    </>
  )
}

export default TLoginError
