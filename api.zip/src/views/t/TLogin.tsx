import React, { useState, useRef } from 'react';
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { postToTLogin } from '../../network/api/tLogin'
import { RESPONSE_CODE } from '../../network/BasicResponse'
import { useTypedSelector } from '../../store'
import { API_TOKEN, LOGIN_STATUS_IS_VALID } from "../../constants/Localstorage"
import LoginButton from '../../assets/img/personal/14_login.png'
import VPLogo from '../../assets/img/corporate/14_VP_logo.png'

const TLogin = () => {
  const history = useHistory()
  const dispatch = useDispatch()

  const useInput = (initialValue: string) => {
    const [value, set] = useState(initialValue)
    return { value, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { if (e && e.target) set(e.target.value) } }
  }
  const tLoginHojinCode = useTypedSelector((state) => state.tLoginHojinCode)
  const tLoginId = useTypedSelector((state) => state.tLoginId)
  const password = useInput("")
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }

  const onClickLogin = async (e: React.MouseEvent<HTMLDivElement>) => {
    await e.preventDefault()
    await onLogin()
  }

  const onLogin = async () => {

    const parameters = {
      hojinCode: tLoginHojinCode,
      id: tLoginId,
      password: password.value,
    }

    await postToTLogin(parameters,
      async (response) => {
        if (response.result === RESPONSE_CODE.OK) {
          await localStorage.setItem(API_TOKEN.smallGroup, LOGIN_STATUS_IS_VALID)
          await history.push("/t/dashboard")
        } else {
          await history.push("/t/login_error")
        }
      }
    )(() => { })

  }

  const passwordRef = useRef<HTMLInputElement>(null)
  const hojinCodeRef = useRef<HTMLInputElement>(null)
  const ENTER = 13

  const onHojinCodeKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER) {
      if (passwordRef && passwordRef.current) {
        passwordRef.current.focus()
      }
    }
  }

  const onIdKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER) {
      if (hojinCodeRef && hojinCodeRef.current) {
        hojinCodeRef.current.focus()
      }
    }
  }


  const onPasswordKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER) {
      onLogin()
    }
  }

  return (
    <>
      <h4 className="cardtitle" style={{ marginTop: 40 }}>体温アラート管理 ログイン</h4>
      <CForm action="" method="post" onSubmit={handleSubmit}>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="hojinCode"
            id="nf-hojinCode"
            name="nf-hojinCode"
            placeholder="法人コード"
            autoComplete="hojinCode"
            value={tLoginHojinCode}
            onChange={(ev: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', tLoginHojinCode: ev.target.value })}
            onKeyDown={onHojinCodeKeyDown}
          />
        </CFormGroup>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="id"
            id="nf-id"
            name="nf-id"
            placeholder="ID"
            autoComplete="id"
            value={tLoginId}
            onChange={(ev: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', tLoginId: ev.target.value })}
            onKeyDown={onIdKeyDown}
          />
        </CFormGroup>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="password"
            id="nf-password"
            name="nf-password"
            placeholder="パスワード"
            autoComplete="current-password"
            onKeyDown={onPasswordKeyDown}
            {...password}
          />
        </CFormGroup>
      </CForm>
      <div className="primarybutton" onClick={(event) => onClickLogin(event)}>
        <img src={LoginButton} width={"100%"} alt='Logo' />
      </div>
      <div className="centered" style={{ marginTop: 20 }}>
        <img src={VPLogo} width={"40%"} alt="logo" />
      </div>
      {/*
      <div className="centered" style={{ marginTop: 10 }}>
        Vital Passport inc.
      </div>
      */}
    </>
  )
}

export default TLogin
