import React, { useEffect, useState } from 'react'
import { useDispatch } from "react-redux"

import { useTypedSelector } from '../../store'
import { SHeader } from './SHeader'

//import 承認除外 from '../../assets/img/corporate/14_kanri_clear.png'
//import 承認申請 from '../../assets/img/corporate/14_kanri_search.png'
import クリア from '../../assets/img/corporate/14_kanri_clear.png'
import 検索 from '../../assets/img/corporate/14_kanri_search.png'
import 保存 from '../../assets/img/corporate/14_kanri_save.png'
import 戻る from '../../assets/img/personal/14_back.png'
import { CRow, CCol, CModal, CModalHeader, CModalBody, CModalFooter, CButton } from '@coreui/react'
import { postToSHome } from '../../network/api/sHome'
import { postToSAffiliationList, SAffiliationListResponseZero } from '../../network/api/sAffiliationList'
import { postToSAffiApply } from '../../network/api/sAffiApply'
import { postToSStudentList, SStudentListResponseZero } from '../../network/api/sStudentList'
import { postToSStudentCreate } from '../../network/api/sStudentCreate'
import { postToSStudentEdit } from '../../network/api/sStudentEdit'
import { useToggle } from '../../tools/useToggle'
import { AffiliationDto } from '../../network/api/dto/AffiliationDto'
import { format } from 'date-fns/fp'
import { AffiliationDtoZero } from '../../network/api/dto/AffiliationDto'
import { IdNameDtoZero } from '../../network/api/dto/IdNameDto'
import { StudentListDtoZero } from '../../network/api/dto/StudentListDto'
//import { registerLocale } from 'react-datepicker'
const format年月日 = format("yyyy年MM月dd日")
const format日時分 = format("yyyy/MM/dd H:mm")

const pad = (n: string, size: number) => { //パクリ
  let s = n + ""
  while (s.length < size) s = "0" + s
  return s
}

const pad2 = (n: number, size: number) => { //パクリ
  let s = n + ""
  while (s.length < size) s = "0" + s
  return s
}

const SAffiliation = () => {
  const dispatch = useDispatch()
  const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)
  const [SAffiliationListResponse, setSAffiliationListResponse] = useState(SAffiliationListResponseZero)
  const [SStudentListResponse, setSStudentListResponse] = useState(SStudentListResponseZero)
  //const [SStudentDetailResponse, setSStudentDetailResponse] = useState(SStudentDetailResponseZero)

  const [検索用指定ページ, set検索用指定ページ] = useState(1)
  const [検索用件数, set検索用件数] = useState(20)

  const [検索用未承認, set検索用未承認] = useState(true)
  const [検索用承認済み24時間以内, set検索用承認済み24時間以内] = useState(true)
  const [検索用承認済み全て, set検索用承認済み全て] = useState(false)
  const [検索用承認除外, set検索用承認除外] = useState(false)

  const [年, set年] = useState(2021)
  const [月, set月] = useState(1)
  const [日, set日] = useState(1)
  const [上限年, set上限年] = useState(format("yyyy")(new Date()))
  const [上限月, set上限月] = useState(format("M")(new Date()))
  const [上限日, set上限日] = useState(format("dd")(new Date()))

  const [誕生日絞り込みなし, set誕生日絞り込みなし] = useState(false)

  const [承認用所属, set承認用所属] = useState(0)
  const [承認用体温管理対象, set承認用体温管理対象] = useState(0)
  const [承認用連携ID, set承認用連携ID] = useState(0)

  const [検索用所属, set検索用所属] = useState(0)

  const [識別番号, set識別番号] = useState("")
  const [氏名, set氏名] = useState("")
  const [所属, set所属] = useState("0")
  const [分類, set分類] = useState("0")
  const [性別, set性別] = useState(1)
  const [電話番号, set電話番号] = useState("")
  const [非表示, set非表示] = useState(false)
  const [在籍なし, set在籍なし] = useState(false)
  const [連携解除, set連携解除] = useState(false)

  //const [studentId, setStudentId] = useState(0)
  const toggle = useToggle(false)
  const toggle2 = useToggle(false)

  const 申請日From = 年 + "-" + pad2(月, 2) + "-" + pad2(日, 2)
  const 申請日To = 上限年 + "-" + pad(上限月, 2) + "-" + pad(上限日, 2)

  const 申請対象 = SAffiliationListResponse.items.find(e => e.affiliationId === 承認用連携ID) || AffiliationDtoZero

  const 承認区分 = (n: number) =>
    n === 0 ? "承認未" :
      n === 1 ? "連携中" :
        n === 2 ? "承認除外" :
          n === 3 ? "連携解除済み" : ""

  useEffect(() => {
    postToSHome({}, (response) => {
      dispatch({ type: 'set', sHomeResponse: response })
    })(dispatch)

    postToSStudentList({ 件数: 1000000, ページ: 1, 在籍無し: false }, () => { })(dispatch, setSStudentListResponse)

    postToSAffiliationList({
      未承認: true,
      承認済み24時間以内: true,
      承認済み: false,
      承認除外: false,
      申請日From: '2021-01-01',
      申請日To: format("yyyy-MM-dd")(new Date()),
      件数: 検索用件数,
      ページ: 検索用指定ページ
    }, (response) => {
      //set承認用連携ID(((response.items && response.items.find(e => e.status === 0)) || AffiliationDtoZero).affiliationId)
    })(dispatch, setSAffiliationListResponse)
  }, [dispatch, 検索用件数, 検索用指定ページ])

  const reload = () => {
    postToSAffiliationList({
      未承認: 検索用未承認,
      承認済み24時間以内: 検索用承認済み24時間以内,
      承認済み: 検索用承認済み全て,
      承認除外: 検索用承認除外,
      申請日From: 申請日From,
      申請日To: 申請日To,
      件数: 検索用件数,
      ページ: 検索用指定ページ
    }, () => { })(dispatch, setSAffiliationListResponse)
  }

  const onクリアClick = () => {
    set検索用指定ページ(1)
    set検索用件数(20)

    set検索用未承認(true)
    set検索用承認済み24時間以内(true)
    set検索用承認済み全て(false)
    set検索用承認除外(false)

    set年(2021)
    set月(1)
    set日(1)
    set上限年(format("yyyy")(new Date()))
    set上限月(format("M")(new Date()))
    set上限日(format("dd")(new Date()))
  }

  const on選択Click = async (affiliationDto: AffiliationDto) => {
    if (承認用連携ID === affiliationDto.affiliationId) {
      set承認用連携ID(0)
      set承認用所属(0)
      set承認用体温管理対象(0)
    } else {
      set承認用連携ID(affiliationDto.affiliationId)
      set承認用所属(affiliationDto.departmentId)
      const 管理対象 = SStudentListResponse.items
        .filter(e => e.departmentId === 承認用所属 || 承認用所属 === 0)
        .find(e2 => 誕生月日同一判定(e2.生年月日, "2000-" + affiliationDto.birthMonth + "-" + affiliationDto.birthDay)) || StudentListDtoZero
      set承認用体温管理対象(管理対象.studentId)
    }
  }

  const on保存Click = () => {
    postToSStudentEdit(
      {
        //studentId: studentId,
        studentId: 0,
        insideNo: 識別番号,
        name: 氏名,
        departmentId: Number(所属),
        teamId: Number(分類),
        gender: Number(性別), // 1: 男性, 2: 女性, 3: その他
        birth: 上限年 + "-" + 上限月 + "-" + 上限日, //"yyyy-mm-dd"
        tel: 電話番号,
        hidden: 非表示,
        retired: 在籍なし,
        連結解除実行: 連携解除,
      },
      (response) => {
        if (response.result === "OK") {
          toggle.onClick()
          //postToSStudentList({ 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
        }
      }
    )(dispatch)
  }

  const 誕生月日同一判定 = (s1: string, s2: string) => {
    const s1d = new Date(s1)
    const s2d = new Date(s2)
    return (s1d.getDate() === s2d.getDate() && s1d.getMonth() === s2d.getMonth()) || 誕生日絞り込みなし
  }

  const on新規追加保存Click = () => {
    postToSStudentCreate(
      {
        insideNo: 識別番号,
        name: 氏名,
        departmentId: Number(所属),
        teamId: Number(分類),
        gender: Number(性別), // 1: 男性, 2: 女性, 3: その他
        birth: 上限年 + "-" + 上限月 + "-" + 上限日, //"yyyy-mm-dd"
        tel: 電話番号,
      },
      (response) => {
        if (response.result === "OK") {
          toggle2.onClick()
          //postToSStudentList({ 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
        }
      }
    )(dispatch)
  }

  const yearOptions = (n: number) => Array.from(Array(3000).keys()).filter(e => e >= 2021 && e <= new Date().getFullYear()).map(e => <option value={e} key={n + "year-" + e}>{e}</option>)
  const monthOptions = (n: number) => Array.from(Array(13).keys()).filter(e => e).map(e => <option value={e} key={n + "month-" + e}>{e}</option>)
  const dayOptions = (n: number) => Array.from(Array(32).keys()).filter(e => e).map(e => <option value={e} key={n + "day-" + e}>{e}</option>)

  const 検索用最終ページ = Math.floor(SAffiliationListResponse.count % 検索用件数 === 0 ? SAffiliationListResponse.count / 検索用件数 : (SAffiliationListResponse.count / 検索用件数) + 1)
  const pageNumbers = Array.from(Array(検索用最終ページ + 1).keys()).filter(e => e >= 1 && e <= 検索用最終ページ)
  const pages = (n: number) => pageNumbers.reduce((acc, current, i) => {
    if (current === 1) return [...acc, current]
    if ((current >= (検索用指定ページ - 2)) && (current <= (検索用指定ページ + 2))) return [...acc, current]
    if (current === 検索用最終ページ) return [...acc, current]
    if (acc.slice(-1)[0] === "…" || acc.slice(-1)[0] === undefined) return [...acc]
    return [...acc, "…"]
  }, [] as Array<number | string>).map((e, i) => <span key={"pageoptions" + i} style={e === 検索用指定ページ || isNaN(Number(e)) ? { color: 'black' } : { color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { if (!isNaN(Number(e))) { set検索用指定ページ(Number(e)) } }}>{e} </span>)
  const 前のX件 = 検索用指定ページ <= 1 ? <></> : <span style={{ color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { set検索用指定ページ(検索用指定ページ - 1) }} >前の{検索用件数}件</span>
  const 次のX件 = 検索用最終ページ <= 検索用指定ページ ? <></> : <span style={{ color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { set検索用指定ページ(検索用指定ページ + 1) }} >次の{検索用件数}件</span>

  return (
    <>
      <SHeader />
      <div className="title-band">データ連携申請 承認</div>
      <div style={{ padding: "0 20px 20px 20px", backgroundColor: "rgb(241, 241, 241)" }}>
        <div style={{ width: "80%", backgroundColor: "rgb(214, 214, 214)", margin: "auto" }}>
          <div style={{ textAlign: "right" }}>
            <CRow style={{ paddingTop: 20 }}>
              <CCol xs="2" style={{ textAlign: "right", padding: "10px 20px 10px 50px", whiteSpace: 'nowrap' }}>
                <span style={{ fontWeight: 'bold' }}>承認区分</span>
              </CCol>
              <CCol style={{ textAlign: "left", padding: "10px 20px 10px 50px", whiteSpace: 'nowrap' }}>
                <input type="checkbox" style={{ marginLeft: '20px' }} checked={検索用未承認} onChange={() => { set検索用未承認(!検索用未承認) }} />未承認
                <input type="checkbox" style={{ marginLeft: '20px' }} checked={検索用承認済み24時間以内}
                  onChange={() => {
                    if (set検索用承認済み全て) set検索用承認済み全て(false)
                    set検索用承認済み24時間以内(!検索用承認済み24時間以内)
                  }} />承認済み(24時間以内)
                <input type="checkbox" style={{ marginLeft: '20px' }} checked={検索用承認済み全て}
                  onChange={() => {
                    if (検索用承認済み24時間以内) set検索用承認済み24時間以内(false)
                    set検索用承認済み全て(!検索用承認済み全て)
                  }} />承認済み(すべて)
                <input type="checkbox" style={{ marginLeft: '20px' }} checked={検索用承認除外} onChange={() => { set検索用承認除外(!検索用承認除外) }} />承認除外
              </CCol>
            </CRow>
            <CRow style={{ paddingTop: 0 }}>
              <CCol xs="2" style={{ textAlign: "right", padding: "10px 20px 20px 50px", whiteSpace: 'nowrap' }}>
                <span style={{ fontWeight: 'bold' }}>申請日</span>
              </CCol>
              <CCol style={{ textAlign: "center", padding: "10px 20px 20px 20px", whiteSpace: 'nowrap' }}>
                <div style={{ margin: '0 auto 0 auto' }}>
                  <select value={年} onChange={(e) => { set年(Number(e.target.value)) }}>{yearOptions(1)}</select>年
                  <select value={月} onChange={(e) => { set月(Number(e.target.value)) }}>{monthOptions(2)}</select>月
                  <select value={日} onChange={(e) => { set日(Number(e.target.value)) }}>{dayOptions(3)}</select>日
                  ～
                  <select value={上限年} onChange={(e) => { set上限年(e.target.value) }}>{yearOptions(1)}</select>年
                  <select value={上限月} onChange={(e) => { set上限月(e.target.value) }}>{monthOptions(2)}</select>月
                  <select value={上限日} onChange={(e) => { set上限日(e.target.value) }}>{dayOptions(3)}</select>日
                </div>
              </CCol>
            </CRow>
            <CRow style={{ marginTop: 10 }}>
              <CCol xs="4">
              </CCol>
              <CCol xs="4" style={{ textAlign: 'center' }} >
                <img src={検索} alt="検索" onClick={() => { reload() }} />
              </CCol>
              <CCol xs="4">
                <img src={クリア} alt="クリア" style={{ textAlign: 'right', margin: "0 10px 10px 0" }} onClick={() => { onクリアClick() }} />
              </CCol>
            </CRow>
          </div>
        </div>
        <div style={{ verticalAlign: "middle", fontWeight: 'bold', fontSize: 18, marginTop: 20, minHeight: 400, padding: 10, backgroundColor: "white" }}>
          <div style={{ float: "left" }}>
            <span style={{ marginRight: 20 }}>データ連携申請一覧</span>
            {SHomeResponse.client.所属名}：
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用所属(Number(e.target.value)) }} value={検索用所属}>
              <option value="0">すべて</option>
              {SHomeResponse.クラスList.map(
                e => <option value={e.id}>{e.name}</option>
              )}
            </select>
          </div>
          <div style={{ float: "right" }}>
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用件数(Number(e.target.value)); reload() }} value={検索用件数}>
              <option value="10">10件</option>
              <option value="20">20件</option>
              <option value="50">50件</option>
            </select>
            <span>
              全{SAffiliationListResponse.count}件中 {SAffiliationListResponse.count === 0 ? 0 : (検索用指定ページ * 検索用件数) - 検索用件数 + 1}-{検索用指定ページ * 検索用件数 >= SAffiliationListResponse.count ? SAffiliationListResponse.count : 検索用指定ページ * 検索用件数}件を表示中 {前のX件} {pages(1)} {次のX件}
            </span>
          </div>
          <table className="ichiran-table">
            <thead>
              <tr className="ichiran-header">
                <th className="ichiran-header-cell-nodecoration" rowSpan={2}></th>
                <th className="ichiran-header-cell" colSpan={3}>データ連携者申請 入力情報</th>
                <th className="ichiran-header-cell" rowSpan={2}>申請日時</th>
                <th className="ichiran-header-cell" rowSpan={2}>承認区分</th>
                <th className="ichiran-header-cell" rowSpan={2}>承認日時</th>
                <th className="ichiran-header-cell" colSpan={3}>紐付けマスターデータ</th>
              </tr>
              <tr className="ichiran-header">
                <th className="ichiran-header-cell">{SHomeResponse.client.所属名}</th>
                <th className="ichiran-header-cell">名前</th>
                <th className="ichiran-header-cell">誕生日</th>
                <th className="ichiran-header-cell">{SHomeResponse.client.識別番号名}</th>
                <th className="ichiran-header-cell">氏名</th>
                <th className="ichiran-header-cell">生年月日</th>
              </tr>
            </thead>
            <tbody>
              {SAffiliationListResponse.items.filter(e => e.departmentId === Number(検索用所属) || Number(検索用所属) === 0).map((e, i) =>
                <tr key={i + "trIchiranCell"}>
                  <td className="ichiran-cell-nodecoration cursored" style={e.affiliationId === 承認用連携ID ? { backgroundColor: "orange" } : {}} onClick={() => on選択Click(e)}><span className='cursored'>選択</span></td>
                  <td className="ichiran-cell">{(SAffiliationListResponse.クラスList.find(ex => ex.id === e.departmentId) || IdNameDtoZero).name}</td>
                  <td className="ichiran-cell">{e.name}</td>
                  <td className="ichiran-cell">{e.birthMonth + "月" + e.birthDay + "日"}</td>
                  <td className="ichiran-cell">{format日時分(e.createdAt)}</td>
                  <td className="ichiran-cell">{承認区分(e.status)}</td>
                  <td className="ichiran-cell">
                    {
                      e.deniedAt ?
                        format日時分(e.deniedAt) : e.acceptedAt ?
                          format日時分(e.acceptedAt) : ""
                    }
                  </td>
                  <td className="ichiran-cell">{e.student ? e.student.insideNo : "-"}</td>
                  <td className="ichiran-cell">{e.student ? e.student.name : "-"}</td>
                  <td className="ichiran-cell">{e.student && e.student.birth ? format年月日(new Date(e.student.birth)) : "-"}</td>
                </tr>
              )}
            </tbody>
          </table>
          <CRow style={{ marginTop: 10 }}>
            <CCol xs="3">
              ＜申請者＞
            </CCol>
            <CCol style={{ textAlign: 'left' }} >
              {SHomeResponse.client.所属名}: {(SAffiliationListResponse.クラスList.find(ex => ex.id === 申請対象.departmentId) || IdNameDtoZero).name} 　　名前: {申請対象.name}　　誕生日: {申請対象.birthDay === 0 && 申請対象.birthMonth === 0 ? <></> : <>{申請対象.birthMonth}月{申請対象.birthDay}日</>}
            </CCol>
          </CRow>
          {/*
          <CRow style={{ marginTop: 10 }}>
            <CCol xs="4">
              ＜生徒マスター 紐付け＞
            </CCol>
            <CCol style={{ textAlign: 'right' }} >
              <CButton color="info">マスタを新規追加して紐付け</CButton>
            </CCol>
          </CRow>
          */}
          <CRow style={{ marginTop: 10, textAlign: 'right' }}>
            <CCol xs="4">
              {SHomeResponse.client.所属名}
            </CCol>
            <CCol style={{ textAlign: 'left' }} >
              <select style={{ marginRight: 20 }} onChange={(e) => { set承認用所属(Number(e.target.value)) }} value={承認用所属}>
                <option value="0">すべての{SHomeResponse.client.所属名}</option>
                {SHomeResponse.クラスList.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow style={{ marginTop: 10, textAlign: 'right' }}>
            <CCol xs="4">
              {SHomeResponse.client.体温管理対象呼称}選択
            </CCol>
            <CCol style={{ textAlign: 'left' }} >
              <select style={{ marginRight: 20 }} onChange={(e) => { set承認用体温管理対象(Number(e.target.value)) }} value={承認用体温管理対象}>
                <option value="0">{SHomeResponse.client.体温管理対象呼称}未選択</option>
                {SStudentListResponse.items
                  .filter(e => e.departmentId === 承認用所属 || 承認用所属 === 0)
                  .filter(e2 => 誕生月日同一判定(e2.生年月日, "2000-" + 申請対象.birthMonth + "-" + 申請対象.birthDay)).map(
                    e => <option value={e.studentId}>{e.生徒番号} - {e.クラス} - {e.氏名}({e.生年月日})</option>
                  )}
              </select>
              <input type="checkbox" style={{ marginLeft: '20px' }} checked={誕生日絞り込みなし} onChange={() => { set誕生日絞り込みなし(!誕生日絞り込みなし) }} />誕生日絞り込みなし
              <br />
              <span style={{ fontWeight: 'normal', fontSize: '12px' }}>({SHomeResponse.client.識別番号名} - {SHomeResponse.client.所属名} - 氏名(生年月日))</span>
            </CCol>
          </CRow>
          <CRow style={{ marginTop: 10 }}>
            <CCol xs="4">
              <CButton color="secondary" disabled={申請対象.status !== 0 || 申請対象.affiliationId === 0 || 承認用体温管理対象 === 0} onClick={() => {
                postToSAffiApply({
                  status: 申請対象.status === 0 ? 2 : 申請対象.status, // 1:連携中にする / 2:承認除外にする / 3:連携解除済みにする
                  affiliationId: 承認用連携ID,
                  studentId: 申請対象.studentId,
                }, (response) => { if (response.result === "OK" as "OK") reload() })(dispatch)
              }}>承認除外</CButton>
            </CCol>
            <CCol xs="4" style={{ textAlign: 'center' }} >
              <CButton color="info" size="lg" disabled={
                !(申請対象.status === 0 || 申請対象.status === 2)
                || 申請対象.affiliationId === 0
                || 承認用体温管理対象 === 0
              } onClick={() => {
                postToSAffiApply({
                  status: 申請対象.status === 0 ? 1 : 申請対象.status, // 1:連携中にする / 2:承認除外にする / 3:連携解除済みにする
                  affiliationId: 承認用連携ID,
                  studentId: 承認用体温管理対象,
                }, (response) => { if (response.result === "OK" as "OK") reload() })(dispatch)
              }}
              ><span style={{ fontSize: 24 }}>申請承認</span><br />(マスター紐付け)</CButton>
            </CCol>
            <CCol xs="4">
            </CCol>
          </CRow>
        </div>
      </div>


      <CModal show={toggle2.value} onClose={toggle2.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div className="title-band">{SHomeResponse.client.体温管理対象呼称}マスター追加</div>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.識別番号名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={識別番号} onChange={(e) => { set識別番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">氏　名</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={氏名} onChange={(e) => { set氏名(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.所属名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set所属(e.target.value) }} value={所属}>
                <option value="0">未指定</option>
                {SHomeResponse.クラスList.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.分類名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set分類(e.target.value) }} value={分類}>
                <option value="0">未指定</option>
                {SHomeResponse.班List.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">性別</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="radio" name="性別" checked={性別 === 1} value="1" onChange={(e) => { set性別(Number(e.target.value)) }} />男 <input type="radio" name="性別" checked={性別 === 2} value="2" onChange={(e) => { set性別(Number(e.target.value)) }} />女</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">携帯電話番号</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={電話番号} onChange={(e) => { set電話番号(e.target.value) }} /></CCol>
          </CRow>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CRow>
            <CCol>
              <img src={戻る} alt="戻る" style={{ textAlign: 'right', margin: "0 20px 0 0", height: 40 }} onClick={(e) => { toggle2.onClick() }} />
              <img src={保存} alt="保存" style={{ height: 40 }} onClick={on新規追加保存Click} />
            </CCol>
          </CRow>
        </CModalFooter>
      </CModal>

      <CModal show={toggle.value} onClose={toggle.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div className="title-band">{SHomeResponse.client.体温管理対象呼称}マスター編集</div>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.識別番号名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={識別番号} onChange={(e) => { set識別番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">氏　名</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={氏名} onChange={(e) => { set氏名(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.所属名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set所属(e.target.value) }} value={所属}>
                <option value="0">未指定</option>
                {SHomeResponse.クラスList.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.分類名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set分類(e.target.value) }} value={分類}>
                <option value="0">未指定</option>
                {SHomeResponse.班List.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">性別</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <form>
                <input type="radio" name="性別" value="1" defaultChecked={性別 === 1} onClick={() => { set性別(1) }} />男
                <input type="radio" name="性別" value="2" defaultChecked={性別 === 2} onClick={() => { set性別(2) }} />女
              </form>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">携帯電話番号</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={電話番号} onChange={(e) => { set電話番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">リスト表示</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={非表示} onChange={(e) => { set非表示(e.target.checked) }} />非表示</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">在籍</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={在籍なし} onChange={(e) => { set在籍なし(e.target.checked) }} />無し</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">体温データ連携</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={連携解除} onChange={(e) => { set連携解除(e.target.checked) }} />連携解除</CCol>
          </CRow>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CRow>
            <CCol>
              <img src={戻る} alt="戻る" style={{ textAlign: 'right', margin: "0 20px 0 0", height: 40 }} onClick={(e) => { toggle.onClick() }} />
              <img src={保存} alt="保存" style={{ height: 40 }} onClick={on保存Click} />
            </CCol>
          </CRow>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default SAffiliation
