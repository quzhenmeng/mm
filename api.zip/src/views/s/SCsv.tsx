import React, { useEffect, useState } from 'react'
import { useDispatch } from "react-redux"
import { useHistory } from 'react-router-dom'

//import { useTypedSelector } from '../../store'
import { SHeader } from './SHeader'

import 送信ボタン from '../../assets/img/personal/14_send.png'
import 戻る from '../../assets/img/personal/14_back.png'
import { CRow, CCol } from '@coreui/react'
import { postToSHome } from '../../network/api/sHome'
import { postToSStudentCsvUpload } from '../../network/api/sStudentCsvUpload'
import { useTypedSelector } from '../../store'

const SCsv = () => {
  const dispatch = useDispatch()
  const history = useHistory()
  //const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)
  const [携帯番号取り込みする, set携帯番号取り込みする] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState([] as unknown as FileList)
  const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)

  useEffect(() => {
    postToSHome({}, (response) => {
      dispatch({ type: 'set', SHomeResponse: response })
    })(dispatch)
  }, [dispatch])

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const onInputButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    if (selectedFiles.length === 0) {
      alert("取込みするCSVファイルを選択してください")
    } else {
      postToSStudentCsvUpload({ 携帯番号取込: 携帯番号取り込みする, file: selectedFiles[0] }, (response) => {
        dispatch({ type: 'set', sStudentCsvUploadResponse: response })
        if (response.result === "OK") history.push("/s/csv_completed")
      })(dispatch)
    }
  }

  return (
    <>
      <SHeader />
      <div className="title-band">CSVアップロード</div>
      <div style={{ padding: "10px 20px 20px 20px", backgroundColor: "rgb(241, 241, 241)" }}>
        <div style={{ width: "80%", backgroundColor: "rgb(214, 214, 214)", margin: "auto" }}>
          <div style={{ textAlign: "right" }}>
            <form>
              <CRow style={{ paddingTop: 20 }}>
                <CCol xs="3" style={{ textAlign: "right" }}>
                  ファイル選択：
                </CCol>
                <CCol xs="9" style={{ textAlign: "left" }}>
                  <input type="file" onChange={(event) => { if (event.target.files) setSelectedFiles(event.target.files) }} style={{ display: 'inline-block', width: '80%', backgroundColor: 'white' }} />
                </CCol>
              </CRow>
              {/* <CRow style={{ marginTop: 20 }}>
                  <CCol xs="6">
                    カ　ナ　<input type="text" style={{ display: 'inline-block', width: '300px' }} />
                  </CCol>
                  <CCol xs="6">
                  </CCol>
                  </CRow> */}
              <div style={{ borderBottom: "2px solid rgb(150,150,150)", margin: "20px 0 20px 0" }}></div>
              <div style={{ fontWeight: 'bold', textAlign: "left" }}>
                <div style={{ margin: '0 0 10px 20px' }}>●アップロードファイルについて</div>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>ファイル形式：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>カンマ区切り CSVファイル</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>文字コード：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>Shift-JIS</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>ヘッダー行：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>1行目をヘッダー行(項目名)としてください。<br />2行目以降をデータ行として取込みします。</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>データ行：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>
                    <CRow>
                      <CCol xs="3" style={{ textAlign: "right" }}>◇ 1項目目：</CCol>
                      <CCol xs="9">{SHomeResponse.client.識別番号名} ※必須</CCol>
                    </CRow>
                    <CRow>
                      <CCol xs="3" style={{ textAlign: "right" }}>◇ 2項目目：</CCol>
                      <CCol xs="9">氏名 ※必須</CCol>
                    </CRow>
                    <CRow>
                      <CCol xs="3" style={{ textAlign: "right" }}>◇ 3項目目：</CCol>
                      <CCol xs="9">生年月日 ※必須<br /><span style={{ fontWeight: 'normal' }}>「YYYY/MM/DD形式」または「YYYY-MM-DD形式」</span></CCol>
                    </CRow>
                    <CRow>
                      <CCol xs="3" style={{ textAlign: "right" }}>◇ 4項目目：</CCol>
                      <CCol xs="9">性別 ※必須
                        <br /><span style={{ fontWeight: 'normal' }}>男性 →「1」または「男」または「男性」</span>
                        <br /><span style={{ fontWeight: 'normal' }}>女性 →「2」または「女」または「女性」</span>
                      </CCol>
                    </CRow>
                    <CRow>
                      <CCol xs="3" style={{ textAlign: "right" }}>◇ 5項目目：</CCol>
                      <CCol xs="9">携帯番号 ※任意 <span style={{ color: 'crimson', marginLeft: 10 }}><input type="checkbox" onChange={(event) => set携帯番号取り込みする(event.target.checked)} checked={携帯番号取り込みする} />  携帯番号を取込みする</span>
                        <br /><span style={{ fontWeight: 'normal' }}>－(ハイフン)あり、無しとも可。</span>
                      </CCol>
                    </CRow>
                  </CCol>
                </CRow>

              </div>
              <CRow style={{ marginTop: 20 }}>
                <CCol xs="4">
                  <img src={戻る} alt="戻る" style={{ textAlign: 'right', margin: "0 0 20px 0", height: 61 }} onClick={onBackButtonClick} />
                </CCol>
                <CCol xs="4" style={{ textAlign: 'center' }} >
                  <img src={送信ボタン} alt="送信ボタン" style={{ height: 61 }} onClick={onInputButtonClick} />
                </CCol>
                <CCol xs="4">
                </CCol>
              </CRow>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default SCsv
