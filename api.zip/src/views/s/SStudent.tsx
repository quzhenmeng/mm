import React, { useEffect, useState } from 'react'
import { useDispatch } from "react-redux"

import { useTypedSelector } from '../../store'
import { SHeader } from './SHeader'

import CSVアップロード from '../../assets/img/corporate/14_kanri_CSV.png'
import 新規追加 from '../../assets/img/corporate/14_kanri_tsuika.png'
import クリア from '../../assets/img/corporate/14_kanri_clear.png'
import 検索 from '../../assets/img/corporate/14_kanri_search.png'
import 保存 from '../../assets/img/corporate/14_kanri_save.png'
import 戻る from '../../assets/img/personal/14_back.png'
import { CRow, CCol, CModal, CModalHeader, CModalBody, CModalFooter } from '@coreui/react'
import { postToSHome } from '../../network/api/sHome'
import { postToSStudentList, SStudentListResponseZero } from '../../network/api/sStudentList'
import { postToSStudentDetail } from '../../network/api/sStudentDetail'
import { postToSStudentCreate } from '../../network/api/sStudentCreate'
import { postToSStudentEdit } from '../../network/api/sStudentEdit'
import { Link } from 'react-router-dom'
import { useToggle } from '../../tools/useToggle'
import { StudentListDto } from '../../network/api/dto/StudentListDto'
import { format } from 'date-fns/fp'
//import { registerLocale } from 'react-datepicker'

const SStudent = () => {
  const dispatch = useDispatch()
  const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)
  const [SStudentListResponse, setSStudentListResponse] = useState(SStudentListResponseZero)
  //const [SStudentDetailResponse, setSStudentDetailResponse] = useState(SStudentDetailResponseZero)

  const [検索用指定ページ, set検索用指定ページ] = useState(1)
  const [検索用在籍無し, set検索用在籍無し] = useState(false)

  const [検索用識別番号, set検索用識別番号] = useState("")
  const [検索用氏名, set検索用氏名] = useState("")
  const [検索用所属, set検索用所属] = useState(0)
  const [検索用分類, set検索用分類] = useState(0)
  const [検索用件数, set検索用件数] = useState(50)
  const [検索用並び順, set検索用並び順] = useState("所属名")
  const [検索用昇順降順, set検索用昇順降順] = useState("昇順")

  const [識別番号, set識別番号] = useState("")
  const [氏名, set氏名] = useState("")
  const [所属, set所属] = useState("0")
  const [分類, set分類] = useState("0")
  const [性別, set性別] = useState(1)
  const [誕生年, set誕生年] = useState(2000)
  const [誕生月, set誕生月] = useState(1)
  const [誕生日, set誕生日] = useState(1)
  const [電話番号, set電話番号] = useState("")
  const [非表示, set非表示] = useState(false)
  const [在籍なし, set在籍なし] = useState(false)
  const [連携解除, set連携解除] = useState(false)


  const [studentId, setStudentId] = useState(0)
  const toggle = useToggle(false)
  const toggle2 = useToggle(false)

  useEffect(() => {
    postToSHome({}, (response) => {
      dispatch({ type: 'set', sHomeResponse: response })
    })(dispatch)

    postToSStudentList({ 並び順: 検索用並び順, 昇順降順: 検索用昇順降順, 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
  }, [dispatch, 検索用件数, 検索用指定ページ, 検索用在籍無し, 検索用並び順, 検索用昇順降順])

  const reload = () => {
    postToSStudentList({ 並び順: 検索用並び順, 昇順降順: 検索用昇順降順, 生徒番号: 検索用識別番号, 氏名: 検索用氏名, 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
  }

  const on編集Click = (student: StudentListDto) => {
    setStudentId(student.studentId)
    postToSStudentDetail({ studentId: student.studentId }, (response) => {
      const s = response.item
      const year = s.birth ? format("yyyy")(new Date(s.birth)) : 2000
      const month = s.birth ? format("MM")(new Date(s.birth)) : 1
      const date = s.birth ? format("dd")(new Date(s.birth)) : 1
      set識別番号(s.insideNo)
      set氏名(s.name)
      set所属(s.departmentId.toString())
      set分類(s.teamId.toString())
      set性別(s.gender)
      set誕生年(Number(year))
      set誕生月(Number(month))
      set誕生日(Number(date))
      set電話番号(s.tel)
    })(dispatch)
    toggle.onClick()
  }

  const on保存Click = () => {
    postToSStudentEdit(
      {
        studentId: studentId,
        insideNo: 識別番号,
        name: 氏名,
        departmentId: Number(所属),
        teamId: Number(分類),
        gender: Number(性別), // 1: 男性, 2: 女性, 3: その他
        birth: 誕生年 + "-" + 誕生月 + "-" + 誕生日, //"yyyy-mm-dd"
        tel: 電話番号,
        hidden: 非表示,
        retired: 在籍なし,
        連結解除実行: 連携解除,
      },
      (response) => {
        if (response.result === "OK") {
          toggle.onClick()
          postToSStudentList({ 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
        }
      }
    )(dispatch)
  }

  const on新規追加保存Click = () => {
    postToSStudentCreate(
      {
        insideNo: 識別番号,
        name: 氏名,
        departmentId: Number(所属),
        teamId: Number(分類),
        gender: Number(性別), // 1: 男性, 2: 女性, 3: その他
        birth: 誕生年 + "-" + 誕生月 + "-" + 誕生日, //"yyyy-mm-dd"
        tel: 電話番号,
      },
      (response) => {
        if (response.result === "OK") {
          toggle2.onClick()
          postToSStudentList({ 件数: 検索用件数, ページ: 検索用指定ページ, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
        }
      }
    )(dispatch)
  }

  const yearOptions = (n: number) => Array.from(Array(3000).keys()).filter(e => e >= 1910 && e <= new Date().getFullYear()).map(e => <option value={e} key={n + "year-" + e}>{e}</option>)
  const monthOptions = (n: number) => Array.from(Array(13).keys()).filter(e => e).map(e => <option value={e} key={n + "month-" + e}>{e}</option>)
  const dayOptions = (n: number) => Array.from(Array(32).keys()).filter(e => e).map(e => <option value={e} key={n + "day-" + e}>{e}</option>)

  const 検索用最終ページ = Math.floor(SStudentListResponse.count % 検索用件数 === 0 ? SStudentListResponse.count / 検索用件数 : (SStudentListResponse.count / 検索用件数) + 1)
  const pageNumbers = Array.from(Array(検索用最終ページ + 1).keys()).filter(e => e >= 1 && e <= 検索用最終ページ)
  const pages = (n: number) => pageNumbers.reduce((acc, current, i) => {
    if (current === 1) return [...acc, current]
    if ((current >= (検索用指定ページ - 2)) && (current <= (検索用指定ページ + 2))) return [...acc, current]
    if (current === 検索用最終ページ) return [...acc, current]
    if (acc.slice(-1)[0] === "…" || acc.slice(-1)[0] === undefined) return [...acc]
    return [...acc, "…"]
  }, [] as Array<number | string>).map((e, i) => <span key={"pageoptions" + i} style={e === 検索用指定ページ || isNaN(Number(e)) ? { color: 'black' } : { color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { if (!isNaN(Number(e))) { set検索用指定ページ(Number(e)) } }}>{e} </span>)
  const 前のX件 = 検索用指定ページ <= 1 ? <></> : <span style={{ color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { set検索用指定ページ(検索用指定ページ - 1) }} >前の{検索用件数}件</span>
  const 次のX件 = 検索用最終ページ <= 検索用指定ページ ? <></> : <span style={{ color: 'rgb(63, 191, 240)', cursor: 'pointer' }} onClick={() => { set検索用指定ページ(検索用指定ページ + 1) }} >次の{検索用件数}件</span>

  return (
    <>
      <SHeader />
      <div className="title-band">{SHomeResponse.client.体温管理対象呼称}マスター管理</div>
      <div style={{ padding: "10px 20px 20px 20px", backgroundColor: "rgb(241, 241, 241)" }}>
        <div style={{ width: "80%", margin: "auto" }}>
          <div style={{ textAlign: "right", marginBottom: 10 }}>
            <Link to="/s/csv"><img src={CSVアップロード} alt="CSVアップロード" style={{ marginRight: 10 }} /></Link>
            <img src={新規追加} alt="新規追加" onClick={() => {
              set識別番号("")
              set氏名("")
              set所属("0")
              set分類("0")
              set性別(1)
              set誕生年(2000)
              set誕生月(1)
              set誕生日(1)
              set電話番号("")
              toggle2.onClick()
            }} />
          </div>
        </div>
        <div style={{ width: "80%", backgroundColor: "rgb(214, 214, 214)", margin: "auto" }}>
          <div style={{ textAlign: "right" }}>
            <CRow style={{ paddingTop: 20 }}>
              <CCol xs="6" style={{ textAlign: "left", padding: "20px 20px 20px 50px", whiteSpace: 'nowrap' }}>
                {SHomeResponse.client.識別番号名}　<input type="text" value={検索用識別番号} onChange={(e) => { set検索用識別番号(e.target.value) }} style={{ display: 'inline-block', width: '250px', whiteSpace: 'nowrap' }} />
              </CCol>
              <CCol xs="6" style={{ textAlign: "left", padding: "20px 20px 20px 20px", whiteSpace: 'nowrap' }}>
                <span>氏　名</span>　<input type="text" value={検索用氏名} onChange={(e) => { set検索用氏名(e.target.value) }} style={{ display: 'inline-block', width: '250px' }} />
              </CCol>
            </CRow>
            {/* <CRow style={{ marginTop: 20 }}>
              <CCol xs="6">
                カ　ナ　<input type="text" style={{ display: 'inline-block', width: '300px' }} />
              </CCol>
              <CCol xs="6">
              </CCol>
            </CRow> */}
            <CRow style={{ marginTop: 20 }}>
              <CCol xs="4">
              </CCol>
              <CCol xs="4" style={{ textAlign: 'center' }} >
                <img src={検索} alt="検索" onClick={() => {
                  postToSStudentList({ 生徒番号: 検索用識別番号, 氏名: 検索用氏名, 件数: 検索用件数, ページ: 1, 在籍無し: 検索用在籍無し }, () => { })(dispatch, setSStudentListResponse)
                }} />
              </CCol>
              <CCol xs="4">
                <img src={クリア} alt="クリア" style={{ textAlign: 'right', margin: "0 10px 10px 0" }} onClick={() => { set検索用氏名(""); set検索用識別番号("") }} />
              </CCol>
            </CRow>
          </div>
        </div>
        <div style={{ verticalAlign: "middle", fontWeight: 'bold', fontSize: 18, marginTop: 20, minHeight: 400, padding: 10, backgroundColor: "white" }}>
          <div style={{ float: "left" }}>
            <span style={{ marginRight: 20 }}>{SHomeResponse.client.体温管理対象呼称}一覧</span>
            {SHomeResponse.client.所属名}：
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用所属(Number(e.target.value)) }} value={検索用所属}>
              <option value="0">すべて</option>
              {SHomeResponse.クラスList.map(
                e => <option value={e.id}>{e.name}</option>
              )}
            </select>
            {SHomeResponse.client.分類名}：
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用分類(Number(e.target.value)) }} value={検索用分類}>
              <option value="0">すべて</option>
              {SHomeResponse.班List.map(
                e => <option value={e.id}>{e.name}</option>
              )}
            </select>
            <input type="checkbox" checked={検索用在籍無し} onChange={() => { set検索用在籍無し(!検索用在籍無し); reload() }} />在籍なしも表示
          </div>
          <div style={{ float: "right" }}>
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用件数(Number(e.target.value)); reload() }} value={検索用件数}>
              <option value="50">50件</option>
              <option value="100">100件</option>
              <option value="200">200件</option>
            </select>
            <span>
              全{SStudentListResponse.count}件中 {SStudentListResponse.count === 0 ? 0 : (検索用指定ページ * 検索用件数) - 検索用件数 + 1}-{検索用指定ページ * 検索用件数 >= SStudentListResponse.count ? SStudentListResponse.count : 検索用指定ページ * 検索用件数}件を表示中 {前のX件} {pages(1)} {次のX件}
            </span>
          </div>
          <table className="ichiran-table">
            <thead>
              <tr className="ichiran-header">
                <th className="ichiran-header-cell" onClick={() => { set検索用並び順("識別番号"); set検索用昇順降順(検索用昇順降順 === "昇順" ? "降順" : "昇順"); reload() }}>{SHomeResponse.client.識別番号名}</th>
                <th className="ichiran-header-cell">氏名</th>
                <th className="ichiran-header-cell">生年月日</th>
                <th className="ichiran-header-cell">{SHomeResponse.client.所属名}</th>
                <th className="ichiran-header-cell">{SHomeResponse.client.分類名}</th>
                <th className="ichiran-header-cell font-size-x-small">リスト<br />非表示</th>
                <th className="ichiran-header-cell">在籍</th>
                <th className="ichiran-header-cell" onClick={() => { set検索用並び順("連携ステータス"); set検索用昇順降順(検索用昇順降順 === "昇順" ? "降順" : "昇順"); reload() }}>体温データ連携</th>
                <th className="ichiran-header-cell-nodecoration"></th>
              </tr>
            </thead>
            <tbody>
              {SStudentListResponse.items.filter(e => e.departmentId === Number(検索用所属) || Number(検索用所属) === 0).filter(e => e.teamId === Number(検索用分類) || Number(検索用分類) === 0).map((e, i) =>
                <tr key={i + "trIchiranCell"}>
                  <td className="ichiran-cell">{e.生徒番号}</td>
                  <td className="ichiran-cell">{e.氏名}</td>
                  <td className="ichiran-cell">{e.生年月日}</td>
                  <td className="ichiran-cell">{e.クラス}</td>
                  <td className="ichiran-cell">{e.班}</td>
                  <td className="ichiran-cell">{e.非表示 ? "◯" : ""}</td>
                  <td className="ichiran-cell">{!e.在籍無し ? "◯" : ""}</td>
                  <td className="ichiran-cell">{e.体温データ連携}</td>
                  <td className="ichiran-cell-nodecoration" onClick={() => on編集Click(e)}>編集</td>
                </tr>
              )}
            </tbody>
          </table>
          <div style={{ float: "right" }}>
            <select style={{ marginRight: 20 }} onChange={(e) => { set検索用件数(Number(e.target.value)); reload() }} value={検索用件数}>
              <option value="50">50件</option>
              <option value="100">100件</option>
              <option value="200">200件</option>
            </select>
            <span>
              全{SStudentListResponse.count}件中 {SStudentListResponse.count === 0 ? 0 : (検索用指定ページ * 検索用件数) - 検索用件数 + 1}-{検索用指定ページ * 検索用件数 >= SStudentListResponse.count ? SStudentListResponse.count : 検索用指定ページ * 検索用件数}件を表示中 {前のX件} {pages(1)} {次のX件}
            </span>
          </div>
        </div>
      </div>


      <CModal show={toggle2.value} onClose={toggle2.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div className="title-band">{SHomeResponse.client.体温管理対象呼称}マスター追加</div>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.識別番号名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={識別番号} onChange={(e) => { set識別番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">氏　名</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={氏名} onChange={(e) => { set氏名(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.所属名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set所属(e.target.value) }} value={所属}>
                <option value="0">未指定</option>
                {SHomeResponse.クラスList.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.分類名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set分類(e.target.value) }} value={分類}>
                <option value="0">未指定</option>
                {SHomeResponse.班List.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">性別</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="radio" name="性別" checked={性別 === 1} value="1" onChange={(e) => { set性別(Number(e.target.value)) }} />男 <input type="radio" name="性別" checked={性別 === 2} value="2" onChange={(e) => { set性別(Number(e.target.value)) }} />女</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">生年月日</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select value={誕生年} onChange={(e) => { set誕生年(Number(e.target.value)) }}>{yearOptions(1)}</select>
              <select value={誕生月} onChange={(e) => { set誕生月(Number(e.target.value)) }}>{monthOptions(2)}</select>
              <select value={誕生日} onChange={(e) => { set誕生日(Number(e.target.value)) }}>{dayOptions(3)}</select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">携帯電話番号</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={電話番号} onChange={(e) => { set電話番号(e.target.value) }} /></CCol>
          </CRow>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CRow>
            <CCol>
              <img src={戻る} alt="戻る" style={{ textAlign: 'right', margin: "0 20px 0 0", height: 40 }} onClick={(e) => { toggle2.onClick() }} />
              <img src={保存} alt="保存" style={{ height: 40 }} onClick={on新規追加保存Click} />
            </CCol>
          </CRow>
        </CModalFooter>
      </CModal>

      <CModal show={toggle.value} onClose={toggle.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div className="title-band">{SHomeResponse.client.体温管理対象呼称}マスター編集</div>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.識別番号名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={識別番号} onChange={(e) => { set識別番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">氏　名</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={氏名} onChange={(e) => { set氏名(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.所属名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set所属(e.target.value) }} value={所属}>
                <option value="0">未指定</option>
                {SHomeResponse.クラスList.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">{SHomeResponse.client.分類名}</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select onChange={(e) => { set分類(e.target.value) }} value={分類}>
                <option value="0">未指定</option>
                {SHomeResponse.班List.map(
                  e => <option value={e.id}>{e.name}</option>
                )}
              </select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">性別</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <form>
                <input type="radio" name="性別" value="1" defaultChecked={性別 === 1} onClick={() => { set性別(1) }} />男
                <input type="radio" name="性別" value="2" defaultChecked={性別 === 2} onClick={() => { set性別(2) }} />女
              </form>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">生年月日</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}>
              <select value={誕生年} onChange={(e) => { set誕生年(Number(e.target.value)) }}>{yearOptions(4)}</select>
              <select value={誕生月} onChange={(e) => { set誕生月(Number(e.target.value)) }}>{monthOptions(5)}</select>
              <select value={誕生日} onChange={(e) => { set誕生日(Number(e.target.value)) }}>{dayOptions(6)}</select>
            </CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">携帯電話番号</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="text" value={電話番号} onChange={(e) => { set電話番号(e.target.value) }} /></CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">リスト表示</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={非表示} onChange={(e) => { set非表示(e.target.checked) }} />非表示</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">在籍</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={在籍なし} onChange={(e) => { set在籍なし(e.target.checked) }} />無し</CCol>
          </CRow>
          <CRow>
            <CCol xs="4" className="col-label">体温データ連携</CCol>
            <CCol xs="8" style={{ textAlign: "left" }}><input type="checkbox" checked={連携解除} onChange={(e) => { set連携解除(e.target.checked) }} />連携解除</CCol>
          </CRow>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CRow>
            <CCol>
              <img src={戻る} alt="戻る" style={{ textAlign: 'right', margin: "0 20px 0 0", height: 40 }} onClick={(e) => { toggle.onClick() }} />
              <img src={保存} alt="保存" style={{ height: 40 }} onClick={on保存Click} />
            </CCol>
          </CRow>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default SStudent
