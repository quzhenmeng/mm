import { CRow, CCol } from '@coreui/react'
import React, { useEffect } from 'react'
import { useDispatch } from "react-redux"
import { Link } from 'react-router-dom'

import 生徒マスター管理 from '../../assets/img/corporate/14_main_1_master.png'
import データ連携申請承認 from '../../assets/img/corporate/14_main_2_approval.png'
import ログイン管理 from '../../assets/img/corporate/14_main_3_login_kanri.png'
import 表示名称管理 from '../../assets/img/corporate/14_main_4_meisho.png'
import 所属名管理 from '../../assets/img/corporate/14_main_5_syozoku.png'
import 分類名管理 from '../../assets/img/corporate/14_main_6_bunrui.png'
import 体温アラート設定 from '../../assets/img/corporate/14_main_7_setting.png'

import { useTypedSelector } from '../../store'
import { SHeader } from './SHeader'
import { postToSHome } from '../../network/api/sHome'

import { unregister } from '../../serviceWorker'
import version from "../../assets/version.json"
import { postToRoot } from '../../network/api/root'

const Dashboard = () => {
  const dispatch = useDispatch()
  const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)

  useEffect(() => {
    postToSHome({}, (response) => {
      dispatch({ type: 'set', sHomeResponse: response })
    })(dispatch)
  }, [dispatch])

  useEffect(() => {
    const ClientVersion = localStorage.getItem("ClientVersion")
    const ServerVersion = localStorage.getItem("ServerVersion")
    if (ClientVersion !== version.version) {
      localStorage.setItem("ClientVersion", version.version)
      unregister()
      console.log("...Client Refresh")
    }
    postToRoot({}, (response) => {
      if (ServerVersion !== response.version) {
        localStorage.setItem("ServerVersion", response.version)
        unregister()
        console.log("...Server Refresh")
      }
      console.log("Server Version: " + ServerVersion)
    })(() => { })
    console.log("Client Version: " + ClientVersion)
  }, [])

  return (
    <>
      <SHeader />
      <div style={{ marginTop: 10 }}>
        <CRow>
          <CCol xs="4" style={{ textAlign: 'left', paddingLeft: 40 }}>
            <div>
              <Link to="/s/student"><img src={生徒マスター管理} alt='体温管理対象マスター管理' width={220} /></Link>
            </div>
            <div>
              <Link to="/s/affiliation"><img src={データ連携申請承認} alt='データ連携申請承認' width={220} style={{ marginTop: -20 }} /></Link>
            </div>
            {SHomeResponse.manager.superUser || false ? <>
              <Link to="/s/dashboard"><img src={ログイン管理} alt='ログイン管理' width={220} /></Link>
              <Link to="/s/dashboard"><img src={表示名称管理} alt='表示名称管理' width={220} style={{ marginTop: -20 }} /></Link>
              <Link to="/s/dashboard"><img src={所属名管理} alt='所属名管理' width={220} style={{ marginTop: -20 }} /></Link>
              <Link to="/s/dashboard"><img src={分類名管理} alt='分類名管理' width={220} style={{ marginTop: -20 }} /></Link>
              <Link to="/s/dashboard"><img src={体温アラート設定} alt='体温アラート設定' width={220} style={{ marginTop: -20 }} /></Link>
            </> : <></>}
          </CCol>
          <CCol xs="8" style={{ textAlign: 'center', backgroundColor: 'rgb(240,240,240)' }}>
            <div style={{ verticalAlign: "middle", fontWeight: 'bold', fontSize: 18, marginTop: 100, minHeight: 400 }}>お知らせ</div>
          </CCol>
        </CRow>
      </div>
    </>
  )
}

export default Dashboard
