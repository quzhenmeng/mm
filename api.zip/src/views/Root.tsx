import React, { useEffect } from 'react'
//import { Link, useHistory } from 'react-router-dom'
import { useDispatch } from 'react-redux'

const Root = () => {
  //const history = useHistory()
  const dispatch = useDispatch()

  useEffect(() => {
    window.location.href = "/#/login"
    //ここでログイン判定してユーザーダッシュボードとランディングページへ振り分け
  }, [dispatch])

  return (
    <>
    </>
  )
}

export default Root
