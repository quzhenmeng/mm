import React, { Suspense } from 'react'
import {
  Redirect,
  Route,
  Switch,
  RouteProps
} from 'react-router-dom'
import { CContainer, CFade } from '@coreui/react'
import BasicCard from './BasicCard'
import { AUTH_CLASS, AUTH_CLASS_TYPE, LOGIN_STATUS_IS_VALID, API_TOKEN } from '../constants/Localstorage'

import BackgroundImage from '../assets/img/general/1_background_2.png'

// routes config
import routes from '../routes'

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
)

const PrivateRoute: React.FC<RouteProps & { authClass: AUTH_CLASS_TYPE }> = ({ ...props }) => {
  const isUserAuthenticated = localStorage.getItem(API_TOKEN.user) === LOGIN_STATUS_IS_VALID
  const isSmallGroputAuthenticated = localStorage.getItem(API_TOKEN.smallGroup) === LOGIN_STATUS_IS_VALID
  const isOrganizationAuthenticated = localStorage.getItem(API_TOKEN.organization) === LOGIN_STATUS_IS_VALID
  const isOemAuthenticated = localStorage.getItem(API_TOKEN.oem) === LOGIN_STATUS_IS_VALID
  const isVpAuthenticated = localStorage.getItem(API_TOKEN.vp) === LOGIN_STATUS_IS_VALID

  if (props.authClass === AUTH_CLASS.public) {
    return <Route {...props} />
  } else {
    if (isUserAuthenticated && props.authClass === AUTH_CLASS.user) {
      return <Route {...props} />
    } else if (isSmallGroputAuthenticated && props.authClass === AUTH_CLASS.smallGroup) {
      return <Route {...props} />
    } else if (isOrganizationAuthenticated && props.authClass === AUTH_CLASS.organization) {
      return <Route {...props} />
    } else if (isOemAuthenticated && props.authClass === AUTH_CLASS.oem) {
      return <Route {...props} />
    } else if (isVpAuthenticated && props.authClass === AUTH_CLASS.vp) {
      return <Route {...props} />
    } else {
      console.log(`認証タイプ ${props.authClass} : ログインしていないユーザーは${props.path}へはアクセスできません`)
      return <Redirect to="/login" />
    }
  }
}

const Login = React.lazy(() => import('../views/Login'))

const TheContent = () => {
  return (
    <Suspense fallback={loading}>
      <Switch>
        <Route exact path="/login"
          children={() => (
            <main id="mainx" className="c-main" style={{
              backgroundImage: "url(" + BackgroundImage + ")",
            }}>
              <CContainer fluid className="fullheightwidth" style={{ paddingLeft: 0, paddingRight: 0 }}>
                <CFade className="fullheightwidthpad0">
                  <BasicCard headerTitle={"ログイン"} hasHeader={true} hasCloseButton={false}>
                    <Login />
                  </BasicCard>
                </CFade>
              </CContainer>
            </main>
          )} />
        {routes.map((route, idx) => {
          return route.component && (
            <PrivateRoute
              key={idx}
              path={route.path}
              exact={route.exact}
              authClass={route.authClass}
              children={() => (
                <main id="mainx" className="c-main"
                  style={{
                    backgroundImage: "url(" + route.backgroundImage + ")",
                    backgroundColor: route.backgroundColor
                  }}>
                  <CContainer fluid className="fullheightwidth" style={{ paddingLeft: 0, paddingRight: 0 }}>
                    <CFade className="fullheightwidthpad0">
                      {route.cardType ?
                        <BasicCard headerTitle={route.headerTitle} hasHeader={route.hasHeader} hasCloseButton={route.hasCloseButton}>
                          <route.component />
                        </BasicCard>
                        :
                        <route.component />
                      }
                    </CFade>
                  </CContainer>
                </main>
              )}
            />
          )
        })}
        <Redirect from="/" to="/login" />
      </Switch>
    </Suspense>
  )
}

export default React.memo(TheContent)
