import React from 'react'
import { CContainer, CRow, CCol, CCard, CCardBody, CCardHeader } from '@coreui/react'
import CloseButton from '../assets/img/personal/14_close.png'
import { Link } from 'react-router-dom'

type props = {
  children: any,
  hasHeader: boolean | undefined,
  hasCloseButton: boolean | undefined,
  headerTitle: string | undefined,
}
const BasicCard = (props: props) => {
  return (
    <>
      <CContainer className="fullheight">
        <CRow className="fullheight">
          <CCol sm="12" className="fullheightpad0">
            <CCard className="fullheight cardbase" >
              {props.hasHeader ?
                <CCardHeader style={{ textAlign: 'center', padding: props.hasCloseButton ? 5 : "" }}>
                  <CRow>
                    <CCol xs="2"></CCol>
                    <CCol xs="8">
                      {props.headerTitle}
                    </CCol>
                    <CCol xs="2" style={{ textAlign: 'right' }}>
                      {props.hasCloseButton ? <><Link to="/dashboard"><img src={CloseButton} alt="close" height="25px" /></Link></> : <></>}
                    </CCol>
                  </CRow>
                </CCardHeader>
                : <></>}
              <CCardBody className="fullheight" style={{ minHeight: 400 }}>
                {props.children}
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CContainer >
    </>
  )
}

export default BasicCard
