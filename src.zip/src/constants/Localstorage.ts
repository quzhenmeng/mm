export const SMALL_GROUP_API_TOKEN = 'SMALL_GROUP_API_TOKEN'
export const ORGANIZATION_API_TOKEN = 'ORGANIZATION_API_TOKEN'
export const OEM_API_TOKEN = 'OEM_API_TOKEN'
export const VP_API_TOKEN = 'VP_API_TOKEN'
export const LOGIN_STATUS_IS_VALID = 'LOGIN_STATUS_IS_VALID'

export const API_TOKEN = Object.freeze({
  public: "API_TOKEN_public",
  user: "API_TOKEN_user",
  smallGroup: "API_TOKEN_smallGroup",
  organization: "API_TOKEN_organization",
  oem: "API_TOKEN_oem",
  vp: "API_TOKEN_vp"
})
export type API_TOKEN_TYPE = typeof API_TOKEN[keyof typeof API_TOKEN]


export const AUTH_CLASS = Object.freeze({
  public: "public",
  user: "user",
  smallGroup: "smallGroup",
  organization: "organization",
  oem: "oem",
  vp: "vp"
})
export type AUTH_CLASS_TYPE = typeof AUTH_CLASS[keyof typeof AUTH_CLASS]
