import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { TaionDto, TaionDtoZero } from './dto/TaionDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   2-6 メンバー指定体温一覧取得
   --------------------------------------------------------------- */

export const TTaionListURL = URL_ENDPOINT_TOP + '/t/taion/list/'

export interface TTaionListRequestParameters {
  studentId: number, // 生徒指定 必須パラメータ
  件数: number, // itemsの件数  
  ページ?: number, // 初期が1, 0はIllegalArgumentException
  date?: string, // yyyy-mm-dd
}

export interface TTaionListResponse {
  items?: Array<TaionDto>,
  subItems: Array<TaionDto>,
  result: string, //"OK" or "NG"
  department: IdNameDto, // 表示対象Department
  initialDate?: string, // yyyy-MM-dd
  nextPage: number,
  previousPage: number,
}

export const TTaionListResponseZero = {
  items: [TaionDtoZero],
  subItems: [TaionDtoZero],
  result: "NG", //"OK" or "NG"
  department: IdNameDtoZero, // 表示対象Department
  initialDate: "", // yyyy-MM-dd
  nextPage: 0,
  previousPage: 0,
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToTTaionList = (
  params: TTaionListRequestParameters,
  callback: (response: TTaionListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, TTaionListURL, params, callback)
