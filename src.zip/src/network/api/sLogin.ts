//@flow

import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログイン
   --------------------------------------------------------------- */

export const SloginURL = URL_ENDPOINT_TOP + '/s/login/'

export interface SloginParameters {
  hojinCode: string,
  id: string,
  password: string,
}

export type SloginResponse = Response

export const postToSLogin = (
  params: SloginParameters,
  callback: (response: SloginResponse) => void,
) => postToApi(API_TOKEN.organization, SloginURL, params, callback)
