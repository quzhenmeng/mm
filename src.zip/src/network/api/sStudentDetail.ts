import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { StudentDto, StudentDtoZero } from './dto/StudentDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   3-3 システム環境設定
   --------------------------------------------------------------- */

export const SStudentDetailURL = URL_ENDPOINT_TOP + '/s/student/detail/'

export interface SStudentDetailRequestParameters {
  studentId: number
}

export interface SStudentDetailResponse {
  item: StudentDto,
  連携済み: boolean,
  クラスList: Array<IdNameDto>,
  班List: Array<IdNameDto>,
}

export const SStudentDetailResponseZero: SStudentDetailResponse = {
  item: StudentDtoZero,
  連携済み: false,
  クラスList: [IdNameDtoZero],
  班List: [IdNameDtoZero],
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSStudentDetail = (
  params: SStudentDetailRequestParameters,
  callback: (response: SStudentDetailResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SStudentDetailURL, params, callback)
