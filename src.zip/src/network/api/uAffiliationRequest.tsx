import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-27 データ連携申請
   --------------------------------------------------------------- */

export const UAffiliationRequstURL = URL_ENDPOINT_TOP + '/u/affi/request/'

export interface UAffiliationRequstRequest {
  clientId: number,
  name: string,
  departmentId: number,
  birthMonth: number,
  birthDay: number,
}

export type UAffiliationRequstResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUAffiliationRequest = (
  params: UAffiliationRequstRequest,
  callback: (response: UAffiliationRequstResponse) => void,
) => postToApi(API_TOKEN.user, UAffiliationRequstURL, params, callback)
