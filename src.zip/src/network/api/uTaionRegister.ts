//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-12 体温データ登録
   --------------------------------------------------------------- */

export const UTaionRegisterURL = URL_ENDPOINT_TOP + '/u/taion/register/'

export interface UTaionRegister {
  date: string, //yyyy-mm-dd
  time: string, //hh:mm
  taion: number, //XX.X
  photo?: string,
}

export type UTaionRegisterResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUTaionRegister = (
  params: UTaionRegister,
  callback: (response: UTaionRegisterResponse) => void,
) => postToApi(API_TOKEN.user, UTaionRegisterURL, params, callback)
