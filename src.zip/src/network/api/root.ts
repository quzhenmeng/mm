import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   0-0 /
   --------------------------------------------------------------- */

export const RootURL = URL_ENDPOINT_TOP + '/'

export interface RootRequestParameters { }

export interface RootResponse {
  schemeVersion: string,
  version: string,
}

export const RootResponseZero = {
  schemeVersion: "",
  version: "",
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToRoot = (
  params: RootRequestParameters,
  callback: (response: RootResponse) => void = () => { },
) => postToApi(API_TOKEN.user, RootURL, params, callback)
