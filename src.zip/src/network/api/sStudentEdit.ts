import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   3-8 生徒マスター追加
   --------------------------------------------------------------- */

export const SStudentEditURL = URL_ENDPOINT_TOP + '/s/student/edit/'

export interface SStudentEditRequestParameters {
  studentId: number,
  insideNo: string,
  name: string,
  departmentId: number,
  teamId: number,
  gender: number, // 1: 男性, 2: 女性, 3: その他
  birth: string, //"yyyy-mm-dd"
  tel: string,
  hidden: boolean,
  retired: boolean,
  連結解除実行: boolean,
}

export interface SStudentEditResponse {
  result: string, // OK / NG
  cause: string, // duplicatedInsideNo
  message: string, // insideNoが重複しています
}

export const SStudentEditResponseZero: SStudentEditResponse = {
  result: "NG", // OK / NG
  cause: "", // duplicatedInsideNo
  message: "", // insideNoが重複しています
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSStudentEdit = (
  params: SStudentEditRequestParameters,
  callback: (response: SStudentEditResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SStudentEditURL, params, callback)
