export interface TaionDto {
  taionDataId: number,
  date: number, //timestamp
  temperature: number,
  diff: number,
  regTemp: number,
  registered: boolean,
  evidenceId: number,
  regTempSampleCount: number,
}

export const TaionDtoZero: TaionDto = {
  taionDataId: 0,
  date: 0, //timestamp
  temperature: 0,
  diff: 0,
  regTemp: 0,
  registered: false,
  evidenceId: 0,
  regTempSampleCount: 0,
}