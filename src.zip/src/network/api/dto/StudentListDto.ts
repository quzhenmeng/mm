export interface StudentListDto {
  生徒番号: string, 
  氏名: string, 
  生年月日: string, 
  クラス: string, 
  班: string, 
  非表示: boolean, 
  在籍無し: boolean, 
  体温データ連携: string,
  studentId: number,
  departmentId: number,
  teamId: number,
}

export const StudentListDtoZero: StudentListDto = {
  生徒番号: "", 
  氏名: "", 
  生年月日: "", 
  クラス: "", 
  班: "", 
  非表示: false, 
  在籍無し: false, 
  体温データ連携: "",
  studentId: 0,
  departmentId: 0,
  teamId: 0,
}