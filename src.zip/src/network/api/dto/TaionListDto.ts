export interface TaionListDto {
  taionDataId: number,
  date?: number, //timestamp
  temperature: number,
  diff: number,
  regTemp: number,
  registered: boolean,
  evidenceId: number,
  number: string,
  name: string,
  gender: string | undefined,
  studentId: number,
  teamId: number,
  regTempSampleCount: number,
}

export const TaionListDtoZero: TaionListDto = {
  taionDataId: 0,
  date: 0, //timestamp
  temperature: 0,
  diff: 0,
  regTemp: 0,
  registered: false,
  evidenceId: 1,
  number: "1",
  name: "name",
  gender: "男性",
  studentId: 0,
  teamId: 0,
  regTempSampleCount: 0,
}