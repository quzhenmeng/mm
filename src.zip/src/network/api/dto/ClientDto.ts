export interface ClientDto {
  clientId: number,
  type: number, // 1: 企業、2: 学校、3: 各種団体、4:店舗、99: その他 ※ 順次、区分追加
  name: string,
  dispName: string,
  hojinCode: string,
  regTempDays: number, //  平熱計算参照対象日数
  zip: string, //
  pref: string, //"01"~"47"
  prefName: string, //"東京都"など都道府県名
  address: string,
  tel: string,
  mail: string,
  availableAccounts: number, // 発行可能アカウント数
  suspended: boolean, //  契約停止中
  searchCode: string, //8文字の数字、連携申請で使用 ハイフンは除外されている
  contractType: string, //月払い、年払い、その他
  startDate: number, //timestamp,
  companyLogoId: number,
  oemId: number, //  int
  体温管理対象呼称: string,
  分類名: string,
  所属名: string,
  識別番号名: string,
}

export const ClientDtoZero: ClientDto = {
  clientId: 0,
  type: 0, // 1: 企業、2: 学校、3: 各種団体、4:店舗、99: その他 ※ 順次、区分追加
  name: "",
  dispName: "",
  hojinCode: "",
  regTempDays: 0, //  平熱計算参照対象日数
  zip: "", //
  pref: "", //"01"~"47"
  prefName: "", //"東京都"など都道府県名
  address: "",
  tel: "",
  mail: "",
  availableAccounts: 0, // 発行可能アカウント数
  suspended: false, //  契約停止中
  searchCode: "", //8文字の数字、連携申請で使用 ハイフンは除外されている
  contractType: "", //月払い、年払い、その他
  startDate: 0, //timestamp,
  companyLogoId: 0,
  oemId: 0, //  int
  体温管理対象呼称: "",
  分類名: "",
  所属名: "",
  識別番号名: "",
}