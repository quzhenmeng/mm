export interface TeacherDto {
  teacherId: number,
  clientId: number,
  loginId: string,
  fullAccess: boolean,
  departmentId: number,
  accountName: string,
  mail: string,
}

export const TeacherDtoZero: TeacherDto = {
  teacherId: 0,
  clientId: 0,
  loginId: "",
  fullAccess: false,
  departmentId: 0,
  accountName: "",
  mail: "",
}