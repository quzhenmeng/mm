import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-23 グラフ表示期間変更
   ホーム画面で表示するグラフで表示する体温データの日数を設定する
   --------------------------------------------------------------- */

export const UConfigGraphURL = URL_ENDPOINT_TOP + '/u/config/graph/'

export interface UConfigGraphRequest {
  days: number, // 7 or 14
}

export type UConfigGraphResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUConfigGraph = (
  params: UConfigGraphRequest,
  callback: (response: UConfigGraphResponse) => void,
) => postToApi(API_TOKEN.user, UConfigGraphURL, params, callback)
