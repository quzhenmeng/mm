//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* --------------------F-------------------------------------------
   1-12 体温データ登録
   --------------------------------------------------------------- */

export const UTaionEditURL = URL_ENDPOINT_TOP + '/u/taion/edit/'

export interface UTaionEdit {
  taionDataId: number,
  photo: Blob,
}

export type UTaionEditResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUTaionEdit = (
  params: UTaionEdit,
  callback: (response: UTaionEditResponse) => void,
) => postToApi(API_TOKEN.user, UTaionEditURL, params, callback)
