import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { AffiliationDto, AffiliationDtoZero } from './dto/AffiliationDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   3-10 申請一覧
   連携申請の一覧を取得する
   --------------------------------------------------------------- */

export const SAffiliationListURL = URL_ENDPOINT_TOP + '/s/affi/list/'

export interface SAffiliationListRequestParameters {
  未承認:  boolean, //trueの場合 tdt_affiliation.status = 0 による絞り込み
  承認済み24時間以内: boolean, // trueの場合 tdt_affiliation.status = 1でかつ tdt_affiliation.accepted_at が現在時刻と比較し24時間以内のもので絞り込み
  承認済み: boolean, //tdt_affiliation.status = 1 で絞り込み
  承認除外: boolean, // dt_affiliation.status = 2 で絞り込み
  申請日From: string, //"yyyy-mm-dd" 空文字で未指定を表す
  申請日To:  string, //  "yyyy-mm-dd" 空文字で未指定を表す
  件数: number, // int 取得件数  0はIllegalArgumentException
  ページ: number, // int,  1オリジン  0はIllegalArgumentException  全数を越える数値の場合空リストを返却
}

export interface SAffiliationListResponse {
  items?: Array<AffiliationDto>,
  count: number,
  クラスList: Array<IdNameDto>,
}

export const SAffiliationListResponseZero = {
  items: [AffiliationDtoZero],
  count: 0,
  クラスList: [IdNameDtoZero],
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSAffiliationList = (
  params: SAffiliationListRequestParameters,
  callback: (response: SAffiliationListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SAffiliationListURL, params, callback)
