//@flow

import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログイン
   --------------------------------------------------------------- */

export const TLoginURL = URL_ENDPOINT_TOP + '/t/login/'

export interface TLoginParameters {
  hojinCode: string,
  id: string,
  password: string,
}

export type TLoginResponse = Response

export const postToTLogin = (
  params: TLoginParameters,
  callback: (response: TLoginResponse) => void,
) => postToApi(API_TOKEN.smallGroup, TLoginURL, params, callback)
