import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-22 メールアドレス変更
   ログイン中の自アカウントのメールアドレスを更新する
     指定したメールアドレスが重複していたら更新せずにNGを返す
   --------------------------------------------------------------- */

export const UConfigMailURL = URL_ENDPOINT_TOP + '/u/config/mail/'

export interface UConfigMailRequest {
  mail: string,
  password: string,
}

export type UConfigMailResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUConfigMail = (
  params: UConfigMailRequest,
  callback: (response: UConfigMailResponse) => void,
) => postToApi(API_TOKEN.user, UConfigMailURL, params, callback)
