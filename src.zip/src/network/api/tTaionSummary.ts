import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { TaionListDto, TaionListDtoZero } from './dto/TaionListDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   2-4 体温一覧取得
   --------------------------------------------------------------- */

export const TTaionSummaryURL = URL_ENDPOINT_TOP + '/t/taion/summary/'

export interface TTaionSummaryRequestParameters {
  departmentId?: number, // クラス指定 未指定は0扱い
  date?: string, // 日付 "yyyy-mm-dd" 未指定でのアクセス時はアクセスした日とみなす
}

export interface TTaionSummaryResponse {
  items: Array<TaionListDto>,
  result: string, //"OK" or "NG"
  department: IdNameDto, // 表示対象Department
  message: string, // "NG"の場合読める文章が入る
}

export const TTaionSummaryResponseZero = {
  items: [TaionListDtoZero],
  result: "NG", //"OK" or "NG"
  department: IdNameDtoZero, // 表示対象Department
  message: "", // "NG"の場合読める文章が入る
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToTTaionSummary = (
  params: TTaionSummaryRequestParameters = {},
  callback: (response: TTaionSummaryResponse) => void = () => { },
) => postToApi(API_TOKEN.user, TTaionSummaryURL, params, callback)
