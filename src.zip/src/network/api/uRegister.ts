import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   会員登録
   --------------------------------------------------------------- */

export const URegisterURL = URL_ENDPOINT_TOP + '/u/register/'

export interface URegisterParameters {
  gender: String,
  birthYear: Number,
  birthMonth: Number,
  prefecture: String,
  nickname: String,
  password: String,
  mail: String,
}

export type URegisterResponse = Response

export const postToURegister = (
  params: URegisterParameters,
  callback: (response: URegisterResponse) => void,
) => postToApi(API_TOKEN.user, URegisterURL, params, callback)
