import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-20 マイアイコン変更
   --------------------------------------------------------------- */

export const UConfigMyIconURL = URL_ENDPOINT_TOP + '/u/config/myicon/'

export interface UConfigMyIconRequest {
  iconId: string, // int
}

export type UConfigMyIconResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUConfigMyIcon = (
  params: UConfigMyIconRequest,
  callback: (response: UConfigMyIconResponse) => void,
) => postToApi(API_TOKEN.user, UConfigMyIconURL, params, callback)
