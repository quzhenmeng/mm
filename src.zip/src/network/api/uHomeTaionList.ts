import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { TaionDto, TaionDtoZero } from './dto/TaionDto'

/* ---------------------------------------------------------------
    1-5 自体温データ取得
    自分の体温履歴を取得する
   --------------------------------------------------------------- */

export const UHomeTaionListURL = URL_ENDPOINT_TOP + '/u/home/taionList/'

export interface UHomeTaionListRequest {
  件数: number,
  date?: string, //yyyy-mm-dd
  ページ?: number,
}

export interface UHomeTaionListResponse {
  result: string, //OK or NG
  items: Array<TaionDto>,
  subItems: Array<TaionDto>,
  graphDisplayDays: number,
  count: number,
  initialDate: string, //yyyy-MM-dd
  nextPage: number,
  previousPage: number,
}

export const UHomeTaionListResponseZero = {
  result: "OK", //OK or NG
  items: [TaionDtoZero],
  subItems: [TaionDtoZero],
  graphDisplayDays: 7,
  count: 0,
  initialDate: "1970-01-01",
  nextPage: 0,
  previousPage: 0,
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUHomeTaionList = (
  params: UHomeTaionListRequest,
  callback: (response: UHomeTaionListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, UHomeTaionListURL, params, callback)
