import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   3-8 生徒マスター追加
   --------------------------------------------------------------- */

export const SStudentCreateURL = URL_ENDPOINT_TOP + '/s/student/create/'

export interface SStudentCreateRequestParameters {
  insideNo: string,
  name: string,
  departmentId: number,
  teamId: number,
  gender: number, // 1: 男性, 2: 女性, 3: その他
  birth: string, //"yyyy-mm-dd"
  tel: string,
}

export interface SStudentCreateResponse {
  result: string, // OK / NG
  cause: string, // duplicatedInsideNo
  message: string, // insideNoが重複しています
}

export const SStudentCreateResponseZero: SStudentCreateResponse = {
  result: "NG", // OK / NG
  cause: "", // duplicatedInsideNo
  message: "", // insideNoが重複しています
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSStudentCreate = (
  params: SStudentCreateRequestParameters,
  callback: (response: SStudentCreateResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SStudentCreateURL, params, callback)
