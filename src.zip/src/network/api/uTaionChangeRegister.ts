//@flow

import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   1-35 登録体温採用切替
   同日に複数登録済みの体温のうち、正式採用するものを選択する
   --------------------------------------------------------------- */

export const UTaionChangeRegisterURL = URL_ENDPOINT_TOP + '/u/taion/changeRegister/'

export interface UTaionChangeRegisterRequest { 
  taionDataId: number,
  register: boolean,
}

export type UTaionChangeRegisterResponse = Response
export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUTaionChangeRegister = (
  params: UTaionChangeRegisterRequest,
  callback: (response: UTaionChangeRegisterResponse) => void = () => {},
) => postToApi(API_TOKEN.user, UTaionChangeRegisterURL, params, callback)
