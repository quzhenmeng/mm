import { postToApi, URL_ENDPOINT_TOP, API_TOKEN } from '../Accessor'
import { Response } from '../BasicResponse'

/* ---------------------------------------------------------------
   ログアウト
   --------------------------------------------------------------- */

export const ULogoutURL = URL_ENDPOINT_TOP + '/u/logout/'

export interface ULogoutParameters { }

export type ULogoutResponse = Response

export const postToUserLogout = (
  params: ULogoutParameters = {},
  callback: (response: ULogoutResponse) => void = () => {},
) => postToApi(API_TOKEN.user, ULogoutURL, params, callback)
