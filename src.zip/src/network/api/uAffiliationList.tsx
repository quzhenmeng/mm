import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'

/* ---------------------------------------------------------------
   1-27 データ連携先一覧取得
   --------------------------------------------------------------- */

export const UAffiliationListURL = URL_ENDPOINT_TOP + '/u/affi/list/'

export interface AffiliationDto {
  affiliationId: number,
  studentId: number,
  shareConfig: number,
  status: string,
  acceptedAt: number, //timestamp
  createdAt: number, //timestamp
  deniedAt: number, //timestamp
  name: string,
  clientName: string,
}

export const AffiliationDtoZero: AffiliationDto = {
  affiliationId: 0,
  studentId: 0,
  shareConfig: 0,
  status: "",
  acceptedAt: 0, //timestamp
  createdAt: 0, //timestamp
  deniedAt: 0, //timestamp
  name: "",
  clientName: "",
}

export interface UAffiliationListRequest { }

//export type UAffiliationListResponse = Array<AffiliationDto>

//export const UAffiliationListResponseZero = [AffiliationDtoZero]

export interface UAffiliationListResponse {
  items: Array<AffiliationDto>
}

export const UAffiliationListResponseZero = {
  items: [AffiliationDtoZero]
}


export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToUAffiliationList = (
  params: UAffiliationListRequest = {},
  callback: (response: UAffiliationListResponse) => void = () => { },
) => postToApi(API_TOKEN.user, UAffiliationListURL, params, callback)
