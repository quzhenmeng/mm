import { postToApi, URL_ENDPOINT_TOP, RESPONSE_CODE as RESPONSE_CODE_Temporary, API_TOKEN } from '../Accessor'
import { ClientDto, ClientDtoZero } from './dto/ClientDto'
import { ManagerDto, ManagerDtoZero } from './dto/ManagerDto'
import { IdNameDto, IdNameDtoZero } from './dto/IdNameDto'

/* ---------------------------------------------------------------
   3-3 システム環境設定
   --------------------------------------------------------------- */

export const SHomeURL = URL_ENDPOINT_TOP + '/s/home/'

export interface SHomeRequestParameters { }

export interface SHomeResponse {
  serviceLogoId: number, //サービスロゴ取得用ID
  companyLogoId: number, //企業ロゴ取得用ID
  manager: ManagerDto, 
  client: ClientDto, 
  クラスList: Array<IdNameDto>, //選択可能なクラス
  班List: Array<IdNameDto>, //選択可能な班
}

export const SHomeResponseZero = {
  serviceLogoId: 0, //サービスロゴ取得用ID
  companyLogoId: 0, //企業ロゴ取得用ID
  manager: ManagerDtoZero,
  client: ClientDtoZero, 
  クラスList: [IdNameDtoZero], //選択可能なクラス
  班List: [IdNameDtoZero], //選択可能な班
}

export const RESPONSE_CODE = RESPONSE_CODE_Temporary

export const postToSHome = (
  params: SHomeRequestParameters = {},
  callback: (response: SHomeResponse) => void = () => { },
) => postToApi(API_TOKEN.user, SHomeURL, params, callback)
