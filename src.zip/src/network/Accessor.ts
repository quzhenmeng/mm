import axios from "axios"
import FormData from 'form-data'
import { API_TOKEN as API_TOKEN_Temporary, API_TOKEN_TYPE as API_TOKEN_TYPE_Temporary } from "../constants/Localstorage"

import { RESPONSE_CODE as RESPONSE_CODE_Temporary, RESPONSE_CODE_TYPE as RESPONSE_CODE_TYPE_Temporary, Response as Response_Temporary } from "./BasicResponse"
import { URL_ENDPOINT_TOP as URL_ENDPOINT_TOP_Temporary } from "./NetConfig"

export const API_TOKEN = API_TOKEN_Temporary
export type API_TOKEN_TYPE = API_TOKEN_TYPE_Temporary

export const RESPONSE_CODE = RESPONSE_CODE_Temporary
export type RESPONSE_CODE_TYPE = RESPONSE_CODE_TYPE_Temporary
export type Response = Response_Temporary
export const URL_ENDPOINT_TOP = URL_ENDPOINT_TOP_Temporary

const criteriaToOmit = ["createdAt", "createdBy", "updatedAt", "updatedBy", "deletedAt", "deletedBy", "deleted"]

//headers: { 'content-type': 'multipart/form-data' }
//headers: { "content-type": "application/x-www-form-urlencoded" }
export const postToApi =
  (authClass: API_TOKEN_TYPE_Temporary, url: string, json: any = {}, callback: (a: any) => void = (responseData) => { }, headers: any = { 'Content-Type': 'application/x-www-form-urlencoded' }) =>
    async (dispatch: (a: any) => void, setState: (a: any) => void = (any) => { }) => {
      //const params = new URLSearchParams()
      const params = new FormData()
      Object.keys(json).forEach(key => {
        console.log(json)
        if (!criteriaToOmit.includes(key) && json[key] !== undefined) params.append(key, json[key])
      })
      await requestThroughAxios(authClass, url, params, headers, dispatch, callback, setState)
    }

export const requestThroughAxios = async (
  authClass: API_TOKEN_TYPE_Temporary,
  url: string,
  params: FormData,
  headers: any,
  dispatch: (a: any) => void = (any) => { },
  callback: (a: any) => void = (any) => { },
  setState: (a: any) => void = (any) => { },
) =>
  await axios.create({
    withCredentials: true
  }).post(url, params, { headers: headers })
    .then(async response => {
      //console.log('request : ', url, json)
      //console.log('response: ', url, response.data)
      if (response && response && response.data.result === RESPONSE_CODE.NG) {
        dispatch({ type: 'set', message: response.data.message ? response.data.message : "エラーが発生しました" })
        dispatch({ type: 'set', danger: true })
        setState(response.data)
        callback(response.data)
      } else if (response && response && response.data.result === RESPONSE_CODE.ERROR) {
        dispatch({ type: 'set', message: response.data.message ? response.data.message : "想定外のエラーが発生しました" })
        dispatch({ type: 'set', danger: true })
        setState(response.data)
        callback(response.data)
      } else if (response && response.data) {
        setState(response.data)
        callback(response.data)
      }
    }).catch(async error => {
      if (error.response) {
        //console.log('request : ', url, json)
        console.log("======API エラー======")
        console.log(error)
        console.log(error.response.data)
        console.log(error.response.status)
        console.log(error.response.headers)

        if (error.response.status === 401) { // 401が返ってきた場合ログアウトし、状態無視でrootページへ飛ばす
          if (authClass === API_TOKEN.organization) {
            window.location.href = "/#/s/dashboard"
            localStorage.removeItem(authClass)
          } else if (authClass === API_TOKEN.smallGroup) {
            window.location.href = "/#/t/dashboard"
            localStorage.removeItem(authClass)
          } else {
            window.location.href = "/"
            localStorage.removeItem(authClass)
          }
        } else {
          if (error.response.data) {
            dispatch({ type: 'set', message: error.response.data.message ? error.response.data.message : "原因不明のエラーが発生しました。 Code: X05" })
            dispatch({ type: 'set', danger: true })
            callback(error.response.data)
            console.log("Code: X05")
          } else {
            alert("原因不明のAPIエラーが発生しました Code:GNIX1 \n\n")
            console.log(error.response)
          }
        }

      } else if (error.request) {
        alert("インターネットに接続されていない、または、接続が不安定な状態です。再接続を確認のうえ、使用ください。 \n\n")
        console.log(error.request)
      } else {
        alert("原因不明のAPIエラーが発生しました Code:CUNKNOWN-X3 \n\n")
        console.log('Error', error.message)
      }
    })