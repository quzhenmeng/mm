import React from 'react';
import {  /* Link, */ useHistory } from 'react-router-dom'
import OkButton from '../assets/img/personal/14_OK_gray.png'
//import PasswordResetButton from '../assets/img/personal/14_re_password.png'

const LoginError = () => {
  const history = useHistory()

  const onOkClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault()
    history.push("/login")
  }

  return (
    <>
      <h4 className="cardtitle">ログインエラー</h4>
      <div className="maintext">
        入力されたメールアドレス、<br />
        またはパスワードが<br />
        正しくありません。<br />
        確認のうえ、<br />
        入力し直してください。<br />
      </div>
      <div className="primarybutton" onClick={(event) => onOkClick(event)}>
        <img src={OkButton} width={"100%"} alt='ok' />
      </div>
      {/* 
      <div className="secondarybutton">
        <Link to="password_reset">
          <img src={PasswordResetButton} width={"100%"} alt='passreset' />
        </Link>
      </div>
      */}
    </>
  )
}

export default LoginError
