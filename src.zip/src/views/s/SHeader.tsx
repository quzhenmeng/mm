import React from 'react'
import { useTypedSelector } from '../../store'
import { useHistory } from 'react-router-dom'
import { postToSLogout } from '../../network/api/sLogout'
import { API_TOKEN } from '../../constants/Localstorage'
import {
  CRow,
  CCol,
} from '@coreui/react'
import ホーム画面へ from '../../assets/img/corporate/14_main_home.png'
import ログアウト from '../../assets/img/corporate/14_main_logout.png'

export const SHeader = () => {
  const history = useHistory()
  const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)
  return (
    <>
      <div className="top-band">システム環境設定</div>
      <div style={{ backgroundColor: 'white', borderRadius: "0 0 0.5rem 0.5rem", margin: "-5px 10px 0 10px", padding: "5px 5px 5px 5px" }}>
        <CRow>
          <CCol xs="8" style={{ textAlign: 'left', paddingLeft: 40 }}>
            <span style={{ verticalAlign: "middle", fontWeight: 'bold', fontSize: 18 }}>{SHomeResponse.client.dispName} 様</span>
            <span style={{ verticalAlign: "middle", marginLeft: 20 }}>ログイン名: {SHomeResponse.manager.dispName}</span>
          </CCol>
          <CCol xs="4" style={{ textAlign: 'right' }}>
            <span style={{ paddingTop: 5, paddingRight: 5, verticalAlign: "middle" }} >
              <img src={ホーム画面へ} alt='ホーム画面へ' width={100}
                onClick={() => {
                  history.push('/s/dashboard')
                }}
              />
            </span>
            <span style={{ paddingTop: 5, paddingRight: 5, verticalAlign: "middle" }} >
              <img src={ログアウト} alt='ログアウト' width={100}
                onClick={() => {
                  if (window.confirm("ログアウトしますか？")) {
                    postToSLogout()(() => { })
                    localStorage.removeItem(API_TOKEN.organization)
                    history.push("/s/login")
                  }
                }}
              />
            </span>
          </CCol>
        </CRow>
      </div>
    </>
  )
}