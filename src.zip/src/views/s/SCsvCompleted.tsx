import React, { useEffect } from 'react'
import { useDispatch } from "react-redux"
import { useHistory } from 'react-router-dom'
import { useTypedSelector } from '../../store'

//import { useTypedSelector } from '../../store'
import { SHeader } from './SHeader'

import { CRow, CCol, CButton } from '@coreui/react'
import { postToSHome } from '../../network/api/sHome'
import { SStudentCsvUploadResponseZero } from '../../network/api/sStudentCsvUpload'

const SCsvCompleted = () => {
  const dispatch = useDispatch()
  const history = useHistory()
  const SStudentCsvUploadResponse = useTypedSelector((state) => state.sStudentCsvUploadResponse)
  //const SHomeResponse = useTypedSelector((state) => state.sHomeResponse)

  useEffect(() => {
    postToSHome({}, (response) => {
      dispatch({ type: 'set', SHomeResponse: response })
    })(dispatch)
  }, [dispatch])

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    if (SStudentCsvUploadResponseZero.処理エラーNG > 0) {
      history.push("/s/csv")
    } else {
      history.push("/s/student")
    }
  }

  return (
    <>
      <SHeader />
      <div className="title-band">CSVアップロード</div>
      <div style={{ padding: "10px 20px 20px 20px", backgroundColor: "rgb(241, 241, 241)" }}>
        <div style={{ width: "80%", backgroundColor: "rgb(214, 214, 214)", margin: "auto" }}>
          <div style={{ textAlign: "right" }}>
            <form>
              <CRow style={{ padding: "20px 0 0 20px" }}>
                <CCol style={{ textAlign: "left" }}>
                  CSVファイルのアップロードが完了しました。取り込み結果は以下の通りです。
                </CCol>
              </CRow>
              <div style={{ borderBottom: "2px solid rgb(150,150,150)", margin: "20px 0 20px 0" }}></div>
              <div style={{ fontWeight: 'bold', textAlign: "left" }}>
                <div style={{ margin: '0 0 10px 20px' }}>●取り込み結果</div>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>データ件数：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>{SStudentCsvUploadResponse.データ件数}件</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>新規追加OK：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>{SStudentCsvUploadResponse.新規追加OK}件</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>データ更新OK：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>{SStudentCsvUploadResponse.データ更新OK}件</CCol>
                </CRow>
                <CRow>
                  <CCol xs="3" style={{ textAlign: "right" }}>処理エラーNG：</CCol>
                  <CCol xs="9" style={{ textAlign: "left" }}>{SStudentCsvUploadResponse.処理エラーNG}件</CCol>
                </CRow>
                <CRow>
                  <CCol style={{ textAlign: "right" }}>
                    {SStudentCsvUploadResponse.処理エラーNG > 0 ?
                      <table style={{ minWidth: 400, margin: "20px auto 0 auto" }}>
                        <thead>
                          <tr className="ichiran-header">
                            <th className="ichiran-header-cell"></th>
                            <th className="ichiran-header-cell">エラー内容</th>
                          </tr>
                        </thead>
                        <tbody>
                          {SStudentCsvUploadResponse.items.map((e, i) =>
                            <tr key={"error-content" + i}>
                              <td className="ichiran-cell">{e.line}行目</td>
                              <td className="ichiran-cell">{e.message}</td>
                            </tr>)}
                        </tbody>
                      </table>
                      : <></>}
                  </CCol>
                </CRow>

              </div>
              <CRow style={{ textAlign: 'center' }}>
                <CCol>
                  <CButton color="info" size="lg" style={{ margin: "20px 20px 20px 20px" }} onClick={onBackButtonClick}>確認</CButton>
                </CCol>
              </CRow>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default SCsvCompleted
