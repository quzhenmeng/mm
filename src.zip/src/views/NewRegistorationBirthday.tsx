import React from 'react'
import { CForm, CFormGroup, CSelect } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../store'
import InputButton from '../assets/img/personal/14_nyuryoku.png'
import BackButton from '../assets/img/personal/14_back.png'


const NewRegistorationBirthday = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const birthYear = useTypedSelector((state) => state.birthYear)
  const birthMonth = useTypedSelector((state) => state.birthMonth)
  const getYearGannen = (e: number) => e === 1 ? "元" : e
  const getYearLabel = (e: number) => {
    if (e < 1912) return "明治" + getYearGannen(e - 1867) + "年"
    if (e < 1926) return "大正" + getYearGannen(e - 1911) + "年"
    if (e < 1989) return "昭和" + getYearGannen(e - 1925) + "年"
    if (e < 2019) return "平成" + getYearGannen(e - 1988) + "年"
    return "令和" + getYearGannen(e - 2018) + "年"
  }
  const yearFormat = (e: number) => {
    const label = e + "(" + getYearLabel(e) + ")"
    return <option value={e} key={"min-" + e}>{label}</option>
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.push("/new_registoration_prefecture")
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const yearOptions = Array.from(Array(3000).keys()).filter(e => e >= 1910 && e <= new Date()
    .getFullYear())
    .map(e => yearFormat(e))
  const monthOptions = Array.from(Array(13).keys()).filter(e => e).map(e => <option value={e} key={"min-" + e}>{e}</option>)

  return (
    <>
      <h4 className="cardtitle">誕生日年月入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CSelect value={birthYear} style={{ paddingLeft: 5 }} name="ccyear" id="ccyear" size="lg" onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', birthYear: e.target.value })}>
              {yearOptions}
            </CSelect>
            {/* <CLabel htmlFor="ccyear" style={{ display: '', width: "" }}>年</CLabel> */}
          </CFormGroup>
          <div className='formlabelunit'>
            年
          </div>
          <CFormGroup>
            <CSelect value={birthMonth} style={{ paddingLeft: 5, paddingRight: 5 }}  name="ccmonth" id="ccmonth" size="lg" onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', birthMonth: e.target.value })}>
              {monthOptions}
            </CSelect>
            {/* <CLabel htmlFor="ccmonth" style={{ display: '', width: "" }}>月</CLabel> */}
          </CFormGroup>
          <div className='formlabelunit'>
            月
          </div>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>
    </>
  )
}

export default NewRegistorationBirthday
