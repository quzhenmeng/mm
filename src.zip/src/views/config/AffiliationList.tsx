import React, { useState, useEffect } from 'react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import BackButton from '../../assets/img/personal/14_OK_orange.png'
import { postToUAffiliationList, UAffiliationListResponseZero } from '../../network/api/uAffiliationList'
import { ConfigHeader } from './ConfigHeader'
import { format } from 'date-fns/fp'

const AffiliationList = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const [UAffiliationListResponse, setUAffiliationListResponse] = useState(UAffiliationListResponseZero)

  useEffect(() => {
    postToUAffiliationList()(dispatch, setUAffiliationListResponse)
  }, [dispatch, setUAffiliationListResponse])

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20 }}>データ連携申請先一覧</h4>
      {UAffiliationListResponse.items.map((e, i) =>
        <div key={(i + 1) + "affiliationItem"}>
          <div style={{ fontSize: "large", fontWeight: "bold" }}>{i + 1}.{e.clientName}</div>
          <div style={{ marginLeft: 30 }}>{e.status} ( {
            format("yyyy-MM-dd H:mm")(new Date(e.status === affiliationStatus.承認未 ? e.createdAt :
              e.status === affiliationStatus.連携中 ? e.acceptedAt :
                e.status === affiliationStatus.承認除外 ? e.deniedAt :
                  e.status === affiliationStatus.連携解除済み ? e.deniedAt :
                    0))
          } )</div>
        </div>
      )}
      <div style={{ textAlign: 'center' }}>
        <div className="primarybutton" style={{ marginTop: 20 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
        </div>
      </div>
    </>
  )
}

const affiliationStatus = {
  承認未: "承認未",
  連携中: "連携中",
  承認除外: "承認除外",
  連携解除済み: "連携解除済み",
}

export default AffiliationList
