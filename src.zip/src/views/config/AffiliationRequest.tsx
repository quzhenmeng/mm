import React from 'react'
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useInput } from '../../tools/useInput'
import InputButton from '../../assets/img/personal/14_nyuryoku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUAffiliationSearch, RESPONSE_CODE } from '../../network/api/uAffiliationSearch'
import { ConfigHeader } from './ConfigHeader'


const AffiliationRequest = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const code1 = useInput("")
  const code2 = useInput("")

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    const code = code1.value + "" + code2.value
    if (code1.value === "" || code1.value.length > 4 || code2.value === "" || code2.value.length > 4) {
      dispatch({ type: 'set', message: "認証コード、頭の4桁、後ろの4桁をそれぞれ入力してください" })
      dispatch({ type: 'set', danger: true })
    } else if (isNaN(Number(code))) {
      dispatch({ type: 'set', message: "認証コードは、半角数字にて入力してください" + code })
      dispatch({ type: 'set', danger: true })
    } else {
      const parameters = {
        code: code,
      }
      await postToUAffiliationSearch(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            if (response.申請済み) {
              dispatch({ type: 'set', message: "この学校または会社と、既に、データ連携申請済みです" })
              dispatch({ type: 'set', danger: true })
            } else if (response.連携済み) {
              dispatch({ type: 'set', message: "この学校または会社と、既に、データ連携済みです" })
              dispatch({ type: 'set', danger: true })
            } else {
              dispatch({ type: 'set', uAffiliationSearchResponse: response })
              history.push("/config/affiliation_input")
            }
          }
        }
      )(dispatch)
    }
  }


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20, marginBottom: 10 }}>データ連携申請</h4>
      <div className="centered">
        所属先の学校、会社の<br />
        認証コードを入力してください
      </div>
      <h4 className="cardtitle" style={{ marginTop: 20, marginBottom: 10 }}>認証コード</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CInput
              className="input"
              size="lg"
              type="text"
              id="nf-code1"
              name="nf-code1"
              placeholder="4桁の数字"
              style={{ width: "40%", display: "inline" }}
              {...code1}
            />
            <span style={{ margin: "0 5px 0 5px" }}>
              －
            </span>
            <CInput
              className="input"
              size="lg"
              type="text"
              id="nf-code2"
              name="nf-code2"
              placeholder="4桁の数字"
              style={{ width: "40%", display: "inline" }}
              {...code2}
            />
          </CFormGroup>
        </CForm>
        <div className="primarybutton" style={{ marginTop: 80 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default AffiliationRequest
