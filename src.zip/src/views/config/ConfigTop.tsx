import React, { useState, useEffect } from 'react'
import { useHistory } from 'react-router-dom'
import { ConfigHeader } from './ConfigHeader'
import { useDispatch } from 'react-redux'
import { useTypedSelector } from '../../store'
import { API_TOKEN } from '../../constants/Localstorage'
import {
  CButton,
  CModal,
  CModalBody,
  CModalFooter,
} from '@coreui/react'
import { postToUHome } from '../../network/api/uHome'
import { postToUserLogout } from '../../network/api/uLogout'
import { MemberDtoZero } from '../../network/api/dto/MemberDto'
import { unregister } from '../../serviceWorker'

const Settings = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const memberDto = useTypedSelector((state) => state.memberDto)

  const useToggle = (initialValue: boolean) => {
    const [value, set] = useState(initialValue)
    return { value, onClick: () => { set(!value) } }
  }

  const toggle = useToggle(false)

  const onButtonClick = async (e: React.MouseEvent<HTMLFormElement>) => {
    e.preventDefault()
    postToUserLogout()(() => { })
    localStorage.removeItem(API_TOKEN.user)
    unregister()
    window.location.href = "/"
  }


  useEffect(() => {
    if (memberDto === MemberDtoZero) {
      postToUHome({}, (response) => {
        dispatch({ type: 'set', memberDto: response.member })
        dispatch({ type: 'set', taionDto: response.taion })
        dispatch({ type: 'set', supportMailAddress: response.supportMailAddress })
      })(dispatch)
    }
  }, [dispatch, memberDto])

  return (
    <>
      <ConfigHeader />
      <div className="config-category-top">
        <div className="config-category-title">アプリ説明</div>
        <div className="item" onClick={() => { window.location.href = "https://note.com/taion_diary" }}>体温ダイアリーって、こんなアプリ　　　＞</div>
      </div>
      <div className="config-category">
        <div className="config-category-title">会員メニュー</div>
        <div className="item" onClick={() => { history.push("/config/nickname") }}>ニックネームを変更　　　　　　　　　　＞</div>
        {/*<div className="item" onClick={() => { history.push("/config/my_icon") }}>マイアイコンを選択　　　　　　　　　　＞</div>*/}
        <div className="item" onClick={() => { history.push("/config/password") }}>パスワードを変更　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/mail") }}>メールアドレスを変更　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/graph") }}>体温グラフ設定　　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/thermometer") }}>マイ体温計　　　　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { toggle.onClick() }}>ログアウト　　　　　　　　　　　　　　＞</div>
      </div>
      <div className="config-category">
        <div className="config-category-title">学校・会社との体温データ連携</div>
        <div className="item" onClick={() => { history.push("/config/affiliation_request") }}>データ連携申請　　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/affiliation_list") }}>データ連携先リスト　　　　　　　　　　＞</div>
      </div>
      <div className="config-category">
        <div className="config-category-title">体温ダイアリーサービスについて</div>
        <div className="item" onClick={() => { history.push("/config/terms_and_conditions") }}>利用規約　　　　　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/privacy_policy") }}>プライバシーポリシー　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/tokushohou") }}>特定商取引法に基づく表記　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/version") }}>バージョン　　　　　　　　　　　　　　＞</div>
        <div className="item" onClick={() => { history.push("/config/inquiry") }}>お問い合わせ　　　　　　　　　　　　　＞</div>
      </div>
      <CModal show={toggle.value} onClose={toggle.onClick} className={'modal-danger'} centered>
        <CModalBody>
          ログアウトしますか？
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CButton color="info" onClick={(e: React.MouseEvent<HTMLFormElement>) => onButtonClick(e)}>はい</CButton>
          <CButton color="secondary" onClick={toggle.onClick}>戻る</CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default Settings
