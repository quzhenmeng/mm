import React from 'react'
import { useHistory } from 'react-router-dom'
import BackButton from '../../assets/img/personal/14_OK_orange.png'
import { ConfigHeader } from './ConfigHeader'


const Version = () => {
  const history = useHistory()

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="configtitle">バージョン情報</h4>
      <iframe
        width="250px"
        height="40px"
        src="/text/version.txt"
        scrolling="no"
        frameBorder="0"
        title="バージョン情報"
      ></iframe>
      <iframe
        width="250px"
        height="40px"
        src="/text/vendor.txt"
        scrolling="no"
        frameBorder="0"
        title="ベンダー情報"
      ></iframe>
      <div className="primarybutton" style={{ marginTop: 20, textAlign: 'center' }}>
        <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
      </div>
    </>
  )
}

export default Version
