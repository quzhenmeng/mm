import React, { useState } from 'react'
import { CForm, CFormGroup, CInput, CSelect, CCol, CRow } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../../store'
import { useInput } from '../../tools/useInput'
import InputButton from '../../assets/img/personal/14_nyuryoku.png'
import InputDisabledButton from '../../assets/img/personal/nyuryoku_light.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUAffiliationRequest, RESPONSE_CODE } from '../../network/api/uAffiliationRequest'
import { ConfigHeader } from './ConfigHeader'


const AffiliationInput = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const uAffiliationSearchResponse = useTypedSelector((state) => state.uAffiliationSearchResponse)
  const [checked, setChecked] = useState(false)

  const yourname = useInput("")
  const departmentId = useInput(0)
  const birthMonth = useInput(1)
  const birthDay = useInput(1)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    if (yourname.value === "" || departmentId.value === "0" || departmentId.value === 0) {
      dispatch({ type: 'set', message: "未入力の項目があります。入力を行って下さい。" })
      dispatch({ type: 'set', danger: true })
    } else if (yourname.value.length > 20) {
      dispatch({ type: 'set', message: "名前は、20文字以下にて入力してください" })
      dispatch({ type: 'set', danger: true })
    } else {
      const parameters = {
        clientId: uAffiliationSearchResponse.company.clientId,
        name: yourname.value,
        departmentId: departmentId.value,
        birthMonth: birthMonth.value,
        birthDay: birthDay.value,
      }
      await postToUAffiliationRequest(parameters,
        async (response) => {
          if (response.result === RESPONSE_CODE.OK) {
            history.push("./affiliation_completed")
          }
        }
      )(dispatch)
    }
  }


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const departmentOptions = uAffiliationSearchResponse.company.departmentList.map(e => <option value={e.id} key={"min-" + e.id}>{e.name}</option>)
  const dayOptions = Array.from(Array(32).keys()).filter(e => e).map(e => <option value={e} key={"min-day-" + e}>{e}</option>)
  const monthOptions = Array.from(Array(13).keys()).filter(e => e).map(e => <option value={e} key={"min-month-" + e}>{e}</option>)

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle" style={{ marginTop: 20, marginBottom: 10 }}>データ連携申請</h4>
      <div className="centered">
        申請先： {uAffiliationSearchResponse.company.name}<br />
      </div>
      <div style={{ textAlign: 'center' }}>
        <CForm action="" method="post" onSubmit={handleSubmit} style={{ marginLeft: 20 }}>
          <CRow>
            <CCol>
              <CFormGroup>
                <div className="form-label">
                  <label htmlFor="department">所属名：</label>
                </div>
                <CSelect value={departmentId.value} name="department" id="department" size="lg" onChange={(e: React.ChangeEvent<HTMLInputElement>) => departmentId.onChange(e)} >
                  <option value="0">-</option>
                  {departmentOptions}
                </CSelect>
              </CFormGroup>
            </CCol>
          </CRow>
          <CRow>
            <CCol>
              <CFormGroup>
                <div className="form-label">
                  <label htmlFor="nf-yourname">名前：</label>
                </div>
                <CInput
                  className="input"
                  size="lg"
                  type="text"
                  id="nf-yourname"
                  name="nf-yourname"
                  placeholder="あなたの名前"
                  {...yourname}
                />
              </CFormGroup>
            </CCol>
          </CRow>
          <CRow>
            <CCol className='centeredform'>
              <div className="form-label">
                <label htmlFor="department">誕生日：　</label>
              </div>
              <CFormGroup>
                <CSelect value={birthMonth.value} name="ccmonth" id="ccmonth" size="lg" onChange={birthMonth.onChange}>
                  {monthOptions}
                </CSelect>
              </CFormGroup>
              <div className='formlabelunit'>
                月
              </div>
              <CFormGroup>
                <CSelect value={birthDay.value} name="ccday" id="ccday" size="lg" onChange={birthDay.onChange}>
                  {dayOptions}
                </CSelect>
              </CFormGroup>
              <div className='formlabelunit'>
                日
              </div>
            </CCol>
          </CRow>
          <CRow>
            <CCol className='centeredform'>
              <div onClick={() => setChecked(!checked)}><input type="checkbox" checked={checked} />このアプリで登録するすべての体温データ・平熱・発熱の有無・計測の有無を申請先と共有することに同意する</div>
            </CCol>
          </CRow>
        </CForm>
        <div className="primarybutton" style={{ marginTop: 60 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          {checked ?
            <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
            :
            <img src={InputDisabledButton} className="inputbutton" alt='Input' />
          }
        </div>
      </div>

    </>
  )
}

export default AffiliationInput
