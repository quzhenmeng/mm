import React from 'react'
import { useDispatch } from "react-redux"
import { CForm, CFormGroup, CSelect } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useInput } from '../../tools/useInput'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUConfigGraph, RESPONSE_CODE, UConfigGraphResponse } from '../../network/api/uConfigGraph'
import { ConfigHeader } from './ConfigHeader'

const GraphDisplayDays = () => {
  const history = useHistory()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const dispatch = useDispatch()
  const days = useInput(memberDto.graphDisplayDays)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    const parameters = {
      days: days.value,
    }
    await postToUConfigGraph(parameters,
      async (response: UConfigGraphResponse) => {
        if (response.result === RESPONSE_CODE.OK) {
          history.push("/config/")
        }
      }
    )(dispatch)
  }


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle">体温グラフ設定</h4>
      <div style={{ textAlign: 'left' }}>
        <CForm action="" method="post" onSubmit={handleSubmit}>
          <CFormGroup>
            <label htmlFor="days">グラフ表示期間</label>
            <CSelect value={days.value} name="days" id="days" size="lg" onChange={days.onChange}>
              <option value={7}>1週間(体温計測7回)分</option>
              <option value={14}>2週間(体温計測14回)分</option>
            </CSelect>
          </CFormGroup>
        </CForm>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default GraphDisplayDays
