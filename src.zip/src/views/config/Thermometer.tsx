import React, { useState, useEffect } from 'react'
import { useDispatch } from "react-redux"
import { CForm, CFormGroup, CSelect } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useInput } from '../../tools/useInput'
import { useTypedSelector } from '../../store'
import InputButton from '../../assets/img/personal/14_touroku.png'
import BackButton from '../../assets/img/personal/14_back.png'
import { postToUConfigMyThermometer, RESPONSE_CODE, UConfigMyThermometerResponse } from '../../network/api/uConfigMyThermometer'
import { postToUThermometerList, UThermometerListResponseZero } from '../../network/api/uThermometerList'
import { ConfigHeader } from './ConfigHeader'

const Thermometer = () => {
  const history = useHistory()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const dispatch = useDispatch()
  const thermometerId = useInput(memberDto.myThermometer)
  const measurementMethodId = useInput(memberDto.measurementMethod)
  const [UConfigThermometerListResponse, setUConfigThermometerListResponse] = useState(UThermometerListResponseZero)

  useEffect(() => {
    postToUThermometerList()(dispatch, setUConfigThermometerListResponse)
  }, [setUConfigThermometerListResponse, dispatch])

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    const parameters = {
      thermometerId: thermometerId.value,
      measurementMethodId: measurementMethodId.value
    }
    await postToUConfigMyThermometer(parameters,
      async (response: UConfigMyThermometerResponse) => {
        if (response.result === RESPONSE_CODE.OK) {
          history.push("/config/")
        }
      }
    )(dispatch)
  }


  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <ConfigHeader />
      <h4 className="cardtitle">マイ体温計</h4>
      <div style={{ textAlign: 'left' }}>
        <CForm action="" method="post" onSubmit={handleSubmit}>
          <CFormGroup>
            <label htmlFor="maker">メーカー</label>
            <CSelect value={thermometerId.value} name="maker" id="maker" size="lg" onChange={thermometerId.onChange}>
              {UConfigThermometerListResponse.thermometerList.map((e, i) => <option key={"maker" + i} value={e.id}>{e.name}</option>)}
            </CSelect>
          </CFormGroup>
        </CForm>
        <CForm action="" method="post" onSubmit={handleSubmit}>
          <CFormGroup>
            <label htmlFor="keisokubui">計測部位</label>
            <CSelect value={measurementMethodId.value} name="keisokubui" id="keisokubui" size="lg" onChange={measurementMethodId.onChange} >
              {UConfigThermometerListResponse.measurementMethodList.map((e, i) => <option key={"keisokubui" + i} value={e.id}>{e.name}</option>)}
            </CSelect>
          </CFormGroup>
        </CForm>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default Thermometer
