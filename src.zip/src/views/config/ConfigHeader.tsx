import React from 'react'
import { useTypedSelector } from '../../store'
import {
  CRow,
  CCol,
} from '@coreui/react'
import maleIcon from '../../assets/img/general/11_icon_man.png'
import femaleIcon from '../../assets/img/general/11_icon_woman.png'

export const ConfigHeader = () => {
  const memberDto = useTypedSelector((state) => state.memberDto)
  return (
    <div className="config-header">
      <CRow>
        <CCol className="text-right">
        <img src={memberDto.gender === 1 ? maleIcon : femaleIcon} alt="icon" height="15px" style={{marginRight: 5}}/>
          {memberDto.nickName}
          <span className="center-bar">|</span>
        </CCol>
        <CCol className="text-left"> 会員番号: {memberDto.memberId}</CCol>
      </CRow>
    </div>
  )
}