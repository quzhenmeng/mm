import React, { useState, useRef } from 'react';
import { CForm, CFormGroup, CInput } from '@coreui/react'
import { Link, useHistory } from 'react-router-dom'
import { useDispatch } from 'react-redux'

import { useTypedSelector } from '../store'
import { postToULogin } from '../network/api/uLogin'
import { RESPONSE_CODE } from '../network/BasicResponse'
import { API_TOKEN, LOGIN_STATUS_IS_VALID } from "../constants/Localstorage"
import LoginButton from '../assets/img/personal/14_login.png'
import RegistrationButton from '../assets/img/personal/14_shinki.png'

const Login = () => {
  const history = useHistory()
  const dispatch = useDispatch()

  const useInput = (initialValue: string) => {
    const [value, set] = useState(initialValue)
    return { value, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { if (e && e.target) set(e.target.value) } }
  }

  const uLoginMail = useTypedSelector((state) => state.uLoginMail)
  const password = useInput("")
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }

  const onClickLogin = async (e: React.MouseEvent<HTMLDivElement>) => {
    await e.preventDefault()
    await onLogin()
  }

  const onLogin = async () => {

    const parameters = {
      username: uLoginMail,
      password: password.value,
    }

    await postToULogin(parameters,
      async (response) => {
        if (response.result === RESPONSE_CODE.OK) {
          await localStorage.setItem(API_TOKEN.user, LOGIN_STATUS_IS_VALID)
          await history.push("/dashboard")
        } else {
          await history.push("/login_error")
        }
      }
    )(() => { })

  }

  const passwordRef = useRef<HTMLInputElement>(null)
  const ENTER = 13

  const onEmailKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER) {
      if (passwordRef && passwordRef.current) {
        passwordRef.current.focus()
      }
    }
  }


  const onPasswordKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.keyCode === ENTER) {
      onLogin()
    }
  }

  return (
    <>
      <h4 className="cardtitle">ログイン</h4>
      <CForm action="" method="post" onSubmit={handleSubmit}>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="email"
            id="nf-email"
            name="nf-email"
            placeholder="メールアドレス"
            autoComplete="email"
            value={uLoginMail}
            onChange={(ev: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', uLoginMail: ev.target.value })}
            onKeyDown={onEmailKeyDown}
          />
        </CFormGroup>
        <CFormGroup>
          <CInput
            className="input"
            size="lg"
            type="password"
            id="nf-password"
            name="nf-password"
            placeholder="パスワード"
            autoComplete="current-password"
            onKeyDown={onPasswordKeyDown}
            {...password}
          />
        </CFormGroup>
      </CForm>
      <div className="primarybutton" onClick={(event) => onClickLogin(event)}>
        <img src={LoginButton} width={"100%"} alt='Logo' />
      </div>
      <div className="secondarybutton">
        <Link to="new_registoration">
          <img src={RegistrationButton} width={"100%"} alt='Logo' />
        </Link>
      </div>
      {/*
      <div style={{ marginTop: 10, textAlign: "center" }}>
        <Link to="password_reset">
          パスワードを忘れた場合
        </Link>
      </div> 
      */}
    </>
  )
}

export default Login
