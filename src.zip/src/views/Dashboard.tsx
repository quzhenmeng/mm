import { CRow, CCol, CSelect, CInputCheckbox, CButton, CModal, CModalHeader, CModalBody, CModalFooter } from '@coreui/react'
import { CChart } from '@coreui/react-chartjs'
import React, { useState, useEffect } from 'react'
import { useDispatch } from "react-redux"
import { Link, useHistory } from 'react-router-dom'
import maleIcon from '../assets/img/general/11_icon_man.png'
import femaleIcon from '../assets/img/general/11_icon_woman.png'
import Camera from '../assets/img/general/6_camera.png'
import InputTemperature from '../assets/img/personal/14_taion_nyuryoku.png'
import Setting from '../assets/img/personal/14_setting.png'
import ShareLogo from '../assets/img/general/7_rireki_logo.png'
import RequestButton from '../assets/img/general/8_a_rireki_request.png'
import SortButton from '../assets/img/general/8_b_rireki_sort.png'
import DeleteButton from '../assets/img/general/8_c_rireki_delete.png'
import LeftArrow from '../assets/img/general/9_cal_yajirushi_left.png'
import RightArrow from '../assets/img/general/9_cal_yajirushi_right.png'
import Calendar from '../assets/img/general/12_touroku_date.png'
import { postToUHome } from '../network/api/uHome'
import { postToUHomeTaionList } from '../network/api/uHomeTaionList'
import { postToUTaionChangeRegister } from '../network/api/uTaionChangeRegister'
import { UTaionEvidenceURL } from '../network/api/uTaionEvidence'
import { TaionDto } from '../network/api/dto/TaionDto'
import { useTypedSelector } from '../store'
import { day } from '../constants/Day'
import { format, isAfter, addHours } from 'date-fns/fp'

import DatePicker, { registerLocale } from "react-datepicker"
import ja from "date-fns/locale/ja"
import "react-datepicker/dist/react-datepicker.css"

import Slider from "react-slick"
import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"

import { selectBoxStyle } from "../tools/selectBoxStyle"

import { unregister } from '../serviceWorker'
import version from "../assets/version.json"
import { postToRoot } from '../network/api/root'

const formatYyyyMMdd = format("yyyy-MM-dd")

const Dashboard = () => {
  registerLocale("ja", ja)
  //const [UHomeTaionListResponse, setUHomeTaionListResponse] = useState(UHomeTaionListResponseZero)
  const dispatch = useDispatch()
  const history = useHistory()
  const memberDto = useTypedSelector((state) => state.memberDto)
  const taionDto = useTypedSelector((state) => state.taionDto)
  const taionListDate = useTypedSelector((state) => state.taionListDate)
  const taionListPage = useTypedSelector((state) => state.taionListPage)
  const taionListResponse = useTypedSelector((state) => state.taionListResponse)
  const isOneRecordADayMode = useTypedSelector((state) => state.isOneRecordADayMode)
  const taionListData = isOneRecordADayMode ? taionListResponse.items : taionListResponse.subItems
  const taionListDataForGraph = taionListResponse.items

  const line = lineBuilder(taionListDataForGraph.slice(0, memberDto.graphDisplayDays).reverse())

  useEffect(() => {
    const ClientVersion = localStorage.getItem("ClientVersion")
    const ServerVersion = localStorage.getItem("ServerVersion")
    if (ClientVersion !== version.version) {
      localStorage.setItem("ClientVersion", version.version)
      unregister()
      console.log("...Client Refresh")
    }
    postToRoot({}, (response) => {
      if (ServerVersion !== response.version) {
        localStorage.setItem("ServerVersion", response.version)
        unregister()
        console.log("...Server Refresh")
      }
      console.log("Server Version: " + ServerVersion)
    })(() => { })
    console.log("Client Version: " + ClientVersion)
  }, [])

  useEffect(() => {
    postToUHome({}, (response) => {
      dispatch({ type: 'set', memberDto: response.member })
      dispatch({ type: 'set', taionDto: response.taion })
      dispatch({ type: 'set', supportMailAddress: response.supportMailAddress })
    })(dispatch)

    postToUHomeTaionList({ ページ: taionListPage, 件数: memberDto.graphDisplayDays }, (response) => {
      dispatch({ type: 'set', taionListResponse: response })
    })(dispatch)

    //console.log(navigator.mediaDevices.getSupportedConstraints())

  }, [dispatch, taionListPage, memberDto.graphDisplayDays])

  const reload = () => {
    postToUHome({}, (response) => {
      dispatch({ type: 'set', memberDto: response.member })
      dispatch({ type: 'set', taionDto: response.taion })
      dispatch({ type: 'set', supportMailAddress: response.supportMailAddress })
    })(dispatch)

    postToUHomeTaionList({ ページ: taionListPage, 件数: memberDto.graphDisplayDays }, (response) => {
      dispatch({ type: 'set', taionListResponse: response })
    })(dispatch)
  }

  const useToggle = (initialValue: boolean) => {
    const [value, set] = useState(initialValue)
    return { value, onClick: () => { set(!value) } }
  }
  const toggle = useToggle(false)
  const [anEvidenceId, setAnEvidenceId] = useState(0)

  const now = new Date()

  const onClickChangeRegistered = async (taionDto: TaionDto) => {
    await postToUTaionChangeRegister({ taionDataId: taionDto.taionDataId, register: !taionDto.registered })(dispatch)
    await postToUHomeTaionList({ ページ: taionListPage, 件数: memberDto.graphDisplayDays }, (response) => {
      dispatch({ type: 'set', taionListResponse: response })
    })(dispatch)
  }

  const adjustedGraghHeight = (n: number) => {
    const height = window.innerHeight
    switch (true) {
      case height <= 667:
        return (190 + n) + "px"
      case height <= 736:
        return (215 + n) + "px"
      case height <= 770:
        return (260 + n) + "px"
      case height <= 812:
        return (320 + n) + "px"
      default:
        return (350 + n) + "px"
    }
  }

  return (
    <>
      <div style={{ backgroundColor: 'white', borderRadius: "0 0 0.5rem 0.5rem", margin: "-5px 10px 0 10px", padding: "5px 5px 5px 5px" }}>
        <CRow>
          <CCol style={{ textAlign: 'right', verticalAlign: "middle", height: 30 }}>
            <div style={{ fontSize: "medium", fontWeight: 'bolder' }} onClick={() => { reload() }}><img src={memberDto.gender === 1 ? maleIcon : femaleIcon} alt="icon" height='15px' style={{ marginRight: 5 }} />
              {memberDto.nickName}</div>
          </CCol>
          <CCol style={{ textAlign: 'left', verticalAlign: "middle", height: 30 }}>
            <div style={{ fontSize: 'medium', fontWeight: 'bold' }}>平熱 {taionDto ? taionDto.regTemp.toFixed(2) : "--.--"}℃</div>
          </CCol>
        </CRow>
        <div style={{ borderBottom: "2px solid lightgray" }}></div>
        <CRow>
          <CCol xs="4" style={{ textAlign: 'center', verticalAlign: "middle", paddingLeft: 40 }}>
            <div className="center-box">
              <div>
                <div style={{ fontWeight: 'bolder', fontSize: 'x-large', marginTop: 5 }}>{taionDto ? new Date(taionDto.date).getMonth() + 1 : '--'}/{taionDto ? new Date(taionDto.date).getDate() : '--'}<span style={{ fontSize: "large" }}>({taionDto ? day[new Date(taionDto.date).getDay()] : '--'})</span></div>
                <div style={{ fontSize: 'large', lineHeight: '90%' }}>{taionDto ? new Date(taionDto.date).getHours() : '--'}:{taionDto ? format("mm")(taionDto.date) : '--'}</div>
              </div>
            </div>
          </CCol>
          <CCol xs="4" style={{ textAlign: 'center', verticalAlign: "middle" }}>
            <div className="center-box">
              <div>
                <div style={{ fontWeight: 'bolder', fontSize: '42px', lineHeight: '90%', letterSpacing: -2 }}>{taionDto ? taionDto.temperature.toFixed(1) : "--.--"}<span style={{ fontSize: "x-large" }}>℃</span></div>
                <div style={{ marginTop: -7, padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bolder', backgroundColor: 'rgb(240,142,44)', marginRight: -5, marginLeft: -5, color: 'white', borderRadius: "0.2rem", whiteSpace: 'nowrap' }}>平熱差 {taionDto ? taionDto.diff.toFixed(2) : "--.--"}℃</div>
              </div>
            </div>
          </CCol>
          <CCol xs="4" style={{ textAlign: 'left', verticalAlign: "middle" }}>
            <div style={{ paddingTop: 5, paddingRight: 5 }} >
              <img src={
                taionDto ?
                  taionDto.evidenceId === 0 ?
                    Camera
                    :
                    UTaionEvidenceURL + "?evidenceId=" + taionDto.evidenceId
                  :
                  Camera
              } alt='Camera' width={"100%"}
                onClick={() => {
                  if (!taionDto) {
                    dispatch({ type: 'set', isCameraOn: true })
                    dispatch({ type: 'set', is確認モード: false })
                  } else if (taionDto.evidenceId !== 0) {
                    setAnEvidenceId(taionDto.evidenceId)
                    toggle.onClick()
                  } else if (isAfter(addHours(1)(new Date(taionDto.date)), new Date())) {
                    dispatch({ type: 'set', danger: true })
                    dispatch({ type: 'set', message: "１時間以上前の体温データに、計測エビデンス画像の登録は行えません" })
                  } else {
                    dispatch({ type: 'set', isCameraOn: true })
                    dispatch({ type: 'set', is確認モード: true })
                    history.push('/register_taion')
                  }
                }}
              />
            </div>
          </CCol>
        </CRow>
      </div>

      <div style={{ margin: "5px 10px 0 10px", padding: "5px 5px 5px 5px ", backgroundColor: 'rgb(240,142,44)' }}>
        <CSelect style={selectBoxStyle} >
          <option>{memberDto.nickName}</option>
        </CSelect>
        <div style={{ display: 'inline-block', textAlign: 'right', marginLeft: 'auto' }}>
          <img src={LeftArrow} alt='LeftArrow' height={34} style={{ marginLeft: 60 }}
            className={taionListResponse.nextPage === 0 ? "image-grayout" : ""}
            onClick={async (e) => {
              e.preventDefault()
              if (taionListResponse.nextPage === 0) {
              } else {
                await dispatch({ type: 'set', taionListPage: taionListResponse.nextPage })
              }
            }
            } />
          <img src={RightArrow} alt='RightArrow' height={34} style={{ marginLeft: 5 }}
            className={taionListResponse.previousPage === 0 ? "image-grayout" : ""}
            onClick={async (e) => {
              e.preventDefault()
              if (taionListResponse.previousPage === 0) {
              } else {
                await dispatch({ type: 'set', taionListPage: taionListResponse.previousPage })
              }
            }} />
          <DatePicker
            dateFormat="yyyy-MM-dd"
            locale="ja"
            popperPlacement="left"
            selected={new Date(taionListDate)}
            minDate={new Date(taionListResponse.initialDate || 1)}
            maxDate={now}
            onChange={async (date) => {
              if (date && !Array.isArray(date)) {
                dispatch({ type: 'set', taionListDate: formatYyyyMMdd(new Date(date)) })
                postToUHomeTaionList({ date: formatYyyyMMdd(new Date(date)), 件数: memberDto.graphDisplayDays }, (response) => {
                  dispatch({ type: 'set', taionListResponse: response })
                })(dispatch)
              }
            }}
            customInput={<img src={Calendar} alt='Calendar' height={34} style={{ marginLeft: 5 }} />}
          />
        </div>
      </div>
      <div className="slide-panel">
        <Slider {...settings1}>
          <div>
            <CChart type="line" datasets={line.datasets} options={
              {
                scales: {
                  yAxes: [{
                    ticks: {
                      //max: 40,
                      //min: 34,
                    }
                  }]
                },
                legend: {
                  labels: {
                    boxWidth: 15,
                    filter: function (items: any) {
                      return items.text !== '平熱差'
                    }
                  }
                },
                animation: undefined,
                maintainAspectRatio: false
              }
            } labels={line.labels} style={{ height: adjustedGraghHeight(0) }} />
          </div>
          <div>
            <div style={{ maxHeight: adjustedGraghHeight(-20), overflowY: "scroll" }}>
              <table className="ichiran-table">
                <thead>
                  <tr className="ichiran-header">
                    <th className="ichiran-header-cell">日付</th>
                    <th className="ichiran-header-cell">時間</th>
                    <th className="ichiran-header-cell">体温(℃)</th>
                    <th className="ichiran-header-cell">平熱(℃)</th>
                    <th className="ichiran-header-cell">平熱差(℃)</th>
                    <th className="ichiran-header-cell">画像</th>
                    <th className="ichiran-header-cell font-size-x-small"><div>平熱計算</div><div>対象</div></th>
                  </tr>
                </thead>
                <tbody>
                  {taionListData.map((e, i) =>
                    <tr key={i + "trIchiranCell"}>
                      <td className="ichiran-cell">{format('M/d')(new Date(e.date))}</td>
                      <td className="ichiran-cell">{format('HH:mm')(new Date(e.date))}</td>
                      <td className="ichiran-cell">{e.temperature.toFixed(1)}</td>
                      <td className="ichiran-cell" style={{ fontStyle: e.regTempSampleCount < 5 ? "italic" : "normal" }}>{e.regTemp.toFixed(2)}</td>
                      <td className="ichiran-cell" style={{ fontStyle: e.regTempSampleCount < 5 ? "italic" : "normal" }}>{e.diff.toFixed(2)}</td>
                      <td className="ichiran-cell">{
                        e.evidenceId === 0 ?
                          "-"
                          :
                          <span onClick={() => {
                            setAnEvidenceId(e.evidenceId)
                            toggle.onClick()
                          }} style={{ color: "blue" }}>◯</span>
                      }</td>
                      <td className="ichiran-cell"><input type="checkbox" onChange={(event) => onClickChangeRegistered(e)} checked={e.registered} /></td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div>
              <CInputCheckbox style={{ position: "relative", marginLeft: 0 }} checked={isOneRecordADayMode} onChange={(ev) => { dispatch({ type: 'set', isOneRecordADayMode: !isOneRecordADayMode }) }} />1日1件のみ表示
            </div>
          </div>
        </Slider>
      </div>
      <CModal show={toggle.value} onClose={toggle.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }}>
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div className="effect">
            <img src={
              anEvidenceId === 0 ?
                Camera
                :
                UTaionEvidenceURL + "?evidenceId=" + anEvidenceId
            } alt="evidence" />
          </div>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CButton size="lg" onClick={(e: React.MouseEvent<HTMLFormElement>) => { toggle.onClick() }}>戻る</CButton>
        </CModalFooter>
      </CModal>
      <div style={{ position: "fixed", bottom: 0, width: "100%" }}>
        <div className="onx">
          <div style={{ marginTop: 10, width: "100%", backgroundColor: "white", padding: "8px 8px 8px 8px" }}>
            <CRow>
              <CCol xs="6">
                <img src={ShareLogo} width="auto" style={{ maxHeight: 88 * 0.5 }} className="ShareLogo" alt='ShareLogo' />
              </CCol>
              <CCol xs="6" style={{ textAlign: 'right', whiteSpace: "nowrap" }}>
                <img src={RequestButton} width="auto" style={{ maxHeight: 88 * 0.5, marginLeft: "1%", marginRight: "1%" }} alt='RequestButton' />
                <img src={SortButton} width="auto" style={{ maxHeight: 88 * 0.5, marginLeft: "1%", marginRight: "1%" }} alt='SortButton' />
                <img src={DeleteButton} width="auto" style={{ maxHeight: 88 * 0.5, marginLeft: "1%", marginRight: "5%" }} alt='DeleteButton' />
              </CCol>
            </CRow>
          </div>
          <div style={{ backgroundColor: "rgb(201,237,251)" }}>
            <Slider {...settings2}>
              <div>
                <div style={{ padding: "0px 5px 5px 5px" }}>
                  <div style={{ boxShadow: "0 0 3px 3px rgba(63, 191, 240, .3)", height: 25, verticalAlign: 'middle', textAlign: 'center', fontWeight: 'bold', padding: "2px 2px 2px 2px", color: 'white', backgroundColor: 'rgb(63, 191, 240)', display: 'inline-block', width: '100%' }}>
                    <span>< img src={maleIcon} alt='Icon' height={15} style={{ display: 'inline-block' }} />場位樽 新</span>
                  </div>
                  <div style={{ boxShadow: "0 3px 3px 3px rgba(63, 191, 240, .3)", borderRadius: '0 0 1rem 1rem', textAlign: 'center', verticalAlign: "middle", padding: "10px 10px 10px 10px", backgroundColor: 'white', }}>
                    <div style={{ color: 'rgb(240,142,44)', fontWeight: 'bolder', fontSize: 'xx-large', lineHeight: '90%', letterSpacing: -2 }}>37.2<span style={{ fontSize: "x-large" }}>℃</span></div>
                    <div style={{ fontSize: 'small', padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bold', backgroundColor: 'rgb(240,142,44)', color: 'white', borderRadius: "0.2rem" }}>平熱差 +2.2℃</div>
                  </div>
                </div>
              </div>
              <div>
                <div style={{ padding: "0px 5px 5px 5px" }}>
                  <div style={{ boxShadow: "0 0 3px 3px rgba(63, 191, 240, .3)", height: 25, verticalAlign: 'middle', textAlign: 'center', fontWeight: 'bold', padding: "2px 2px 2px 2px", color: 'white', backgroundColor: 'rgb(63, 191, 240)', display: 'inline-block', width: '100%' }}>
                    <span><img src={femaleIcon} alt='Icon' height={15} style={{ display: 'inline-block' }} />梅田瑠 杏</span>
                  </div>
                  <div style={{ boxShadow: "0 3px 3px 3px rgba(63, 191, 240, .3)", borderRadius: '0 0 1rem 1rem', textAlign: 'center', verticalAlign: "middle", padding: "10px 10px 10px 10px", backgroundColor: 'white', }}>
                    <div style={{ color: 'gray', fontWeight: 'bolder', fontSize: 'xx-large', lineHeight: '90%', letterSpacing: -2 }}>35.8<span style={{ fontSize: "x-large" }}>℃</span></div>
                    <div style={{ fontSize: 'small', padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bold', backgroundColor: 'gray', color: 'white', borderRadius: "0.2rem" }}>平熱差 +0.2℃</div>
                  </div>
                </div>
              </div>
              <div>
                <div style={{ padding: "0px 5px 5px 5px" }}>
                  <div style={{ boxShadow: "0 0 3px 3px rgba(63, 191, 240, .3)", height: 25, verticalAlign: 'middle', textAlign: 'center', fontWeight: 'bold', padding: "2px 2px 2px 2px", color: 'white', backgroundColor: 'rgb(63, 191, 240)', display: 'inline-block', width: '100%' }}>
                    <span><img src={maleIcon} alt='Icon' height={15} style={{ display: 'inline-block' }} />葉板留 茜</span>
                  </div>
                  <div style={{ boxShadow: "0 3px 3px 3px rgba(63, 191, 240, .3)", borderRadius: '0 0 1rem 1rem', textAlign: 'center', verticalAlign: "middle", padding: "10px 10px 10px 10px", backgroundColor: 'white', }}>
                    <div style={{ color: 'lightgray', fontWeight: 'bolder', fontSize: 'xx-large', lineHeight: '90%', letterSpacing: -2 }}>--.-<span style={{ fontSize: "x-large" }}>℃</span></div>
                    <div style={{ fontSize: 'small', padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bold', backgroundColor: 'white', color: 'lightgray', borderRadius: "0.2rem" }}>平熱差 --.-℃</div>
                  </div>
                </div>
              </div>
              <div>
                <div style={{ padding: "0px 5px 5px 5px" }}>
                  <div style={{ boxShadow: "0 0 3px 3px rgba(63, 191, 240, .3)", height: 25, verticalAlign: 'middle', textAlign: 'center', fontWeight: 'bold', padding: "2px 2px 2px 2px", color: 'white', backgroundColor: 'rgb(63, 191, 240)', display: 'inline-block', width: '100%' }}>
                    <span><img src={maleIcon} alt='Icon' height={15} style={{ display: 'inline-block' }} />陪多流 希</span>
                  </div>
                  <div style={{ boxShadow: "0 3px 3px 3px rgba(63, 191, 240, .3)", borderRadius: '0 0 1rem 1rem', textAlign: 'center', verticalAlign: "middle", padding: "10px 10px 10px 10px", backgroundColor: 'white', }}>
                    <div style={{ color: 'rgb(240,142,44)', fontWeight: 'bolder', fontSize: 'xx-large', lineHeight: '90%', letterSpacing: -2 }}>35.8<span style={{ fontSize: "x-large" }}>℃</span></div>
                    <div style={{ fontSize: 'small', padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bold', backgroundColor: 'rgb(240,142,44)', color: 'white', borderRadius: "0.2rem" }}>平熱差 +0.2℃</div>
                  </div>
                </div>
              </div>
              <div>
                <div style={{ padding: "0px 5px 10px 5px" }}>
                  <div style={{ boxShadow: "0 0 3px 3px rgba(63, 191, 240, .3)", height: 25, verticalAlign: 'middle', textAlign: 'center', fontWeight: 'bold', padding: "2px 2px 2px 2px", color: 'white', backgroundColor: 'rgb(63, 191, 240)', display: 'inline-block', width: '100%' }}>
                    <span><img src={maleIcon} alt='Icon' height={15} style={{ display: 'inline-block' }} />葉板留 桜</span>
                  </div>
                  <div style={{ boxShadow: "0 3px 3px 3px rgba(63, 191, 240, .3)", borderRadius: '0 0 1rem 1rem', textAlign: 'center', verticalAlign: "middle", padding: "10px 10px 10px 10px", backgroundColor: 'white', }}>
                    <div style={{ color: 'gray', fontWeight: 'bolder', fontSize: 'xx-large', lineHeight: '90%', letterSpacing: -2 }}>35.8<span style={{ fontSize: "x-large" }}>℃</span></div>
                    <div style={{ fontSize: 'small', padding: '0.2px 0.2px 0.2px 0.2px', fontWeight: 'bold', backgroundColor: 'gray', color: 'white', borderRadius: "0.2rem" }}>平熱差 +0.2℃</div>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
          <p>
            <span>
              近日、リリースします。<br />
              お待ちください。
            </span>
          </p>
        </div>
        <div className="buttonBox">
          <div style={{ margin: "0 auto 0 auto" }}>
            <Link to="/config"><img src={Setting} width="auto" height={88 * 0.6} alt='Settings' /></Link>
            <img onClick={() => {
              dispatch({ type: 'set', is確認モード: false })
              dispatch({ type: 'set', isCameraOn: false })
              history.push('/register_taion')
            }} src={InputTemperature} style={{ marginLeft: "2.5%" }} width="auto" height={88 * 0.6} alt='Input' />
          </div>
        </div>
      </div>
    </>
  )
}

const lineBuilder = (taionDtos: Array<TaionDto>) => {
  const labels = taionDtos.map(e => e.date)
  const temperatures = taionDtos.map(e => e.temperature)
  const regTemps = taionDtos.map(e => e.regTemp)
  //const diffs = taionDtos.map(e => e.diff)
  return {
    labels: labels.map(e => format('M/d')(new Date(e))),
    datasets: [
      {
        label: '体温',
        fill: false,
        lineTension: 0.1,
        backgroundColor: 'rgb(61,191,240)',
        borderColor: 'rgb(61,191,240)',
        borderCapStyle: 'butt' as 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter' as 'miter',
        pointBorderColor: 'rgb(61,191,240)',
        pointBackgroundColor: '#fff',
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: 'rgb(61,191,240)',
        pointHoverBorderColor: 'rgb(61,191,240)',
        pointHoverBorderWidth: 2,
        pointRadius: 1,
        pointHitRadius: 10,
        data: temperatures,
      },
      {
        label: '平熱',
        fill: false,
        lineTension: 0.1,
        backgroundColor: 'rgba(240,142,44,0.4)',
        borderColor: 'rgba(240,142,44,1)',
        borderCapStyle: 'butt' as 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderJoinStyle: 'miter' as 'miter',
        pointBorderColor: 'rgba(240,142,44,1)',
        pointBackgroundColor: '#fff',
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: 'rgba(240,142,44,1)',
        pointHoverBorderColor: 'rgba(220,220,220,1)',
        pointHoverBorderWidth: 2,
        pointRadius: 1,
        pointHitRadius: 10,
        data: regTemps,
      },
      /*
      {
        label: '平熱差',
        fill: false,
        lineTension: 0.1,
        backgroundColor: 'rgba(240,142,44,0.4)',
        borderColor: 'rgba(240,142,44,1)',
        borderCapStyle: 'butt' as 'butt',
        borderDash: [],
        borderDashOffset: 0.0,
        borderWidth: 0,
        borderJoinStyle: 'miter' as 'miter',
        pointBorderColor: 'rgba(240,142,44,1)',
        pointBackgroundColor: '#fff',
        pointBorderWidth: 1,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: 'rgb(180,180,180)',
        pointHoverBorderColor: 'rgb(180,180,180)',
        pointHoverBorderWidth: 2,
        showLine: false,
        pointRadius: 1,
        pointHitRadius: 10,
        data: diffs, 
      }
      */
    ]
  }
}

const settings1 = {
  className: "slider standard",
  infinite: false,
  centerMode: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  variableWidth: false,
}

const settings2 = {
  className: "slider variable-width",
  initialSlide: 0,
  infinite: false,
  centerMode: false,
  slidesToShow: 1,
  slidesToScroll: 3,
  variableWidth: true,
}


export default Dashboard
