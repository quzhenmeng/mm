import { CRow, CCol, CForm, CFormGroup, CInput, CButton, CModal, CModalBody, CModalFooter, CModalHeader, } from '@coreui/react'
import React, { useRef, useEffect, useState } from 'react'
import { useDispatch } from "react-redux"
import { useHistory } from 'react-router-dom'
import { useTypedSelector } from '../store'
import { postToUTaionRegister } from '../network/api/uTaionRegister'
import { requestThroughAxios, RESPONSE_CODE, API_TOKEN, URL_ENDPOINT_TOP } from '../network/Accessor'
import FormData from 'form-data'
import { format, isAfter, addHours, addMinutes } from 'date-fns/fp'
import { useToggle } from '../tools/useToggle'
//import DatePicker, { registerLocale } from "react-datepicker"


import CameraPng from '../assets/img/general/6_camera.png'
import Retake from '../assets/img/personal/14_retake.png'
import Calendar from '../assets/img/general/12_touroku_date.png'
import Thermometer from '../assets/img/general/12_touroku_ondo.png'
import Clock from '../assets/img/general/12_touroku_time.png'
import Down from '../assets/img/general/13_touroku_down.png'
import Up from '../assets/img/general/13_touroku_up.png'

import Webcam from "react-webcam"

import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"

import InputButton from '../assets/img/personal/14_touroku.png'
import BackButton from '../assets/img/personal/14_back.png'
import { postToUHome } from '../network/api/uHome'

const height = 97 * 1.5
const width = 167 * 1.5

const RegisterTaion = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const isCameraOn = useTypedSelector((state) => state.isCameraOn)
  const is確認モード = useTypedSelector((state) => state.is確認モード)
  const memberDto = useTypedSelector((state) => state.memberDto)
  const taionDto = useTypedSelector((state) => state.taionDto)
  const [date, setDate] = useState(
    is確認モード ?
      taionDto ?
        format('yyyy-MM-dd')(new Date(taionDto.date))
        : format('yyyy-MM-dd')(new Date())
      : format('yyyy-MM-dd')(new Date())
  )
  const [time, setTime] = useState(
    is確認モード ?
      taionDto ?
        format('HH:mm')(new Date(taionDto.date))
        : format('HH:mm')(new Date())
      : format('HH:mm')(new Date())
  )
  const [degree, setDegree] = useState(taionDto ? taionDto.temperature : 36)
  const taionEvidence = useTypedSelector((state) => state.taionEvidence)

  const toggle = useToggle(isCameraOn)
  const 計測体温計の画像を保存しない = useToggle(false)


  const onInputButtonClickWithoutPhoto = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    const parameters = {
      date: date,
      time: time,
      taion: degree,
      photo: undefined,
    }
    postToUTaionRegister(parameters,
      async (response) => {
        if (response.result === RESPONSE_CODE.OK) {
          history.push("/dashboard")
        }
      }
    )(dispatch)
  }

  const on撮影ボタンClick = () => {
    if (isAfter(addHours(1)(new Date(date + " " + time)), new Date())) {
      dispatch({ type: 'set', danger: true })
      dispatch({ type: 'set', message: "１時間以上前の体温データに、計測エビデンス画像の登録は行えません" })
    } else {
      toggle.onClick()
    }
  }

  const onInputButtonClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    await e.preventDefault()
    if (is確認モード) {
      if (taionEvidence && taionEvidence !== CameraPng && taionDto) {
        const file = await DataURIToBlob(taionEvidence)
        const formData = await new FormData()
        await formData.append('taionDataId', taionDto.taionDataId)
        await formData.append('photo', file, 'taionImage.jpg')

        await requestThroughAxios(API_TOKEN.user, URL_ENDPOINT_TOP + '/u/taion/edit/', formData, { 'content-type': 'multipart/form-data' }, dispatch,
          (response) => {
            if (response.result === RESPONSE_CODE.OK) {
              history.push("/dashboard")
              dispatch({ type: "set", taionEvidence: CameraPng })
            }
          }
        )
      }
    } else {
      if (taionEvidence && taionEvidence !== CameraPng) {
        const file = await DataURIToBlob(taionEvidence)
        const formData = await new FormData()
        await formData.append('date', date)
        await formData.append('time', time)
        await formData.append('taion', degree + "")
        await formData.append('photo', file, 'taionImage.jpg')
        await requestThroughAxios(API_TOKEN.user, URL_ENDPOINT_TOP + '/u/taion/register/', formData, { 'content-type': 'multipart/form-data' }, dispatch,
          (response) => {
            if (response.result === RESPONSE_CODE.OK) {
              history.push("/dashboard")
              dispatch({ type: "set", taionEvidence: CameraPng })
            }
          }
        )
      }
    }
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    dispatch({ type: "set", taionEvidence: CameraPng })
    history.goBack()
  }

  const DataURIToBlob = (dataURI: string) => {
    const splitDataURI = dataURI.split(',')
    const byteString = splitDataURI[0].indexOf('base64') >= 0 ? atob(splitDataURI[1]) : decodeURI(splitDataURI[1])
    const mimeString = splitDataURI[0].split(':')[1].split(';')[0]

    const ia = new Uint8Array(byteString.length)
    for (let i = 0; i < byteString.length; i++)
      ia[i] = byteString.charCodeAt(i)

    return new Blob([ia], { type: mimeString })
  }



  const webcamRef = useRef(null)

  const capture = React.useCallback(
    () => {
      if (webcamRef && webcamRef.current) {
        const imageSrc = ((webcamRef.current as unknown) as Webcam).getScreenshot()

        const canvas = canvasRef.current as unknown as HTMLCanvasElement
        const ctx = canvas.getContext('2d')

        const img = new Image()
        img.src = imageSrc ? imageSrc : CameraPng
        img.className = "cameraIcon"
        img.alt = 'camera'
        img.onload = () => {
          if (img.src !== CameraPng && ctx != null) {
            const now = format('yyyy-MM-dd HH:mm:ss')(new Date())
            ctx.clearRect(0, 0, width, height)
            const imgWidth = width * (height / img.height)
            const Xcoordiate = (width - imgWidth) / 2
            ctx.drawImage(img, Xcoordiate, 0, imgWidth, height)
            ctx.textAlign = "center"
            ctx.font = "24px 'Impact'"
            ctx.fillStyle = "blue"
            ctx.strokeText(now, width / 2, height)
            ctx.fillStyle = "white"
            ctx.fillText(now, width / 2, height)
            ctx.save()

            dispatch({ type: "set", taionEvidence: canvas.toDataURL() })
            計測体温計の画像を保存しない.setTrue()
          }
        }

      }
      toggle.onClick()
    },
    [webcamRef, toggle, dispatch, 計測体温計の画像を保存しない]
  )

  const canvasRef = useRef(null)

  useEffect(() => {

    postToUHome({}, (response) => {
      dispatch({ type: 'set', memberDto: response.member })
      dispatch({ type: 'set', taionDto: response.taion })
      dispatch({ type: 'set', supportMailAddress: response.supportMailAddress })
    })(dispatch)

    const canvas = canvasRef.current as unknown as HTMLCanvasElement
    const ctx = canvas.getContext('2d')
    const img = new Image()
    img.src = taionEvidence ? taionEvidence : CameraPng
    img.className = "cameraIcon"
    img.alt = 'camera'
    if (ctx) {
      ctx.drawImage(img, 0, 0, width, height)
      ctx.save()
    }

  }, [taionEvidence, dispatch])

  return (
    <>
      <div className="centered">
        <div className="taion-register-header">
          <CRow>
            <CCol className="text-right">
              {memberDto.nickName}
              <span className="center-bar">|</span>
            </CCol>
            <CCol className="text-left"> 平熱: {taionDto && taionDto.regTemp !== 0 ? taionDto.regTemp : "--.--"}</CCol>
          </CRow>
        </div>
        <div className="taion-title-header">
          <div style={{ fontSize: "large" }}>体温データ登録</div>
        </div>
        <CForm action="" method="post">
          <CFormGroup>
            <img src={Calendar} alt="calendar" height="34" />
            <CInput
              required
              style={{
                width: 160,
                marginLeft: 10,
                display: 'inline-block',
                verticalAlign: 'middle',
                backgroundColor: is確認モード ? 'white' : 'rgb(253,238,223)',
                border: 0,
                fontSize: 'large',
                fontWeight: 'bolder'
              }}
              disabled={is確認モード}
              size="lg"
              className="input"
              type="date"
              max={format('yyyy-MM-dd')(new Date())}
              id="nf-date"
              name="nf-date"
              autoComplete="date"
              value={date}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDate(e.target.value)}
            />
          </CFormGroup>
          <CFormGroup>
            <img src={Clock} alt="time" height="34" />
            <CInput
              required
              style={{
                width: 160,
                marginLeft: 10,
                display: 'inline-block',
                verticalAlign: 'middle',
                backgroundColor: is確認モード ? 'white' : 'rgb(253,238,223)',
                border: 0,
                fontSize: 'large',
                fontWeight: 'bolder'
              }}
              disabled={is確認モード}
              size="lg"
              className="input"
              type="time"
              id="nf-time"
              name="nf-time"
              autoComplete="time"
              value={time}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTime(e.target.value)}
            />
          </CFormGroup>
          <CFormGroup>
            <span style={{ width: 34 }}>
              <img src={Thermometer} alt="degree" height="34" />
            </span>
            <CInput
              style={{
                width: 100,
                marginLeft: 10,
                display: 'inline-block',
                verticalAlign: 'middle',
                backgroundColor: is確認モード ? 'white' : 'rgb(253,238,223)',
                border: 0,
                fontSize: 'x-large',
                fontWeight: 'bolder'
              }}
              disabled={is確認モード}
              className="input"
              size="lg"
              type="text"
              id="nf-degree"
              name="nf-degree"
              autoComplete="degree"
              value={degree}
            />
            {is確認モード ? <></> :
              <>
                <img src={Down} alt="down" height={50} style={{ marginLeft: 5 }} onClick={(e) => {
                  if (degree > 32) {
                    setDegree(Number((degree - 0.1).toFixed(1)))
                  }
                }} />
                <img src={Up} alt="up" height={50} style={{ marginLeft: 5 }} onClick={(e) => {
                  if (degree < 42.9) {
                    setDegree(Number((degree + 0.1).toFixed(1)))
                  }
                }} />
              </>}
          </CFormGroup>
        </CForm>
        <div>
          <div style={{ marginBottom: 10 }}>計測エビデンス 撮影</div>
          <div>
            <canvas className="canvas" width={width} height={height} ref={canvasRef} onClick={() => { on撮影ボタンClick() }} />
            <img src={taionEvidence} alt='camera' style={{ display: "none" }} />
          </div>
          <div style={{ marginTop: 10 }}>
            {taionEvidence === CameraPng ?
              <><input type="checkbox" id="hozonsinai" onChange={計測体温計の画像を保存しない.onClick} checked={計測体温計の画像を保存しない.value} /> <span onClick={計測体温計の画像を保存しない.onClick}>計測体温計の画像を保存しない</span></>
              :
              <div><img src={Retake} alt="retake" width={width} onClick={() => { on撮影ボタンClick() }} /></div>
            }
          </div>
        </div>

        <div className="primarybutton" style={{ marginTop: 15 }}>
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className={"inputbutton" + (計測体温計の画像を保存しない.value ? "" : " image-grayout")} alt='Input'
            onClick={(ev) => {
              if (isAfter(addMinutes(5)(new Date()), new Date(date + " " + time))) {
                dispatch({ type: 'set', danger: true })
                dispatch({ type: 'set', message: "現在時刻以降の計測時間の体温データは登録出来ません" })
              } else {
                if (taionEvidence && taionEvidence !== CameraPng) {
                  onInputButtonClick(ev)
                } else if (計測体温計の画像を保存しない.value) {
                  onInputButtonClickWithoutPhoto(ev)
                }
              }
            }} />
        </div>
      </div>

      <CModal show={toggle.value} onClose={toggle.onClick} className={'modal'} centered>
        <CModalHeader closeButton={true} style={{ backgroundColor: 'rgb(62, 191, 240)' }} >
        </CModalHeader>
        <CModalBody style={{ display: "block", textAlign: "center" }}>
          <div>
            計測した体温計の<br />
            体温表示を枠内におさめて<br />
            撮影してください
          </div>
          <div className="effect">
            <Webcam
              audio={false}
              height={height}
              width={width}
              ref={webcamRef}
              screenshotFormat="image/png"
              videoConstraints={{
                aspectRatio: 1.777777,
                //width: width,
                //height: height,
                facingMode: "environment"
              }}
            />
          </div>
        </CModalBody>
        <CModalFooter style={{ display: "block", textAlign: "center" }}>
          <CButton size="lg" color="info" onClick={(e: React.MouseEvent<HTMLFormElement>) => capture()}>撮影</CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default RegisterTaion
