import React from 'react';
import { CForm, CFormGroup, CSelect } from '@coreui/react'
import { useHistory } from 'react-router-dom'
import { useDispatch } from "react-redux"
import { useTypedSelector } from '../store'
import InputButton from '../assets/img/personal/14_nyuryoku.png'
import BackButton from '../assets/img/personal/14_back.png'
import prefecturesJson from '../assets/prefectures.json'


const NewRegistorationPrefecture = () => {
  const history = useHistory()
  const dispatch = useDispatch()
  const prefecture = useTypedSelector((state) => state.prefecture)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onInputButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.push("/new_registoration_nickname")
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  const yearOptions = prefecturesJson.prefectures.map(e => <option value={e.code} key={"min-" + e.code}>{e.name}</option>)

  return (
    <>
      <h4 className="cardtitle">都道府県入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm inline action="" method="post" onSubmit={handleSubmit} className="centeredform">
          <CFormGroup>
            <CSelect value={prefecture} name="ccmonth" id="ccmonth" size="lg" onChange={(e: React.ChangeEvent<HTMLInputElement>) => dispatch({ type: 'set', prefecture: e.target.value })} >
              {yearOptions}
            </CSelect>
            {/* https://lab.syncer.jp/Document/Japanese-prefecture-number/ */}
          </CFormGroup>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
          <img src={InputButton} className="inputbutton" alt='Input' onClick={onInputButtonClick} />
        </div>
      </div>

    </>
  )
}

export default NewRegistorationPrefecture
