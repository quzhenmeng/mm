import React from 'react';
import { CForm, CFormGroup, CButton } from '@coreui/react'
import { useDispatch } from "react-redux"
import { useHistory } from 'react-router-dom'
import BackButton from '../assets/img/personal/14_back.png'

const NewRegistoration = () => {
  const history = useHistory()
  const dispatch = useDispatch()

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault() }
  const onButtonClick = (e: React.MouseEvent<HTMLButtonElement>, gender: string) => {
    e.preventDefault()
    dispatch({ type: 'set', gender: gender })
    history.push("/new_registoration_birthday")
  }

  const onBackButtonClick = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault()
    history.goBack()
  }

  return (
    <>
      <h4 className="cardtitle">性別入力</h4>
      <div style={{ textAlign: 'center' }}>
        <CForm action="" method="post" onSubmit={handleSubmit}>
          <CFormGroup>
            <div style={{ textAlign: "center" }}>
              <CButton size="lg" className="m-2" onClick={(e: React.MouseEvent<HTMLButtonElement>) => onButtonClick(e, "男性")} >
                男性
            </CButton>
              <CButton size="lg" className="m-2" onClick={(e: React.MouseEvent<HTMLButtonElement>) => onButtonClick(e, "女性")}>
                女性
            </CButton>
            </div>
          </CFormGroup>
        </CForm>
        <div className="primarybutton">
          <img src={BackButton} className="backbutton" alt='Back' onClick={onBackButtonClick} />
        </div>
      </div>
    </>
  )
}

export default NewRegistoration
